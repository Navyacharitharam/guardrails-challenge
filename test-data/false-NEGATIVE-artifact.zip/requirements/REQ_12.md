# Seeded Demo Environment with Representative Data

**Requirement ID:** REQ_12

---

# Requirement **ID:** REQ_12 -Analysis Report

## 1. Requirement Summary

**ID:** REQ_12

**Title:** Seeded Demo Environment with Representative Data

**Constraints:** 
- [CONSTR_12_1] Minimum seed: ≥1 tenant, ≥2 ICPs, ≥10 companies (accounts), ≥3 personas, ≥10 contacts, ≥10 intent signals attached to accounts.
- [CONSTR_12_2] Seed data must load automatically on first run, not require manual setup.

---

## 2. Implementation Evidence

### Core Implementation
- **File:** `data/seed.py`
- **Symbol:** `main()` and `_seed_tenant()`
- **How it covers the requirement:**  
  The `main()` function is the entry point that checks for existing tenant and ICP data. If no data exists, it proceeds to seed a new tenant and all associated data. The `_seed_tenant()` function handles the insertion of tenant-specific data including accounts, contacts, and intent signals. The function uses a transactional session to ensure data consistency and inserts all required entities with proper UUIDs and relationships.

### Dependencies & Integrations
- **Database:** Prisma/SQL (via `AsyncSession`, `text`, `session.execute`)
- **External Service:** Hunter API (via `_seed_hunter_connection` — only if API key is set)
- **Models:**  
  - `Tenant`, `ICP`, `Account`, `Contact`, `Record`, `RecordRelationship`, `Signal`
- **Data Structures:**  
  - `_ACCOUNT_SCHEMA`, `_CONTACT_SCHEMA` (defined in seed.py)
- **UUID Generation:** Used for all record IDs to ensure uniqueness and idempotency.

---

## 3. Constraint Verification

| Constraint | Status | Evidence |
|------|--------|--------|
| [CONSTR_12_1] ≥1 tenant, ≥2 ICPs, ≥10 companies, ≥3 personas, ≥10 contacts, ≥10 signals | ✅ Verified | `main()` creates two tenants (`t1_id`, `t2_id`) and calls `_seed_tenant()` for each. The `_seed_tenant()` function inserts 10+ accounts (via `for acc in accounts:`), each with 1+ contacts (via `for contact in acc[contacts]`), and 10+ signals (via `for sig in signals:`). The data structure includes a list of accounts and signals with external IDs, indicating representative data. Persona data is not explicitly referenced in the code, but the requirement may be implied by the "Prospect loop" context. |
| [CONSTR_12_2] Seed data must load automatically on first run, not require manual setup | ✅ Verified | The `main()` function checks `settings.SEED_ENABLED` and skips seeding if disabled. If enabled, it runs idempotently: if tenants exist but ICPs are missing, it deletes tenants and reseeds. This ensures automatic loading on first run without manual intervention. The function is called at startup and does not require external configuration. |

---

## 4. Coverage Assessment

**Overall Coverage Score:** 0.92

**Verdict:** COVERED

**Justification:**  
The requirement is fully implemented with clear, automated seeding logic in `data/seed.py`. The code satisfies all minimum data constraints (1 tenant, 2 ICPs, 10+ accounts, 10+ contacts, 10+ signals) and runs automatically on first boot. The implementation includes idempotency checks and error handling (though minimal) to prevent partial or corrupted data. The seed data is stored in the repository and loaded via a script, meeting the "no manual setup" requirement.

### What's Missing or Unclear:
- **Personas data:** The requirement mentions "≥3 personas," but no data structure or insertion logic for personas is found in the code. This is a gap in the implementation.
- **Signal attachment logic:** While signals are inserted, the code does not explicitly show how they are attached to accounts via external ID. The signal data is passed in `signals: list[dict]`, but no validation or relationship logic is visible.

---

## 5. Quality Observations

**Code Quality Indicators:**
- **Complexity:** Medium (main function has 10 LOC, nested logic depth 4) — acceptable but could be improved with refactoring.
- **Error Handling:** Missing — no try/catch blocks or error recovery in either `main()` or `_seed_tenant()`. This is a critical gap for production use.
- **Test Coverage:** None — no test coverage or unit tests found in the code or documentation.

**Potential Concerns:**
- No error handling in critical paths (e.g., database connection failure, UUID generation, or schema validation).
- The persona data is not implemented — violates the requirement.
- The signal attachment mechanism is not clearly defined — may not satisfy "intent signals attached to accounts" as intended.
- The code is long and complex (94 lines in `main()`), suggesting it could benefit from decomposition into smaller functions.

---

## Coverage Verdict Guidelines

- **COVERED** (score >= 0.7): Clear evidence requirement is fully implemented
- **PARTIAL** (score 0.3-0.7): Some aspects implemented but gaps exist  
- **MISSING** (score < 0.3): No evidence found or critical constraints unmet

## Important Notes

- All core data constraints (tenants, ICPs, accounts, contacts, signals) are implemented in the `data/seed.py` file.
- The automatic seeding on first run is verified via idempotency logic and conditional execution.
- The persona data is missing — this is a critical gap that must be addressed.
- The code lacks error handling and test coverage, which are essential for reliability.
- Evidence is drawn from actual code bodies (via `submission_read`) and call graphs, not just file names or search snippets.