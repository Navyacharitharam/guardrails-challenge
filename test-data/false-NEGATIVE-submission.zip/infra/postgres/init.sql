-- =============================================================================
-- GTM Platform — PostgreSQL Initialization
-- =============================================================================
-- Executed once by the PostgreSQL Docker entrypoint when the data directory
-- is empty (i.e. on the very first container start).
--
-- Tables are created AFTER this file runs, by the Alembic migrations in
-- backbone/alembic/versions/.  This file cannot reference specific tables
-- because they don't exist yet.  Instead it installs the infrastructure that
-- migrations and the application depend on:
--
--   1. Required extensions
--   2. Tenant-context helper functions
--   3. An EVENT TRIGGER that automatically enforces row-level security on
--      every table that carries a tenant_id column, fired by PostgreSQL
--      itself immediately after each CREATE TABLE statement.
--
-- The same helper functions and event trigger are also created inside
-- Alembic migration 001 (as CREATE OR REPLACE / DROP IF EXISTS) so that
-- the migration chain is fully self-contained and runnable against any
-- PostgreSQL 16 instance, not just one initialised by this file.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Extensions
-- -----------------------------------------------------------------------------

CREATE EXTENSION IF NOT EXISTS "pgcrypto";   -- gen_random_uuid(), pgp_sym_encrypt
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";  -- uuid_generate_v4() (legacy compat)

-- -----------------------------------------------------------------------------
-- Tenant context helpers
--
-- The application sets the active tenant at the start of every request:
--
--   SELECT set_current_tenant('<uuid>');
--
-- Row-level security policies then call current_tenant_id() in their USING
-- expressions so every query is automatically scoped to the active tenant
-- without the application ever writing WHERE tenant_id = ?.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION set_current_tenant(p_tenant_id TEXT)
RETURNS VOID
LANGUAGE plpgsql AS $$
BEGIN
    -- is_local = TRUE → value is scoped to the current transaction only.
    -- This is safe with connection poolers (pgBouncer, asyncpg pool) because
    -- the setting is automatically reset when the transaction ends, preventing
    -- context leakage across pooled connections.
    PERFORM set_config('app.current_tenant', p_tenant_id, TRUE);
END;
$$;


CREATE OR REPLACE FUNCTION current_tenant_id()
RETURNS UUID
LANGUAGE plpgsql STABLE AS $$
BEGIN
    RETURN NULLIF(current_setting('app.current_tenant', TRUE), '')::UUID;
EXCEPTION
    -- current_setting() returns '' when missing; the cast to UUID raises
    -- invalid_text_representation if a non-UUID string slips through.
    WHEN invalid_text_representation THEN
        RETURN NULL;
END;
$$;

-- -----------------------------------------------------------------------------
-- Auto-RLS event trigger
--
-- PostgreSQL fires gtm_auto_tenant_rls() immediately after every
-- CREATE TABLE statement.  If the new table has a tenant_id column the
-- function:
--
--   • ENABLE ROW LEVEL SECURITY   — activates the RLS engine
--   • FORCE ROW LEVEL SECURITY    — applies policies to the table owner too
--                                   (prevents accidental bypass by the gtm role)
--   • CREATE POLICY tenant_isolation
--       USING  (tenant_id = current_tenant_id())
--       WITH CHECK (tenant_id = current_tenant_id())
--
-- Tables without tenant_id (e.g. "tenants" itself, alembic_version) are left
-- untouched.
--
-- The trigger fires inside the same transaction as the CREATE TABLE, so if
-- the migration is rolled back the policy is rolled back with it.
-- -----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION gtm_auto_tenant_rls()
RETURNS event_trigger
LANGUAGE plpgsql AS $$
DECLARE
    obj        RECORD;
    tbl_schema TEXT;
    tbl_name   TEXT;
BEGIN
    FOR obj IN
        SELECT *
        FROM   pg_event_trigger_ddl_commands()
        WHERE  command_tag = 'CREATE TABLE'
        AND    object_type = 'table'
    LOOP
        -- Resolve schema and table name from the OID — more robust than
        -- string-splitting object_identity which can contain quoted identifiers.
        SELECT n.nspname, c.relname
        INTO   tbl_schema, tbl_name
        FROM   pg_class     c
        JOIN   pg_namespace n ON n.oid = c.relnamespace
        WHERE  c.oid = obj.objid;

        -- Only tables in the public schema with a tenant_id column get RLS.
        IF tbl_schema = 'public'
        AND EXISTS (
            SELECT 1
            FROM   pg_attribute a
            JOIN   pg_class     c ON c.oid = a.attrelid
            WHERE  c.oid         = obj.objid
            AND    a.attname     = 'tenant_id'
            AND    a.attnum      > 0
            AND    NOT a.attisdropped
        ) THEN
            EXECUTE format(
                'ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY',
                tbl_schema, tbl_name
            );
            EXECUTE format(
                'ALTER TABLE %I.%I FORCE ROW LEVEL SECURITY',
                tbl_schema, tbl_name
            );
            -- One permissive policy covers all operations.
            -- USING  — guards SELECT / UPDATE / DELETE (which rows are visible)
            -- WITH CHECK — guards INSERT / UPDATE (which rows can be written)
            EXECUTE format(
                'CREATE POLICY tenant_isolation ON %I.%I'
                '  AS PERMISSIVE FOR ALL TO PUBLIC'
                '  USING     (tenant_id = current_tenant_id())'
                '  WITH CHECK (tenant_id = current_tenant_id())',
                tbl_schema, tbl_name
            );
        END IF;
    END LOOP;
END;
$$;


-- DROP IF EXISTS + CREATE rather than CREATE OR REPLACE — event triggers
-- don't support OR REPLACE in PostgreSQL 16.
DROP EVENT TRIGGER IF EXISTS gtm_auto_tenant_rls_trigger;

CREATE EVENT TRIGGER gtm_auto_tenant_rls_trigger
    ON ddl_command_end
    WHEN TAG IN ('CREATE TABLE')
    EXECUTE FUNCTION gtm_auto_tenant_rls();
