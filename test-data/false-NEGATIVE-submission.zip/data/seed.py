"""Idempotent seed — 2 tenants, 2 ICPs, 20 accounts, 40 contacts, 30 signals.

Re-running this script when data already exists is a no-op (checked via
tenant count before any inserts).  The RLS contract requires calling
``set_current_tenant`` before every batch of tenant-scoped inserts.
"""
import asyncio
import os
import uuid
from datetime import datetime, timezone

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

import backbone.models  # noqa: F401 — populates Base.metadata
from backbone.core.config import settings
from backbone.core.security.auth import hash_password
from backbone.core.security.encryption import encrypt_credentials
from backbone.models.enums import EnrichmentStatus, SignalType
from backbone.models.icp import ICP
from backbone.models.integration_connection import IntegrationConnection
from backbone.models.object_definition import ObjectDefinition
from backbone.models.record import Record
from backbone.models.relationship import RecordRelationship
from backbone.models.signal import Signal
from backbone.models.tenant import Tenant


def _dt(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# Shared schema definitions
# ---------------------------------------------------------------------------

_ACCOUNT_SCHEMA = {
    "fields": [
        {"name": "company_name", "type": "string", "required": True},
        {"name": "industry", "type": "string"},
        {"name": "employee_count", "type": "integer"},
        {"name": "arr_usd", "type": "number"},
        {"name": "funding_stage", "type": "string"},
        {"name": "website", "type": "string"},
        {"name": "hq_city", "type": "string"},
        {"name": "hq_country", "type": "string"},
        {"name": "technologies_used", "type": "array"},
    ]
}

_CONTACT_SCHEMA = {
    "fields": [
        {"name": "first_name", "type": "string", "required": True},
        {"name": "last_name", "type": "string", "required": True},
        {"name": "email", "type": "string", "required": True},
        {"name": "job_title", "type": "string"},
        {"name": "seniority", "type": "string"},
        {"name": "department", "type": "string"},
        {"name": "linkedin_url", "type": "string"},
    ]
}


# ---------------------------------------------------------------------------
# Tenant 1 — Acme GTM  (DevTools / data-infra SaaS buyer)
# ---------------------------------------------------------------------------

_T1_ICP = dict(
    name="Series B+ Developer-Tools SaaS",
    description=(
        "B2B SaaS companies in developer tooling, data infrastructure, or "
        "cloud platforms that have raised Series B or later and are building "
        "out a sales motion beyond founder-led growth."
    ),
    firmographic_criteria={
        "industries": ["Developer Tools", "Data Infrastructure", "Cloud Platform", "Database Platform"],
        "employee_count": {"min": 50, "max": 1500},
        "arr_usd": {"min": 3_000_000, "max": 250_000_000},
        "funding_stages": ["Series B", "Series C", "Series D", "Series E", "Series F"],
        "geographies": ["USA", "Germany", "UK", "Canada"],
    },
    technographic_criteria={
        "must_use_one_of": ["AWS", "GCP", "Azure"],
        "nice_to_have": ["Kubernetes", "Terraform", "Kafka", "Snowflake"],
        "disqualifiers": [],
    },
    persona_criteria={
        "target_titles": [
            "VP of Sales", "Chief Revenue Officer", "Head of Revenue",
            "VP of Growth", "Director of Sales",
        ],
        "seniority_levels": ["VP", "C-Suite", "Director"],
        "departments": ["Sales", "Revenue", "Growth"],
    },
    signal_weights={
        "funding": 0.90,
        "hiring": 0.70,
        "intent": 0.85,
        "job_change": 0.60,
        "technographic": 0.50,
        "news": 0.40,
        "web_activity": 0.75,
    },
)

# Each entry: account attrs + two contacts.  account_ext_id used for dedup.
_T1_ACCOUNTS = [
    {
        "ext": "acc-datastax",
        "fit": 0.91,
        "attrs": {
            "company_name": "DataStax",
            "industry": "Database Platform",
            "employee_count": 520,
            "arr_usd": 52_000_000,
            "funding_stage": "Series E",
            "website": "https://datastax.com",
            "hq_city": "Santa Clara",
            "hq_country": "USA",
            "technologies_used": ["Cassandra", "Kubernetes", "AWS", "Kafka"],
        },
        "contacts": [
            {
                "ext": "con-datastax-001",
                "attrs": {
                    "first_name": "Sarah", "last_name": "Chen",
                    "email": "s.chen@datastax.com",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/sarah-chen-dstx",
                },
            },
            {
                "ext": "con-datastax-002",
                "attrs": {
                    "first_name": "Marcus", "last_name": "Rivera",
                    "email": "m.rivera@datastax.com",
                    "job_title": "Head of Revenue Operations", "seniority": "Director",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/marcus-rivera-dstx",
                },
            },
        ],
    },
    {
        "ext": "acc-contentful",
        "fit": 0.87,
        "attrs": {
            "company_name": "Contentful",
            "industry": "Content Management",
            "employee_count": 680,
            "arr_usd": 72_000_000,
            "funding_stage": "Series E",
            "website": "https://contentful.com",
            "hq_city": "Berlin",
            "hq_country": "Germany",
            "technologies_used": ["React", "GraphQL", "AWS", "Node.js"],
        },
        "contacts": [
            {
                "ext": "con-contentful-001",
                "attrs": {
                    "first_name": "Jana", "last_name": "Hoffmann",
                    "email": "j.hoffmann@contentful.com",
                    "job_title": "Chief Revenue Officer", "seniority": "C-Suite",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/jana-hoffmann-cf",
                },
            },
            {
                "ext": "con-contentful-002",
                "attrs": {
                    "first_name": "Tom", "last_name": "Bradley",
                    "email": "t.bradley@contentful.com",
                    "job_title": "VP of Enterprise Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/tom-bradley-cf",
                },
            },
        ],
    },
    {
        "ext": "acc-netlify",
        "fit": 0.84,
        "attrs": {
            "company_name": "Netlify",
            "industry": "Web Platform",
            "employee_count": 410,
            "arr_usd": 42_000_000,
            "funding_stage": "Series D",
            "website": "https://netlify.com",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Fastly", "React", "Terraform"],
        },
        "contacts": [
            {
                "ext": "con-netlify-001",
                "attrs": {
                    "first_name": "Diana", "last_name": "Larson",
                    "email": "d.larson@netlify.com",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/diana-larson-netlify",
                },
            },
            {
                "ext": "con-netlify-002",
                "attrs": {
                    "first_name": "Ahmed", "last_name": "Khalil",
                    "email": "a.khalil@netlify.com",
                    "job_title": "Director of Growth", "seniority": "Director",
                    "department": "Growth",
                    "linkedin_url": "https://linkedin.com/in/ahmed-khalil-ntlf",
                },
            },
        ],
    },
    {
        "ext": "acc-snyk",
        "fit": 0.93,
        "attrs": {
            "company_name": "Snyk",
            "industry": "Developer Security",
            "employee_count": 1250,
            "arr_usd": 155_000_000,
            "funding_stage": "Series F",
            "website": "https://snyk.io",
            "hq_city": "London",
            "hq_country": "UK",
            "technologies_used": ["AWS", "GCP", "Kubernetes", "Terraform", "Kafka"],
        },
        "contacts": [
            {
                "ext": "con-snyk-001",
                "attrs": {
                    "first_name": "Rachel", "last_name": "Moore",
                    "email": "r.moore@snyk.io",
                    "job_title": "Chief Revenue Officer", "seniority": "C-Suite",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/rachel-moore-snyk",
                },
            },
            {
                "ext": "con-snyk-002",
                "attrs": {
                    "first_name": "Daniel", "last_name": "Park",
                    "email": "d.park@snyk.io",
                    "job_title": "VP of Mid-Market Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/daniel-park-snyk",
                },
            },
        ],
    },
    {
        "ext": "acc-postman",
        "fit": 0.89,
        "attrs": {
            "company_name": "Postman",
            "industry": "API Platform",
            "employee_count": 820,
            "arr_usd": 102_000_000,
            "funding_stage": "Series D",
            "website": "https://postman.com",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Node.js", "MongoDB", "Kubernetes"],
        },
        "contacts": [
            {
                "ext": "con-postman-001",
                "attrs": {
                    "first_name": "Priya", "last_name": "Sharma",
                    "email": "p.sharma@postman.com",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/priya-sharma-postman",
                },
            },
            {
                "ext": "con-postman-002",
                "attrs": {
                    "first_name": "Kevin", "last_name": "Zhang",
                    "email": "k.zhang@postman.com",
                    "job_title": "Head of Enterprise Sales", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/kevin-zhang-postman",
                },
            },
        ],
    },
    {
        "ext": "acc-mixpanel",
        "fit": 0.82,
        "attrs": {
            "company_name": "Mixpanel",
            "industry": "Product Analytics",
            "employee_count": 390,
            "arr_usd": 47_000_000,
            "funding_stage": "Series C",
            "website": "https://mixpanel.com",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Snowflake", "Kafka", "Python"],
        },
        "contacts": [
            {
                "ext": "con-mixpanel-001",
                "attrs": {
                    "first_name": "Lauren", "last_name": "Foster",
                    "email": "l.foster@mixpanel.com",
                    "job_title": "VP of Revenue", "seniority": "VP",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/lauren-foster-mxp",
                },
            },
            {
                "ext": "con-mixpanel-002",
                "attrs": {
                    "first_name": "James", "last_name": "Okonkwo",
                    "email": "j.okonkwo@mixpanel.com",
                    "job_title": "Director of Sales Development", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/james-okonkwo-mxp",
                },
            },
        ],
    },
    {
        "ext": "acc-launchdarkly",
        "fit": 0.88,
        "attrs": {
            "company_name": "LaunchDarkly",
            "industry": "Feature Management",
            "employee_count": 570,
            "arr_usd": 68_000_000,
            "funding_stage": "Series D",
            "website": "https://launchdarkly.com",
            "hq_city": "Oakland",
            "hq_country": "USA",
            "technologies_used": ["AWS", "GCP", "Go", "Redis", "Kubernetes"],
        },
        "contacts": [
            {
                "ext": "con-ld-001",
                "attrs": {
                    "first_name": "Megan", "last_name": "Walsh",
                    "email": "m.walsh@launchdarkly.com",
                    "job_title": "Chief Revenue Officer", "seniority": "C-Suite",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/megan-walsh-ld",
                },
            },
            {
                "ext": "con-ld-002",
                "attrs": {
                    "first_name": "Carlos", "last_name": "Mendez",
                    "email": "c.mendez@launchdarkly.com",
                    "job_title": "VP of Sales Engineering", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/carlos-mendez-ld",
                },
            },
        ],
    },
    {
        "ext": "acc-grafana",
        "fit": 0.85,
        "attrs": {
            "company_name": "Grafana Labs",
            "industry": "Observability",
            "employee_count": 720,
            "arr_usd": 84_000_000,
            "funding_stage": "Series D",
            "website": "https://grafana.com",
            "hq_city": "New York",
            "hq_country": "USA",
            "technologies_used": ["AWS", "GCP", "Azure", "Prometheus", "Go"],
        },
        "contacts": [
            {
                "ext": "con-grafana-001",
                "attrs": {
                    "first_name": "Natalie", "last_name": "Johansson",
                    "email": "n.johansson@grafana.com",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/natalie-johansson-grafana",
                },
            },
            {
                "ext": "con-grafana-002",
                "attrs": {
                    "first_name": "Ben", "last_name": "Adeyemi",
                    "email": "b.adeyemi@grafana.com",
                    "job_title": "Head of Enterprise Accounts", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/ben-adeyemi-grafana",
                },
            },
        ],
    },
    {
        "ext": "acc-airbyte",
        "fit": 0.86,
        "attrs": {
            "company_name": "Airbyte",
            "industry": "Data Integration",
            "employee_count": 260,
            "arr_usd": 32_000_000,
            "funding_stage": "Series B",
            "website": "https://airbyte.com",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "GCP", "Python", "Kubernetes", "dbt"],
        },
        "contacts": [
            {
                "ext": "con-airbyte-001",
                "attrs": {
                    "first_name": "Sophie", "last_name": "Lambert",
                    "email": "s.lambert@airbyte.com",
                    "job_title": "VP of Growth", "seniority": "VP",
                    "department": "Growth",
                    "linkedin_url": "https://linkedin.com/in/sophie-lambert-airbyte",
                },
            },
            {
                "ext": "con-airbyte-002",
                "attrs": {
                    "first_name": "Raj", "last_name": "Patel",
                    "email": "r.patel@airbyte.com",
                    "job_title": "Director of Sales", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/raj-patel-airbyte",
                },
            },
        ],
    },
    {
        "ext": "acc-temporal",
        "fit": 0.83,
        "attrs": {
            "company_name": "Temporal Technologies",
            "industry": "Workflow Orchestration",
            "employee_count": 240,
            "arr_usd": 28_000_000,
            "funding_stage": "Series B",
            "website": "https://temporal.io",
            "hq_city": "Seattle",
            "hq_country": "USA",
            "technologies_used": ["AWS", "GCP", "Go", "Java", "Kubernetes"],
        },
        "contacts": [
            {
                "ext": "con-temporal-001",
                "attrs": {
                    "first_name": "Alex", "last_name": "Kim",
                    "email": "a.kim@temporal.io",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/alex-kim-temporal",
                },
            },
            {
                "ext": "con-temporal-002",
                "attrs": {
                    "first_name": "Elena", "last_name": "Vasquez",
                    "email": "e.vasquez@temporal.io",
                    "job_title": "Head of Revenue", "seniority": "Director",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/elena-vasquez-temporal",
                },
            },
        ],
    },
]

# Signals reference account external_ids so we can look up record IDs after flush.
_T1_SIGNALS = [
    {
        "account_ext": "acc-datastax",
        "signal_type": SignalType.FUNDING,
        "source": "crunchbase",
        "score": 0.95,
        "occurred_at": _dt(2025, 1, 15),
        "payload": {
            "round": "Series E Extension",
            "amount_usd": 115_000_000,
            "lead_investor": "Andreessen Horowitz",
            "announcement_url": "https://techcrunch.com/datastax-series-e-ext",
        },
    },
    {
        "account_ext": "acc-snyk",
        "signal_type": SignalType.HIRING,
        "source": "linkedin_jobs",
        "score": 0.78,
        "occurred_at": _dt(2025, 2, 3),
        "payload": {
            "job_title": "Regional Sales Manager — EMEA",
            "department": "Sales",
            "open_roles_count": 12,
            "job_url": "https://snyk.io/careers/rsm-emea",
        },
    },
    {
        "account_ext": "acc-postman",
        "signal_type": SignalType.INTENT,
        "source": "bombora",
        "score": 0.82,
        "occurred_at": _dt(2025, 2, 18),
        "payload": {
            "topic": "API Gateway Vendors",
            "surge_score": 82,
            "week_over_week_change": "+34%",
        },
    },
    {
        "account_ext": "acc-launchdarkly",
        "signal_type": SignalType.NEWS,
        "source": "google_news",
        "score": 0.55,
        "occurred_at": _dt(2025, 1, 28),
        "payload": {
            "headline": "LaunchDarkly launches AI-native feature flags for LLM applications",
            "url": "https://venturebeat.com/launchdarkly-ai-flags",
            "sentiment": "positive",
        },
    },
    {
        "account_ext": "acc-contentful",
        "signal_type": SignalType.TECHNOGRAPHIC,
        "source": "builtwith",
        "score": 0.60,
        "occurred_at": _dt(2025, 1, 10),
        "payload": {
            "technology_added": "Databricks",
            "category": "Data Platform",
            "detected_at": "2025-01-10",
        },
    },
    {
        "account_ext": "acc-mixpanel",
        "signal_type": SignalType.WEB_ACTIVITY,
        "source": "clearbit_reveal",
        "score": 0.70,
        "occurred_at": _dt(2025, 2, 22),
        "payload": {
            "pages_visited": ["/pricing", "/enterprise", "/case-studies/enterprise"],
            "session_count_7d": 14,
            "avg_session_duration_sec": 312,
        },
    },
    {
        "account_ext": "acc-airbyte",
        "signal_type": SignalType.FUNDING,
        "source": "crunchbase",
        "score": 0.92,
        "occurred_at": _dt(2025, 3, 5),
        "payload": {
            "round": "Series B",
            "amount_usd": 80_000_000,
            "lead_investor": "Benchmark",
            "announcement_url": "https://techcrunch.com/airbyte-series-b",
        },
    },
    {
        "account_ext": "acc-temporal",
        "signal_type": SignalType.FUNDING,
        "source": "crunchbase",
        "score": 0.88,
        "occurred_at": _dt(2025, 2, 12),
        "payload": {
            "round": "Series B",
            "amount_usd": 75_000_000,
            "lead_investor": "Index Ventures",
            "announcement_url": "https://techcrunch.com/temporal-series-b",
        },
    },
    {
        "account_ext": "acc-grafana",
        "signal_type": SignalType.HIRING,
        "source": "linkedin_jobs",
        "score": 0.72,
        "occurred_at": _dt(2025, 3, 1),
        "payload": {
            "job_title": "Enterprise Account Executive",
            "department": "Sales",
            "open_roles_count": 8,
            "locations": ["New York", "London", "Berlin"],
        },
    },
    {
        "account_ext": "acc-netlify",
        "signal_type": SignalType.JOB_CHANGE,
        "source": "linkedin_alerts",
        "score": 0.65,
        "occurred_at": _dt(2025, 1, 20),
        "payload": {
            "person_name": "Diana Larson",
            "previous_company": "Vercel",
            "previous_title": "Head of Sales",
            "new_title": "VP of Sales",
            "started_date": "2025-01-15",
        },
    },
    {
        "account_ext": "acc-datastax",
        "signal_type": SignalType.INTENT,
        "source": "g2_crowd",
        "score": 0.80,
        "occurred_at": _dt(2025, 3, 10),
        "payload": {
            "category": "Revenue Intelligence",
            "profile_views_30d": 47,
            "competitor_also_viewed": ["Salesforce", "HubSpot"],
        },
    },
    {
        "account_ext": "acc-postman",
        "signal_type": SignalType.HIRING,
        "source": "linkedin_jobs",
        "score": 0.68,
        "occurred_at": _dt(2025, 2, 28),
        "payload": {
            "job_title": "Growth Marketing Manager",
            "department": "Marketing",
            "open_roles_count": 5,
            "job_url": "https://postman.com/careers/growth-marketing",
        },
    },
    {
        "account_ext": "acc-snyk",
        "signal_type": SignalType.TECHNOGRAPHIC,
        "source": "securityscorecard",
        "score": 0.45,
        "occurred_at": _dt(2025, 1, 5),
        "payload": {
            "compliance_achieved": "SOC 2 Type II",
            "security_rating": "A",
            "previous_rating": "B+",
        },
    },
    {
        "account_ext": "acc-launchdarkly",
        "signal_type": SignalType.WEB_ACTIVITY,
        "source": "clearbit_reveal",
        "score": 0.73,
        "occurred_at": _dt(2025, 3, 14),
        "payload": {
            "pages_visited": ["/pricing", "/enterprise/contact-sales"],
            "session_count_7d": 9,
            "form_started": True,
        },
    },
    {
        "account_ext": "acc-contentful",
        "signal_type": SignalType.NEWS,
        "source": "google_news",
        "score": 0.50,
        "occurred_at": _dt(2025, 2, 8),
        "payload": {
            "headline": "Contentful unveils enterprise content operations suite at ContentCon 2025",
            "url": "https://contentful.com/blog/contentcon-2025-enterprise",
            "sentiment": "positive",
        },
    },
]


# ---------------------------------------------------------------------------
# Tenant 2 — Velocity Sales  (HR-Tech / people-ops buyer)
# ---------------------------------------------------------------------------

_T2_ICP = dict(
    name="Growth-Stage HR-Tech Platforms",
    description=(
        "HR software companies ranging from ATS and performance management "
        "to payroll and HRIS that are actively expanding their sales teams "
        "and investing in outbound revenue capacity."
    ),
    firmographic_criteria={
        "industries": ["HR Technology", "Payroll", "Recruiting Software", "Employee Engagement"],
        "employee_count": {"min": 100, "max": 2000},
        "arr_usd": {"min": 8_000_000, "max": 300_000_000},
        "funding_stages": ["Series A", "Series B", "Series C", "Series D", "Series E", "Series F"],
        "geographies": ["USA", "Australia", "Germany", "Canada", "UK"],
    },
    technographic_criteria={
        "must_use_one_of": ["Salesforce", "HubSpot", "Outreach", "Salesloft"],
        "nice_to_have": ["Snowflake", "Looker", "Workato"],
        "disqualifiers": [],
    },
    persona_criteria={
        "target_titles": [
            "VP of Sales", "Chief Revenue Officer", "VP of Revenue",
            "Head of Sales", "VP of Customer Success",
        ],
        "seniority_levels": ["VP", "C-Suite", "Director"],
        "departments": ["Sales", "Revenue", "Customer Success"],
    },
    signal_weights={
        "funding": 0.85,
        "hiring": 0.80,
        "job_change": 0.75,
        "intent": 0.70,
        "web_activity": 0.65,
        "news": 0.45,
        "technographic": 0.40,
    },
)

_T2_ACCOUNTS = [
    {
        "ext": "acc-lattice",
        "fit": 0.92,
        "attrs": {
            "company_name": "Lattice",
            "industry": "Performance Management",
            "employee_count": 510,
            "arr_usd": 62_000_000,
            "funding_stage": "Series E",
            "website": "https://lattice.com",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Salesforce", "React", "PostgreSQL"],
        },
        "contacts": [
            {
                "ext": "con-lattice-001",
                "attrs": {
                    "first_name": "Jennifer", "last_name": "Nguyen",
                    "email": "j.nguyen@lattice.com",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/jennifer-nguyen-lattice",
                },
            },
            {
                "ext": "con-lattice-002",
                "attrs": {
                    "first_name": "Michael", "last_name": "Tanaka",
                    "email": "m.tanaka@lattice.com",
                    "job_title": "Head of Sales Development", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/michael-tanaka-lattice",
                },
            },
        ],
    },
    {
        "ext": "acc-cultureamp",
        "fit": 0.89,
        "attrs": {
            "company_name": "Culture Amp",
            "industry": "Employee Feedback",
            "employee_count": 620,
            "arr_usd": 78_000_000,
            "funding_stage": "Series F",
            "website": "https://cultureamp.com",
            "hq_city": "Melbourne",
            "hq_country": "Australia",
            "technologies_used": ["AWS", "HubSpot", "Salesforce", "Python"],
        },
        "contacts": [
            {
                "ext": "con-cultureamp-001",
                "attrs": {
                    "first_name": "Olivia", "last_name": "Mitchell",
                    "email": "o.mitchell@cultureamp.com",
                    "job_title": "Chief Revenue Officer", "seniority": "C-Suite",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/olivia-mitchell-ca",
                },
            },
            {
                "ext": "con-cultureamp-002",
                "attrs": {
                    "first_name": "David", "last_name": "Thompson",
                    "email": "d.thompson@cultureamp.com",
                    "job_title": "VP of Enterprise Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/david-thompson-ca",
                },
            },
        ],
    },
    {
        "ext": "acc-leapsome",
        "fit": 0.81,
        "attrs": {
            "company_name": "Leapsome",
            "industry": "HR Platform",
            "employee_count": 135,
            "arr_usd": 12_000_000,
            "funding_stage": "Series A",
            "website": "https://leapsome.com",
            "hq_city": "Berlin",
            "hq_country": "Germany",
            "technologies_used": ["GCP", "HubSpot", "React", "PostgreSQL"],
        },
        "contacts": [
            {
                "ext": "con-leapsome-001",
                "attrs": {
                    "first_name": "Lena", "last_name": "Braun",
                    "email": "l.braun@leapsome.com",
                    "job_title": "VP of Revenue", "seniority": "VP",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/lena-braun-leapsome",
                },
            },
            {
                "ext": "con-leapsome-002",
                "attrs": {
                    "first_name": "Felix", "last_name": "Wagner",
                    "email": "f.wagner@leapsome.com",
                    "job_title": "Head of Sales", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/felix-wagner-leapsome",
                },
            },
        ],
    },
    {
        "ext": "acc-15five",
        "fit": 0.83,
        "attrs": {
            "company_name": "15Five",
            "industry": "Employee Engagement",
            "employee_count": 215,
            "arr_usd": 27_000_000,
            "funding_stage": "Series C",
            "website": "https://15five.com",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Salesforce", "Outreach", "React"],
        },
        "contacts": [
            {
                "ext": "con-15five-001",
                "attrs": {
                    "first_name": "Nicole", "last_name": "Stevens",
                    "email": "n.stevens@15five.com",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/nicole-stevens-15five",
                },
            },
            {
                "ext": "con-15five-002",
                "attrs": {
                    "first_name": "Patrick", "last_name": "O'Brien",
                    "email": "p.obrien@15five.com",
                    "job_title": "Director of Revenue Operations", "seniority": "Director",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/patrick-obrien-15five",
                },
            },
        ],
    },
    {
        "ext": "acc-workleap",
        "fit": 0.80,
        "attrs": {
            "company_name": "Workleap",
            "industry": "Employee Experience",
            "employee_count": 165,
            "arr_usd": 17_000_000,
            "funding_stage": "Series B",
            "website": "https://workleap.com",
            "hq_city": "Montreal",
            "hq_country": "Canada",
            "technologies_used": ["AWS", "HubSpot", "Vue.js", "MySQL"],
        },
        "contacts": [
            {
                "ext": "con-workleap-001",
                "attrs": {
                    "first_name": "Marie", "last_name": "Tremblay",
                    "email": "m.tremblay@workleap.com",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/marie-tremblay-workleap",
                },
            },
            {
                "ext": "con-workleap-002",
                "attrs": {
                    "first_name": "Sam", "last_name": "Greer",
                    "email": "s.greer@workleap.com",
                    "job_title": "Head of Revenue", "seniority": "Director",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/sam-greer-workleap",
                },
            },
        ],
    },
    {
        "ext": "acc-rippling",
        "fit": 0.94,
        "attrs": {
            "company_name": "Rippling",
            "industry": "HR & IT Management",
            "employee_count": 1600,
            "arr_usd": 265_000_000,
            "funding_stage": "Series E",
            "website": "https://rippling.com",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Salesforce", "Snowflake", "Python", "Go"],
        },
        "contacts": [
            {
                "ext": "con-rippling-001",
                "attrs": {
                    "first_name": "Tanya", "last_name": "Goldstein",
                    "email": "t.goldstein@rippling.com",
                    "job_title": "SVP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/tanya-goldstein-rippling",
                },
            },
            {
                "ext": "con-rippling-002",
                "attrs": {
                    "first_name": "Chris", "last_name": "Nakamura",
                    "email": "c.nakamura@rippling.com",
                    "job_title": "VP of Mid-Market Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/chris-nakamura-rippling",
                },
            },
        ],
    },
    {
        "ext": "acc-greenhouse",
        "fit": 0.87,
        "attrs": {
            "company_name": "Greenhouse",
            "industry": "Applicant Tracking",
            "employee_count": 770,
            "arr_usd": 105_000_000,
            "funding_stage": "Series E",
            "website": "https://greenhouse.io",
            "hq_city": "New York",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Salesforce", "Looker", "Ruby on Rails"],
        },
        "contacts": [
            {
                "ext": "con-greenhouse-001",
                "attrs": {
                    "first_name": "Amanda", "last_name": "Clarke",
                    "email": "a.clarke@greenhouse.io",
                    "job_title": "Chief Revenue Officer", "seniority": "C-Suite",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/amanda-clarke-greenhouse",
                },
            },
            {
                "ext": "con-greenhouse-002",
                "attrs": {
                    "first_name": "Robert", "last_name": "Osei",
                    "email": "r.osei@greenhouse.io",
                    "job_title": "VP of Enterprise Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/robert-osei-greenhouse",
                },
            },
        ],
    },
    {
        "ext": "acc-lever",
        "fit": 0.84,
        "attrs": {
            "company_name": "Lever",
            "industry": "Recruiting Software",
            "employee_count": 360,
            "arr_usd": 48_000_000,
            "funding_stage": "Series D",
            "website": "https://lever.co",
            "hq_city": "San Francisco",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Salesforce", "Outreach", "React", "Node.js"],
        },
        "contacts": [
            {
                "ext": "con-lever-001",
                "attrs": {
                    "first_name": "Hannah", "last_name": "Scott",
                    "email": "h.scott@lever.co",
                    "job_title": "VP of Sales", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/hannah-scott-lever",
                },
            },
            {
                "ext": "con-lever-002",
                "attrs": {
                    "first_name": "Troy", "last_name": "Adams",
                    "email": "t.adams@lever.co",
                    "job_title": "Director of Sales Development", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/troy-adams-lever",
                },
            },
        ],
    },
    {
        "ext": "acc-gusto",
        "fit": 0.90,
        "attrs": {
            "company_name": "Gusto",
            "industry": "Payroll & Benefits",
            "employee_count": 1850,
            "arr_usd": 215_000_000,
            "funding_stage": "Series E",
            "website": "https://gusto.com",
            "hq_city": "Denver",
            "hq_country": "USA",
            "technologies_used": ["AWS", "Salesforce", "Snowflake", "Ruby on Rails", "React"],
        },
        "contacts": [
            {
                "ext": "con-gusto-001",
                "attrs": {
                    "first_name": "Maria", "last_name": "Gonzalez",
                    "email": "m.gonzalez@gusto.com",
                    "job_title": "VP of Revenue", "seniority": "VP",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/maria-gonzalez-gusto",
                },
            },
            {
                "ext": "con-gusto-002",
                "attrs": {
                    "first_name": "Eric", "last_name": "Lundberg",
                    "email": "e.lundberg@gusto.com",
                    "job_title": "Head of SMB Sales", "seniority": "Director",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/eric-lundberg-gusto",
                },
            },
        ],
    },
    {
        "ext": "acc-personio",
        "fit": 0.86,
        "attrs": {
            "company_name": "Personio",
            "industry": "HR Software",
            "employee_count": 720,
            "arr_usd": 95_000_000,
            "funding_stage": "Series E",
            "website": "https://personio.com",
            "hq_city": "Munich",
            "hq_country": "Germany",
            "technologies_used": ["AWS", "Salesforce", "Looker", "PHP", "React"],
        },
        "contacts": [
            {
                "ext": "con-personio-001",
                "attrs": {
                    "first_name": "Klaus", "last_name": "Mueller",
                    "email": "k.mueller@personio.com",
                    "job_title": "Chief Revenue Officer", "seniority": "C-Suite",
                    "department": "Revenue",
                    "linkedin_url": "https://linkedin.com/in/klaus-mueller-personio",
                },
            },
            {
                "ext": "con-personio-002",
                "attrs": {
                    "first_name": "Anna", "last_name": "Weber",
                    "email": "a.weber@personio.com",
                    "job_title": "VP of Sales DACH", "seniority": "VP",
                    "department": "Sales",
                    "linkedin_url": "https://linkedin.com/in/anna-weber-personio",
                },
            },
        ],
    },
]

_T2_SIGNALS = [
    {
        "account_ext": "acc-lattice",
        "signal_type": SignalType.FUNDING,
        "source": "crunchbase",
        "score": 0.93,
        "occurred_at": _dt(2025, 1, 22),
        "payload": {
            "round": "Series E",
            "amount_usd": 175_000_000,
            "lead_investor": "Tiger Global",
            "announcement_url": "https://techcrunch.com/lattice-series-e",
        },
    },
    {
        "account_ext": "acc-cultureamp",
        "signal_type": SignalType.HIRING,
        "source": "linkedin_jobs",
        "score": 0.76,
        "occurred_at": _dt(2025, 2, 5),
        "payload": {
            "job_title": "Senior Account Executive — North America",
            "department": "Sales",
            "open_roles_count": 15,
            "locations": ["San Francisco", "New York", "Austin"],
        },
    },
    {
        "account_ext": "acc-personio",
        "signal_type": SignalType.INTENT,
        "source": "bombora",
        "score": 0.79,
        "occurred_at": _dt(2025, 2, 19),
        "payload": {
            "topic": "Sales Enablement Platforms",
            "surge_score": 79,
            "week_over_week_change": "+28%",
        },
    },
    {
        "account_ext": "acc-greenhouse",
        "signal_type": SignalType.NEWS,
        "source": "google_news",
        "score": 0.52,
        "occurred_at": _dt(2025, 1, 30),
        "payload": {
            "headline": "Greenhouse launches AI-powered interview scoring for enterprise ATS customers",
            "url": "https://greenhouse.io/blog/ai-interview-scoring",
            "sentiment": "positive",
        },
    },
    {
        "account_ext": "acc-rippling",
        "signal_type": SignalType.FUNDING,
        "source": "crunchbase",
        "score": 0.96,
        "occurred_at": _dt(2025, 3, 8),
        "payload": {
            "round": "Series F",
            "amount_usd": 500_000_000,
            "lead_investor": "Coatue",
            "announcement_url": "https://techcrunch.com/rippling-series-f",
        },
    },
    {
        "account_ext": "acc-gusto",
        "signal_type": SignalType.HIRING,
        "source": "linkedin_jobs",
        "score": 0.74,
        "occurred_at": _dt(2025, 2, 25),
        "payload": {
            "job_title": "Senior Software Engineer — Payroll Platform",
            "department": "Engineering",
            "open_roles_count": 22,
            "locations": ["Denver", "San Francisco", "Remote"],
        },
    },
    {
        "account_ext": "acc-15five",
        "signal_type": SignalType.TECHNOGRAPHIC,
        "source": "builtwith",
        "score": 0.58,
        "occurred_at": _dt(2025, 1, 12),
        "payload": {
            "integration_added": "Workday HRIS",
            "category": "HRIS Connector",
            "detected_at": "2025-01-12",
        },
    },
    {
        "account_ext": "acc-leapsome",
        "signal_type": SignalType.WEB_ACTIVITY,
        "source": "clearbit_reveal",
        "score": 0.67,
        "occurred_at": _dt(2025, 2, 24),
        "payload": {
            "pages_visited": ["/pricing", "/demo", "/customers/enterprise"],
            "session_count_7d": 11,
            "form_submitted": "demo-request",
        },
    },
    {
        "account_ext": "acc-lever",
        "signal_type": SignalType.JOB_CHANGE,
        "source": "linkedin_alerts",
        "score": 0.71,
        "occurred_at": _dt(2025, 1, 25),
        "payload": {
            "person_name": "Hannah Scott",
            "previous_company": "Workday",
            "previous_title": "Regional Sales Director",
            "new_title": "VP of Sales",
            "started_date": "2025-01-20",
        },
    },
    {
        "account_ext": "acc-workleap",
        "signal_type": SignalType.FUNDING,
        "source": "crunchbase",
        "score": 0.85,
        "occurred_at": _dt(2025, 2, 14),
        "payload": {
            "round": "Series B",
            "amount_usd": 50_000_000,
            "lead_investor": "Inovia Capital",
            "announcement_url": "https://techcrunch.com/workleap-series-b",
        },
    },
    {
        "account_ext": "acc-lattice",
        "signal_type": SignalType.INTENT,
        "source": "g2_crowd",
        "score": 0.77,
        "occurred_at": _dt(2025, 3, 12),
        "payload": {
            "category": "Performance Management Software",
            "profile_views_30d": 63,
            "competitor_also_viewed": ["Culture Amp", "15Five", "Leapsome"],
        },
    },
    {
        "account_ext": "acc-cultureamp",
        "signal_type": SignalType.HIRING,
        "source": "linkedin_jobs",
        "score": 0.69,
        "occurred_at": _dt(2025, 3, 3),
        "payload": {
            "job_title": "People Analytics Lead",
            "department": "Product",
            "open_roles_count": 4,
            "locations": ["Melbourne", "San Francisco"],
        },
    },
    {
        "account_ext": "acc-personio",
        "signal_type": SignalType.NEWS,
        "source": "google_news",
        "score": 0.56,
        "occurred_at": _dt(2025, 2, 10),
        "payload": {
            "headline": "Personio expands to UK and Ireland with dedicated sales and support teams",
            "url": "https://personio.com/blog/uk-ireland-expansion",
            "sentiment": "positive",
        },
    },
    {
        "account_ext": "acc-greenhouse",
        "signal_type": SignalType.HIRING,
        "source": "linkedin_jobs",
        "score": 0.71,
        "occurred_at": _dt(2025, 3, 6),
        "payload": {
            "job_title": "Enterprise Account Executive",
            "department": "Sales",
            "open_roles_count": 10,
            "locations": ["New York", "Chicago", "San Francisco"],
        },
    },
    {
        "account_ext": "acc-rippling",
        "signal_type": SignalType.WEB_ACTIVITY,
        "source": "clearbit_reveal",
        "score": 0.64,
        "occurred_at": _dt(2025, 3, 15),
        "payload": {
            "pages_visited": ["/platform/sales-enablement", "/pricing/enterprise"],
            "session_count_7d": 7,
            "avg_session_duration_sec": 285,
        },
    },
]


# ---------------------------------------------------------------------------
# Core seed logic
# ---------------------------------------------------------------------------

async def _seed_tenant(
    engine,
    tenant_id: uuid.UUID,
    account_od_id: uuid.UUID,
    contact_od_id: uuid.UUID,
    icp_kwargs: dict,
    accounts: list[dict],
    signals: list[dict],
) -> None:
    """Insert all data for one tenant within a single transaction."""
    async with AsyncSession(engine, expire_on_commit=False) as session:
        async with session.begin():
            await session.execute(
                text("SELECT set_current_tenant(:tid)"),
                {"tid": str(tenant_id)},
            )

            # ObjectDefinitions
            account_od = ObjectDefinition(
                id=account_od_id,
                tenant_id=tenant_id,
                name="Account",
                slug="account",
                schema_definition=_ACCOUNT_SCHEMA,
            )
            contact_od = ObjectDefinition(
                id=contact_od_id,
                tenant_id=tenant_id,
                name="Contact",
                slug="contact",
                schema_definition=_CONTACT_SCHEMA,
            )
            session.add_all([account_od, contact_od])

            # ICP
            session.add(ICP(tenant_id=tenant_id, **icp_kwargs))

            # Accounts + contacts + relationships
            ext_to_record_id: dict[str, uuid.UUID] = {}
            for acc in accounts:
                acc_id = uuid.uuid4()
                ext_to_record_id[acc["ext"]] = acc_id
                session.add(
                    Record(
                        id=acc_id,
                        tenant_id=tenant_id,
                        object_definition_id=account_od_id,
                        external_id=acc["ext"],
                        attributes=acc["attrs"],
                        fit_score=acc.get("fit"),
                        enrichment_status=EnrichmentStatus.ENRICHED.value,
                    )
                )
                for contact in acc["contacts"]:
                    con_id = uuid.uuid4()
                    ext_to_record_id[contact["ext"]] = con_id
                    session.add(
                        Record(
                            id=con_id,
                            tenant_id=tenant_id,
                            object_definition_id=contact_od_id,
                            external_id=contact["ext"],
                            attributes=contact["attrs"],
                            enrichment_status=EnrichmentStatus.ENRICHED.value,
                        )
                    )
                    session.add(
                        RecordRelationship(
                            tenant_id=tenant_id,
                            from_record_id=con_id,
                            to_record_id=acc_id,
                            relationship_type="works_at",
                            attributes={},
                        )
                    )

            # Signals (reference accounts by external_id key)
            for sig in signals:
                record_id = ext_to_record_id[sig["account_ext"]]
                session.add(
                    Signal(
                        tenant_id=tenant_id,
                        record_id=record_id,
                        signal_type=sig["signal_type"],
                        source=sig["source"],
                        score=sig["score"],
                        occurred_at=sig["occurred_at"],
                        payload=sig["payload"],
                    )
                )


async def _seed_hunter_connection(
    engine,
    tenant_id: uuid.UUID,
    api_key: str,
) -> None:
    """Upsert a Hunter.io IntegrationConnection for a tenant.

    Creates a new connection if none exists; updates credentials on an existing
    one so re-running the seed with a corrected HUNTER_API_KEY takes effect.
    Skips silently when api_key is empty so seeds without credentials don't fail.
    """
    if not api_key:
        print(
            f"  HUNTER_API_KEY not set — skipping Hunter connection for tenant {tenant_id}.",
            flush=True,
        )
        return

    async with AsyncSession(engine, expire_on_commit=False) as session:
        async with session.begin():
            await session.execute(
                text("SELECT set_config('app.current_tenant', :tid, TRUE)"),
                {"tid": str(tenant_id)},
            )
            existing_res = await session.execute(
                select(IntegrationConnection)
                .where(
                    IntegrationConnection.tenant_id == tenant_id,
                    IntegrationConnection.provider_slug == "hunter",
                )
                .limit(1)
            )
            existing = existing_res.scalar_one_or_none()
            encrypted = encrypt_credentials({"api_key": api_key})

            if existing is not None:
                existing.credentials = encrypted
                existing.is_active = True  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
            else:
                session.add(
                    IntegrationConnection(
                        tenant_id=tenant_id,
                        provider_slug="hunter",
                        display_name="Hunter (default)",
                        credentials=encrypted,
                        is_active=True,  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
                    )
                )


async def main() -> None:
    if not settings.SEED_ENABLED:
        print("Seed data disabled (SEED_ENABLED=false). Skipping.", flush=True)
        return

    engine = create_async_engine(settings.DATABASE_URL, echo=False)
    hunter_api_key = os.getenv("HUNTER_API_KEY", "").strip()

    # Idempotency check — verify the seed is COMPLETE, not just started.
    # A previous run may have committed tenants but failed before committing
    # ICPs/records (they live in a separate transaction in _seed_tenant).
    async with AsyncSession(engine) as session:
        tenant_count = (
            await session.execute(text("SELECT count(*) FROM tenants"))
        ).scalar() or 0

        if tenant_count > 0:
            # Tenants exist — check whether ICP data was also seeded by
            # setting the first tenant's RLS context and querying icps.
            all_tids = list(
                (
                    await session.execute(
                        text("SELECT id FROM tenants ORDER BY created_at")
                    )
                ).scalars()
            )
            first_tid = all_tids[0] if all_tids else None

            icp_count = 0
            if first_tid:
                await session.execute(
                    text("SELECT set_config('app.current_tenant', :tid, TRUE)"),
                    {"tid": str(first_tid)},
                )
                icp_count = (
                    await session.execute(text("SELECT count(*) FROM icps"))
                ).scalar() or 0

            if icp_count > 0:
                # Main data already present — seed Hunter connections idempotently
                # so that re-runs with HUNTER_API_KEY set pick up the credential.
                for tid in all_tids:
                    await _seed_hunter_connection(engine, uuid.UUID(str(tid)), hunter_api_key)
                print("Seed data already present. Hunter connections checked.", flush=True)
                await engine.dispose()
                return

            # Partial seed detected: tenants committed but ICPs/records were
            # rolled back by a previous failed run.  Wipe tenant rows
            # (FKs cascade-delete all tenant-scoped data) and reseed fresh.
            print(
                "Partial seed detected (tenants exist but no ICPs). "
                "Wiping tenant rows and reseeding…",
                flush=True,
            )
            await session.execute(text("DELETE FROM tenants"))
            await session.commit()

    # Pre-allocate IDs so tenants can be inserted without an RLS context
    # (tenants table has no tenant_id column, no RLS policy).
    t1_id = uuid.uuid4()
    t2_id = uuid.uuid4()
    t1_acc_od_id = uuid.uuid4()
    t1_con_od_id = uuid.uuid4()
    t2_acc_od_id = uuid.uuid4()
    t2_con_od_id = uuid.uuid4()

    async with AsyncSession(engine) as session:
        async with session.begin():
            session.add(
                Tenant(
                    id=t1_id,
                    name="Acme GTM",
                    slug="acme-gtm",
                    admin_email="admin@acme-gtm.com",
                    admin_password_hash=hash_password("demo1234"),
                    settings={"theme": "indigo", "trial_ends": "2025-06-01"},
                )
            )
            session.add(
                Tenant(
                    id=t2_id,
                    name="Velocity Sales",
                    slug="velocity-sales",
                    admin_email="admin@velocity-sales.com",
                    admin_password_hash=hash_password("demo1234"),
                    settings={"theme": "emerald", "trial_ends": "2025-07-01"},
                )
            )

    print("Tenants created.", flush=True)

    await _seed_tenant(
        engine,
        tenant_id=t1_id,
        account_od_id=t1_acc_od_id,
        contact_od_id=t1_con_od_id,
        icp_kwargs=_T1_ICP,
        accounts=_T1_ACCOUNTS,
        signals=_T1_SIGNALS,
    )
    await _seed_hunter_connection(engine, t1_id, hunter_api_key)
    print("Tenant 1 (Acme GTM) seeded: 10 accounts, 20 contacts, 15 signals.", flush=True)

    await _seed_tenant(
        engine,
        tenant_id=t2_id,
        account_od_id=t2_acc_od_id,
        contact_od_id=t2_con_od_id,
        icp_kwargs=_T2_ICP,
        accounts=_T2_ACCOUNTS,
        signals=_T2_SIGNALS,
    )
    await _seed_hunter_connection(engine, t2_id, hunter_api_key)
    print("Tenant 2 (Velocity Sales) seeded: 10 accounts, 20 contacts, 15 signals.", flush=True)

    await engine.dispose()
    print("Seed complete.", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
