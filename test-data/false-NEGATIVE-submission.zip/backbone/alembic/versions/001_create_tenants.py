"""Create tenants table, RLS helper functions, and auto-RLS event trigger.

Revision ID: 001
Revises:
Create Date: 2025-01-01 00:00:00.000000

This migration is designed to be fully self-contained so it can run against
any PostgreSQL 16 instance, not just one initialised by infra/postgres/init.sql.

Everything created here uses CREATE OR REPLACE / DROP IF EXISTS so the
migration is idempotent whether init.sql has already run or not.

RLS architecture
----------------
Row-level security is enforced through a PostgreSQL event trigger
(gtm_auto_tenant_rls_trigger) that fires immediately after every CREATE TABLE
statement.  If the new table contains a tenant_id column the trigger:

  1. Enables RLS on the table
  2. Forces RLS even for the table owner (prevents accidental bypass)
  3. Creates a single permissive policy that gates every operation:
       USING  (tenant_id = current_tenant_id())   ← SELECT/UPDATE/DELETE
       WITH CHECK (tenant_id = current_tenant_id()) ← INSERT/UPDATE

The application sets the active tenant per-transaction via:
  SELECT set_current_tenant('<uuid>');

This means:
  • Application code never needs WHERE tenant_id = ?  (CLAUDE.md rule #2)
  • Cross-tenant leakage is impossible even if the application has a bug
  • Tests that need to verify isolation can do so by switching tenant context

Tenants table itself has no tenant_id column, so it is intentionally excluded
from RLS (it IS the tenant root, not a tenant-scoped resource).
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql as pg

revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# SQL for the two context helpers — identical to infra/postgres/init.sql so
# that CREATE OR REPLACE makes both paths idempotent.
_SQL_FN_CURRENT_TENANT_ID = """
CREATE OR REPLACE FUNCTION current_tenant_id()
RETURNS UUID
LANGUAGE plpgsql STABLE AS $fn$
BEGIN
    RETURN NULLIF(current_setting('app.current_tenant', TRUE), '')::UUID;
EXCEPTION
    WHEN invalid_text_representation THEN
        RETURN NULL;
END;
$fn$
"""

_SQL_FN_SET_CURRENT_TENANT = """
CREATE OR REPLACE FUNCTION set_current_tenant(p_tenant_id TEXT)
RETURNS VOID
LANGUAGE plpgsql AS $fn$
BEGIN
    PERFORM set_config('app.current_tenant', p_tenant_id, TRUE);
END;
$fn$
"""

# Event trigger: auto-applies RLS to any table created with a tenant_id column.
_SQL_FN_AUTO_RLS = """
CREATE OR REPLACE FUNCTION gtm_auto_tenant_rls()
RETURNS event_trigger
LANGUAGE plpgsql AS $fn$
DECLARE
    obj        RECORD;
    tbl_schema TEXT;
    tbl_name   TEXT;
BEGIN
    FOR obj IN
        SELECT *
        FROM   pg_event_trigger_ddl_commands()
        WHERE  command_tag = 'CREATE TABLE'
        AND    object_type = 'table'
    LOOP
        SELECT n.nspname, c.relname
        INTO   tbl_schema, tbl_name
        FROM   pg_class     c
        JOIN   pg_namespace n ON n.oid = c.relnamespace
        WHERE  c.oid = obj.objid;

        IF tbl_schema = 'public'
        AND EXISTS (
            SELECT 1
            FROM   pg_attribute a
            WHERE  a.attrelid    = obj.objid
            AND    a.attname     = 'tenant_id'
            AND    a.attnum      > 0
            AND    NOT a.attisdropped
        ) THEN
            EXECUTE format(
                'ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY',
                tbl_schema, tbl_name
            );
            EXECUTE format(
                'ALTER TABLE %I.%I FORCE ROW LEVEL SECURITY',
                tbl_schema, tbl_name
            );
            EXECUTE format(
                'CREATE POLICY tenant_isolation ON %I.%I'
                '  AS PERMISSIVE FOR ALL TO PUBLIC'
                '  USING     (tenant_id = current_tenant_id())'
                '  WITH CHECK (tenant_id = current_tenant_id())',
                tbl_schema, tbl_name
            );
        END IF;
    END LOOP;
END;
$fn$
"""


def upgrade() -> None:
    # ------------------------------------------------------------------
    # Helper functions (CREATE OR REPLACE — idempotent with init.sql)
    # ------------------------------------------------------------------
    op.execute(_SQL_FN_CURRENT_TENANT_ID)
    op.execute(_SQL_FN_SET_CURRENT_TENANT)

    # ------------------------------------------------------------------
    # Event trigger (DROP IF EXISTS + CREATE — event triggers have no
    # OR REPLACE syntax in PostgreSQL 16)
    # ------------------------------------------------------------------
    op.execute(_SQL_FN_AUTO_RLS)
    op.execute("DROP EVENT TRIGGER IF EXISTS gtm_auto_tenant_rls_trigger")
    op.execute(
        "CREATE EVENT TRIGGER gtm_auto_tenant_rls_trigger"
        "    ON ddl_command_end"
        "    WHEN TAG IN ('CREATE TABLE')"
        "    EXECUTE FUNCTION gtm_auto_tenant_rls()"
    )

    # ------------------------------------------------------------------
    # tenants
    # No tenant_id column → event trigger does NOT apply RLS here.
    # Tenants are resolved during authentication, before any RLS context
    # is set, so the application connects without a tenant filter.
    # ------------------------------------------------------------------
    op.create_table(
        "tenants",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("slug", sa.String(63), nullable=False),
        sa.Column(
            "settings",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "is_active",
            sa.Boolean(),
            server_default=sa.text("true"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    )
    op.create_index("ix_tenants_slug", "tenants", ["slug"], unique=True)


def downgrade() -> None:
    op.drop_index("ix_tenants_slug", table_name="tenants")
    op.drop_table("tenants")
    op.execute("DROP EVENT TRIGGER IF EXISTS gtm_auto_tenant_rls_trigger")
    op.execute("DROP FUNCTION IF EXISTS gtm_auto_tenant_rls()")
    op.execute("DROP FUNCTION IF EXISTS set_current_tenant(TEXT)")
    op.execute("DROP FUNCTION IF EXISTS current_tenant_id()")
