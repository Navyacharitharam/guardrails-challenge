"""Create agent execution tables: AgentRun, AgentStep, HumanReview, Activity.

Revision ID: 003
Revises: 002
Create Date: 2025-01-01 00:02:00.000000

Activity is included here (not in 002) because it carries an optional FK
to agent_runs, which only exists after this migration runs.

Creation order:
  agent_runs → agent_steps → human_reviews → activities

RLS is applied automatically by the gtm_auto_tenant_rls_trigger event trigger
installed in migration 001 (and infra/postgres/init.sql).  No explicit
_enable_rls() calls are needed here.  The downgrade path disables RLS
explicitly before each DROP TABLE.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql as pg

revision: str = "003"
down_revision: Union[str, None] = "002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Enum valid values (VARCHAR storage — matches backbone/models/enums.py)
_AGENT_RUN_STATUS = ("queued", "running", "completed", "failed", "cancelled")
_AGENT_STEP_TYPE = ("tool_call", "llm_call", "human_gate", "error")
_AGENT_STEP_STATUS = ("pending", "running", "completed", "failed", "retried")
_HUMAN_REVIEW_TYPE = (
    "hypothesis_approval",
    "outreach_approval",
    "enrichment_validation",
)
_HUMAN_REVIEW_STATUS = ("pending", "approved", "rejected", "modified")


def _disable_rls(table: str) -> None:
    op.execute(sa.text(f"DROP POLICY IF EXISTS tenant_isolation ON {table}"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
    op.execute(sa.text(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text


def upgrade() -> None:
    # ------------------------------------------------------------------
    # agent_runs
    # ------------------------------------------------------------------
    op.create_table(
        "agent_runs",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("workflow_type", sa.String(63), nullable=False),
        sa.Column(
            "status",
            sa.String(9),
            server_default="queued",
            nullable=False,
        ),
        sa.Column(
            "icp_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("icps.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column(
            "input_payload",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column("output_payload", pg.JSONB(), nullable=True),
        sa.Column("error_message", sa.String(2048), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint(
            f"status IN {_AGENT_RUN_STATUS}",
            name="ck_agent_runs_status",
        ),
    )
    op.create_index("ix_agent_runs_tenant_id", "agent_runs", ["tenant_id"])
    op.create_index("ix_agent_runs_workflow_type", "agent_runs", ["workflow_type"])
    op.create_index(
        "ix_agent_runs_tenant_status", "agent_runs", ["tenant_id", "status"]
    )
    op.create_index(
        "ix_agent_runs_tenant_created", "agent_runs", ["tenant_id", "created_at"]
    )

    # ------------------------------------------------------------------
    # agent_steps
    # ------------------------------------------------------------------
    op.create_table(
        "agent_steps",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "run_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("agent_runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("step_number", sa.Integer(), nullable=False),
        sa.Column("step_type", sa.String(10), nullable=False),
        sa.Column("tool_name", sa.String(63), nullable=True),
        sa.Column("reasoning", sa.Text(), nullable=True),
        sa.Column(
            "input_payload",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column("output_payload", pg.JSONB(), nullable=True),
        sa.Column(
            "status",
            sa.String(9),
            server_default="pending",
            nullable=False,
        ),
        sa.Column("error_message", sa.String(2048), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.Column(
            "started_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint(
            f"step_type IN {_AGENT_STEP_TYPE}",
            name="ck_agent_steps_step_type",
        ),
        sa.CheckConstraint(
            f"status IN {_AGENT_STEP_STATUS}",
            name="ck_agent_steps_status",
        ),
    )
    op.create_index("ix_agent_steps_tenant_id", "agent_steps", ["tenant_id"])
    op.create_index(
        "ix_agent_steps_tenant_run", "agent_steps", ["tenant_id", "run_id"]
    )
    op.create_index(
        "ix_agent_steps_run_number", "agent_steps", ["run_id", "step_number"]
    )

    # ------------------------------------------------------------------
    # human_reviews
    # ------------------------------------------------------------------
    op.create_table(
        "human_reviews",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "run_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("agent_runs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "step_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("agent_steps.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("review_type", sa.String(21), nullable=False),
        sa.Column(
            "proposed_output",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "context",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "status",
            sa.String(8),
            server_default="pending",
            nullable=False,
        ),
        sa.Column("reviewer_notes", sa.Text(), nullable=True),
        sa.Column("modified_output", pg.JSONB(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        # One review gate per step — enforced at DB level
        sa.UniqueConstraint("step_id", name="uq_human_reviews_step_id"),
        sa.CheckConstraint(
            f"review_type IN {_HUMAN_REVIEW_TYPE}",
            name="ck_human_reviews_review_type",
        ),
        sa.CheckConstraint(
            f"status IN {_HUMAN_REVIEW_STATUS}",
            name="ck_human_reviews_status",
        ),
    )
    op.create_index("ix_human_reviews_tenant_id", "human_reviews", ["tenant_id"])
    op.create_index(
        "ix_human_reviews_tenant_status", "human_reviews", ["tenant_id", "status"]
    )
    op.create_index(
        "ix_human_reviews_tenant_run", "human_reviews", ["tenant_id", "run_id"]
    )

    # ------------------------------------------------------------------
    # activities — created here (not 002) because agent_run_id FK
    # references agent_runs which only exists after this migration.
    # ------------------------------------------------------------------
    op.create_table(
        "activities",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        # PostgreSQL native array — one activity can involve multiple records
        sa.Column(
            "record_ids",
            pg.ARRAY(pg.UUID(as_uuid=True)),
            server_default=sa.text("ARRAY[]::uuid[]"),
            nullable=False,
        ),
        sa.Column("activity_type", sa.String(63), nullable=False),
        sa.Column(
            "payload",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "agent_run_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("agent_runs.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    )
    op.create_index("ix_activities_tenant_id", "activities", ["tenant_id"])
    op.create_index(
        "ix_activities_tenant_type", "activities", ["tenant_id", "activity_type"]
    )
    op.create_index(
        "ix_activities_tenant_run", "activities", ["tenant_id", "agent_run_id"]
    )
    # GIN index for efficient ANY(record_ids) = $uuid queries
    op.execute(
        sa.text("CREATE INDEX ix_activities_record_ids_gin ON activities USING gin (record_ids)")  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
    )


def downgrade() -> None:
    _disable_rls("activities")
    op.execute(sa.text("DROP INDEX IF EXISTS ix_activities_record_ids_gin"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
    op.drop_table("activities")

    _disable_rls("human_reviews")
    op.drop_table("human_reviews")

    _disable_rls("agent_steps")
    op.drop_table("agent_steps")

    _disable_rls("agent_runs")
    op.drop_table("agent_runs")
