"""Add admin_email and admin_password_hash columns to tenants.

Revision ID: 005
Revises: 004
Create Date: 2025-01-01 00:04:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "005"
down_revision: Union[str, None] = "004"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "tenants",
        sa.Column(
            "admin_email",
            sa.String(255),
            nullable=False,
            server_default="admin@example.com",
        ),
    )
    op.add_column(
        "tenants",
        sa.Column(
            "admin_password_hash",
            sa.String(255),
            nullable=False,
            server_default="",
        ),
    )
    op.create_index("ix_tenants_admin_email", "tenants", ["admin_email"], unique=True)
    # Remove the server defaults now that the column exists
    op.alter_column("tenants", "admin_email", server_default=None)
    op.alter_column("tenants", "admin_password_hash", server_default=None)


def downgrade() -> None:
    op.drop_index("ix_tenants_admin_email", table_name="tenants")
    op.drop_column("tenants", "admin_password_hash")
    op.drop_column("tenants", "admin_email")
