"""Create core CRM entity tables: ObjectDefinition, ICP, Record, RecordRelationship, Signal.

Revision ID: 002
Revises: 001
Create Date: 2025-01-01 00:01:00.000000

Creation order respects FK dependencies:
  object_definitions → icps → records → record_relationships → signals

RLS is applied automatically by the gtm_auto_tenant_rls_trigger event trigger
installed in migration 001 (and in infra/postgres/init.sql).  Every CREATE TABLE
in this migration that carries a tenant_id column will have RLS enabled and a
tenant_isolation policy created by the trigger before the transaction commits.
The downgrade path disables RLS explicitly before dropping tables.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql as pg

revision: str = "002"
down_revision: Union[str, None] = "001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Enum valid values (matches backbone/models/enums.py — stored as VARCHAR)
_ENRICHMENT_STATUS = ("unenriched", "enriched", "failed")
_SIGNAL_TYPE = (
    "funding",
    "hiring",
    "job_change",
    "intent",
    "technographic",
    "news",
    "web_activity",
)


def _disable_rls(table: str) -> None:
    """Drop the tenant_isolation policy and disable RLS before table teardown."""
    op.execute(sa.text(f"DROP POLICY IF EXISTS tenant_isolation ON {table}"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
    op.execute(sa.text(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text


def upgrade() -> None:
    # ------------------------------------------------------------------
    # object_definitions
    # RLS applied automatically by event trigger (has tenant_id).
    # ------------------------------------------------------------------
    op.create_table(
        "object_definitions",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("slug", sa.String(63), nullable=False),
        sa.Column(
            "schema_definition",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.UniqueConstraint(
            "tenant_id", "slug", name="uq_object_definitions_tenant_slug"
        ),
    )
    op.create_index(
        "ix_object_definitions_tenant_id", "object_definitions", ["tenant_id"]
    )

    # ------------------------------------------------------------------
    # icps
    # ------------------------------------------------------------------
    op.create_table(
        "icps",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column(
            "description",
            sa.Text(),
            server_default=sa.text("''"),
            nullable=False,
        ),
        sa.Column(
            "firmographic_criteria",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "technographic_criteria",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "persona_criteria",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "signal_weights",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "is_active",
            sa.Boolean(),
            server_default=sa.text("true"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    )
    op.create_index("ix_icps_tenant_id", "icps", ["tenant_id"])
    op.create_index("ix_icps_is_active", "icps", ["is_active"])

    # ------------------------------------------------------------------
    # records
    # ------------------------------------------------------------------
    op.create_table(
        "records",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "object_definition_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("object_definitions.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("external_id", sa.String(255), nullable=True),
        sa.Column(
            "attributes",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column("fit_score", sa.Float(), nullable=True),
        sa.Column("intent_score", sa.Float(), nullable=True),
        sa.Column(
            "enrichment_status",
            sa.String(10),
            server_default="unenriched",
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint(
            f"enrichment_status IN {_ENRICHMENT_STATUS}",
            name="ck_records_enrichment_status",
        ),
    )
    op.create_index("ix_records_tenant_id", "records", ["tenant_id"])
    op.create_index(
        "ix_records_tenant_object",
        "records",
        ["tenant_id", "object_definition_id"],
    )
    op.create_index(
        "ix_records_tenant_external", "records", ["tenant_id", "external_id"]
    )
    op.create_index(
        "ix_records_enrichment_status", "records", ["enrichment_status"]
    )
    # GIN index: fast JSONB containment queries  attributes @> '{"industry": "SaaS"}'
    op.execute(
        sa.text("CREATE INDEX ix_records_attributes_gin ON records USING gin (attributes)")  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
    )

    # ------------------------------------------------------------------
    # record_relationships
    # ------------------------------------------------------------------
    op.create_table(
        "record_relationships",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "from_record_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("records.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "to_record_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("records.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("relationship_type", sa.String(63), nullable=False),
        sa.Column(
            "attributes",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
    )
    op.create_index(
        "ix_record_relationships_tenant_id", "record_relationships", ["tenant_id"]
    )
    op.create_index(
        "ix_record_relationships_tenant_from",
        "record_relationships",
        ["tenant_id", "from_record_id"],
    )
    op.create_index(
        "ix_record_relationships_tenant_to",
        "record_relationships",
        ["tenant_id", "to_record_id"],
    )
    op.create_index(
        "ix_record_relationships_relationship_type",
        "record_relationships",
        ["relationship_type"],
    )

    # ------------------------------------------------------------------
    # signals
    # ------------------------------------------------------------------
    op.create_table(
        "signals",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "record_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("records.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("signal_type", sa.String(13), nullable=False),
        sa.Column("source", sa.String(63), nullable=False),
        sa.Column(
            "payload",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column("score", sa.Float(), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.CheckConstraint(
            f"signal_type IN {_SIGNAL_TYPE}",
            name="ck_signals_signal_type",
        ),
    )
    op.create_index("ix_signals_tenant_id", "signals", ["tenant_id"])
    op.create_index(
        "ix_signals_tenant_record", "signals", ["tenant_id", "record_id"]
    )
    op.create_index(
        "ix_signals_tenant_type", "signals", ["tenant_id", "signal_type"]
    )
    op.create_index(
        "ix_signals_occurred_at", "signals", ["tenant_id", "occurred_at"]
    )


def downgrade() -> None:
    # Drop in reverse FK dependency order.
    # _disable_rls() explicitly removes the policy before DROP TABLE — clean
    # and self-documenting, even though DROP TABLE would cascade-drop policies.
    _disable_rls("signals")
    op.drop_table("signals")

    _disable_rls("record_relationships")
    op.drop_table("record_relationships")

    _disable_rls("records")
    op.execute(sa.text("DROP INDEX IF EXISTS ix_records_attributes_gin"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
    op.drop_table("records")

    _disable_rls("icps")
    op.drop_table("icps")

    _disable_rls("object_definitions")
    op.drop_table("object_definitions")
