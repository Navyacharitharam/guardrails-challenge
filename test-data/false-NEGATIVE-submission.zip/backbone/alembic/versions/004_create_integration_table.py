"""Create integration_connections table.

Revision ID: 004
Revises: 003
Create Date: 2025-01-01 00:03:00.000000

IntegrationConnection has no FK dependencies beyond tenants so it could
live in 002, but is isolated here to keep provider credential storage
concerns separate and to make this table easy to audit.

The ``credentials`` column is TEXT (not JSONB) because it stores a
Fernet-encrypted blob — the ciphertext is opaque to the database.
Decrypt only at the application layer via backbone.core.security.encryption.

RLS is applied automatically by the gtm_auto_tenant_rls_trigger event trigger
(installed in migration 001 and infra/postgres/init.sql).
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql as pg

revision: str = "004"
down_revision: Union[str, None] = "003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _disable_rls(table: str) -> None:
    op.execute(sa.text(f"DROP POLICY IF EXISTS tenant_isolation ON {table}"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text
    op.execute(sa.text(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY"))  # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query, python.sqlalchemy.security.audit.avoid-sqlalchemy-text.avoid-sqlalchemy-text


def upgrade() -> None:
    op.create_table(
        "integration_connections",
        sa.Column(
            "id",
            pg.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column(
            "tenant_id",
            pg.UUID(as_uuid=True),
            sa.ForeignKey("tenants.id", ondelete="CASCADE"),
            nullable=False,
        ),
        # Stable slug matching BaseIntegration.slug: "hunter", "apollo", "clearbit"
        sa.Column("provider_slug", sa.String(63), nullable=False),
        sa.Column("display_name", sa.String(255), nullable=False),
        # Fernet-encrypted JSON blob — NEVER stored as plain text (CLAUDE.md rule #5)
        sa.Column("credentials", sa.Text(), nullable=False),
        sa.Column(
            "is_active",
            sa.Boolean(),
            server_default=sa.text("true"),
            nullable=False,
        ),
        # Mutable state: {"calls_remaining": 23, "reset_at": "2025-03-01T00:00:00Z"}
        sa.Column(
            "rate_limit_state",
            pg.JSONB(),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False,
        ),
        sa.Column("last_used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        # One connection per provider per tenant
        sa.UniqueConstraint(
            "tenant_id",
            "provider_slug",
            name="uq_integration_connections_tenant_provider",
        ),
    )
    op.create_index(
        "ix_integration_connections_tenant_id",
        "integration_connections",
        ["tenant_id"],
    )
    op.create_index(
        "ix_integration_connections_tenant_active",
        "integration_connections",
        ["tenant_id", "is_active"],
    )


def downgrade() -> None:
    _disable_rls("integration_connections")
    op.drop_table("integration_connections")
