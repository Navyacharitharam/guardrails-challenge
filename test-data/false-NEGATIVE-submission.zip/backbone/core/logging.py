"""Structlog configuration for the GTM platform.

Call ``configure_logging()`` once at application startup (in ``app.py`` and
in the ARQ worker entrypoint).  After that, every module can obtain a logger
with ``structlog.get_logger(__name__)`` and the output will be formatted
consistently across the entire process.

Development mode (LOG_LEVEL=DEBUG):
  Pretty-printed, coloured console output with caller info.

Production mode (LOG_LEVEL=INFO or higher):
  JSON lines for log aggregation (Datadog, Loki, CloudWatch, etc.).
"""
import logging
import sys

import structlog

from backbone.core.config import settings


def configure_logging() -> None:
    """Initialise structlog and stdlib logging with shared processors.

    Safe to call multiple times — repeated calls are idempotent because
    ``structlog.configure`` replaces the global configuration in-place.
    """
    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
    ]

    is_development = settings.LOG_LEVEL.upper() == "DEBUG"

    if is_development:
        renderer: structlog.types.Processor = structlog.dev.ConsoleRenderer(
            colors=True,
            exception_formatter=structlog.dev.plain_traceback,
        )
    else:
        renderer = structlog.processors.JSONRenderer()

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.addHandler(handler)
    root_logger.setLevel(settings.LOG_LEVEL.upper())

    # Silence noisy third-party loggers.
    for noisy in ("uvicorn.access", "sqlalchemy.engine"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
