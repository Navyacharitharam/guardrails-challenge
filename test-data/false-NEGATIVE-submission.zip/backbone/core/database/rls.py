"""PostgreSQL Row-Level Security helpers.

The RLS approach used here:
  1. Every table that holds tenant data has a policy:
       USING (tenant_id = current_setting('app.current_tenant', TRUE)::uuid)
  2. Before any query, the application calls ``set_tenant_context(session, tenant_id)``.
  3. No WHERE tenant_id = ? ever appears in application code.

The FastAPI dependency ``require_tenant_session`` combines authentication,
tenant resolution, and RLS context-setting into a single injectable.
"""
import uuid
from typing import Any

import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

log = structlog.get_logger(__name__)


async def set_tenant_context(
    session: AsyncSession, tenant_id: uuid.UUID, *, is_local: bool = True
) -> None:
    """Set the PostgreSQL session variable that drives RLS policies.

    Must be called once per session before any tenant-scoped query.

    Args:
        session: Active async SQLAlchemy session.
        tenant_id: The UUID of the current tenant.
        is_local: When True (default), the setting resets at transaction end —
            safe for API request handlers that use connection pools.  Pass
            False for long-lived worker sessions that commit many times; the
            setting then persists for the connection lifetime.
    """
    # set_config's third argument (is_local) cannot be a bind parameter because
    # asyncpg infers it as text, not boolean. Use two static branches so the
    # query string is always a literal with no f-string interpolation.
    if is_local:
        await session.execute(
            text("SELECT set_config('app.current_tenant', :tid, TRUE)"),
            {"tid": str(tenant_id)},
        )
    else:
        await session.execute(
            text("SELECT set_config('app.current_tenant', :tid, FALSE)"),
            {"tid": str(tenant_id)},
        )


async def clear_tenant_context(session: AsyncSession) -> None:
    """Clear the tenant context (used in tests and admin operations)."""
    await session.execute(
        text("SELECT set_config('app.current_tenant', '', TRUE)")
    )
