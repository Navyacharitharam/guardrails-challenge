"""Fernet symmetric encryption for credential storage.

All IntegrationConnection credentials are stored as an encrypted blob produced
by ``encrypt_credentials`` and must be decrypted by ``decrypt_credentials``
before use.  The key is read from ``settings.FERNET_KEY`` at call time so
rotating it requires only a data-migration re-encryption pass, not a code
change.
"""
import json

from cryptography.fernet import Fernet, InvalidToken


def _fernet() -> Fernet:
    """Return a Fernet instance bound to the current FERNET_KEY."""
    from backbone.core.config import settings  # late import — keeps key hot-reloadable

    key = settings.FERNET_KEY
    if not key:
        raise RuntimeError(
            "FERNET_KEY is not set. "
            "Generate one with: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
        )
    return Fernet(key.encode() if isinstance(key, str) else key)


def encrypt_credentials(creds: dict) -> str:
    """Serialize ``creds`` to JSON and encrypt with Fernet.

    Returns the URL-safe base-64 Fernet token as a plain string suitable for
    storing in ``IntegrationConnection.credentials`` (TEXT column).
    """
    plaintext = json.dumps(creds, separators=(",", ":")).encode()
    return _fernet().encrypt(plaintext).decode()


def decrypt_credentials(token: str) -> dict:
    """Decrypt a Fernet token produced by ``encrypt_credentials``.

    Raises:
        InvalidToken: if the token is malformed, expired, or was encrypted with
            a different key.
        json.JSONDecodeError: if the plaintext is not valid JSON (should never
            happen for tokens we produced).
    """
    try:
        plaintext = _fernet().decrypt(token.encode() if isinstance(token, str) else token)
    except InvalidToken:
        raise InvalidToken(
            "Failed to decrypt credentials — token is invalid or key has rotated."
        )
    return json.loads(plaintext.decode())
