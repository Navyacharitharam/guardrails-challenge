"""JWT authentication and user session management.

Tokens are issued at login and must be presented in the ``Authorization: Bearer``
header.  The ``get_current_tenant_id`` dependency extracts and validates the
tenant ID from the token, which is then used to set the RLS context.
"""
import uuid
from datetime import datetime, timedelta, timezone

import bcrypt as _bcrypt
import structlog
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt

from backbone.core.config import settings

log = structlog.get_logger(__name__)

_bearer = HTTPBearer(auto_error=True)


# ---------------------------------------------------------------------------
# Password helpers
# ---------------------------------------------------------------------------


def hash_password(plain: str) -> str:
    """Return a bcrypt hash of ``plain``."""
    return _bcrypt.hashpw(plain.encode("utf-8"), _bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """Return ``True`` if ``plain`` matches the bcrypt ``hashed`` value."""
    return _bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


# ---------------------------------------------------------------------------
# Token creation
# ---------------------------------------------------------------------------


def create_access_token(tenant_id: uuid.UUID, email: str) -> str:
    """Issue a signed JWT for the given tenant.

    Args:
        tenant_id: UUID of the tenant (embedded as ``sub`` claim).
        email: User email (embedded as ``email`` claim, informational only).

    Returns:
        A compact JWT string.
    """
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.JWT_EXPIRY_MINUTES)
    payload = {
        "sub": str(tenant_id),
        "email": email,
        "exp": expire,
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------


def decode_token(token: str) -> uuid.UUID:
    """Decode a raw JWT string and return the tenant UUID.

    Unlike the FastAPI dependency, this function is synchronous and does not
    depend on the request context.  Used by middleware that needs to decode
    a token before handing off to route handlers.

    Args:
        token: Raw JWT string (without the ``Bearer `` prefix).

    Returns:
        The tenant UUID embedded in the ``sub`` claim.

    Raises:
        JWTError: If the token signature is invalid or the token has expired.
        ValueError: If the ``sub`` claim is not a valid UUID.
    """
    payload = jwt.decode(
        token,
        settings.SECRET_KEY,
        algorithms=[settings.JWT_ALGORITHM],
    )
    tenant_id_str: str | None = payload.get("sub")
    if not tenant_id_str:
        raise JWTError("Token missing subject claim.")
    return uuid.UUID(tenant_id_str)


async def get_current_tenant_id(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
) -> uuid.UUID:
    """FastAPI dependency that validates the Bearer token and returns the tenant ID.

    Raises:
        HTTPException 401: If the token is missing, invalid, or expired.
    """
    token = credentials.credentials
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        tenant_id_str: str | None = payload.get("sub")
        if not tenant_id_str:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token missing subject claim.",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return uuid.UUID(tenant_id_str)
    except (JWTError, ValueError) as exc:
        log.warning("auth.invalid_token", error=str(exc))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token.",
            headers={"WWW-Authenticate": "Bearer"},
        )
