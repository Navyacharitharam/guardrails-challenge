from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables or .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    DATABASE_URL: str = "postgresql+asyncpg://gtm:gtm_secret@localhost:5432/gtm"
    SYNC_DATABASE_URL: str = "postgresql://gtm:gtm_secret@localhost:5432/gtm"
    REDIS_URL: str = "redis://localhost:6379/0"  # nosemgrep: trailofbits.generic.redis-unencrypted-transport.redis-unencrypted-transport
    SECRET_KEY: str = "dev_secret_key_change_in_production_32c"
    ANTHROPIC_API_KEY: str = ""
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRY_MINUTES: int = 60
    FERNET_KEY: str = ""
    ENVIRONMENT: str = "development"
    SEED_ENABLED: bool = True
    LOG_LEVEL: str = "INFO"


settings = Settings()
