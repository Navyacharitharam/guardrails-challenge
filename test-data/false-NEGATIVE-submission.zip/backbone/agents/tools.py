"""Agent tool interface, global registry, and built-in control-flow tools.

Every tool the agent can call must:
  1. Subclass ``AgentTool``.
  2. Set class-level ``name`` and ``description``.
  3. Implement ``input_schema`` (JSON Schema fed to the Anthropic tool_use API).
  4. Implement ``execute(session, run_id, **kwargs)``.

Control-flow tools raise special signals (not exceptions) to communicate
structured outcomes to the orchestrator without going through the normal
ToolResult path:

  ``WorkflowCompleteSignal``  — the workflow is done, carry the final output.
  ``HumanGateSignal``         — suspend the run, await a human decision.

These are caught by the orchestrator, never by callers outside this package.
"""
import abc
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backbone.integrations.base import ToolError, ToolResult
from backbone.models.enums import HumanReviewType


# ---------------------------------------------------------------------------
# Control-flow signals
# ---------------------------------------------------------------------------


class WorkflowCompleteSignal(Exception):
    """Raised by ``complete_workflow`` to terminate the orchestrator loop.

    Not an error — carries the structured final output of the run.
    """

    def __init__(self, output: dict[str, Any]) -> None:
        self.output = output


class HumanGateSignal(Exception):
    """Raised by ``request_human_review`` to suspend the orchestrator loop.

    The orchestrator catches this, creates a ``HumanReview`` record, and
    returns without marking the run terminal.  The run resumes when a
    reviewer approves, rejects, or modifies the proposed output.
    """

    def __init__(
        self,
        review_type: HumanReviewType,
        proposed_output: dict[str, Any],
        context: dict[str, Any],
    ) -> None:
        self.review_type = review_type
        self.proposed_output = proposed_output
        self.context = context


# ---------------------------------------------------------------------------
# AgentTool abstract base
# ---------------------------------------------------------------------------


class AgentTool(abc.ABC):
    """Abstract base for every agent-callable tool.

    Subclasses must set ``name`` and ``description`` as class variables and
    implement ``input_schema`` and ``execute``.

    Registration::

        from backbone.agents.tools import register_tool

        @register_tool
        class MyTool(AgentTool):
            name = "my_tool"
            ...
    """

    name: str
    description: str

    @property
    @abc.abstractmethod
    def input_schema(self) -> dict[str, Any]:
        """JSON Schema object passed verbatim to the Anthropic tool_use API.

        Must conform to the Claude tool schema format::

            {
                "type": "object",
                "properties": { ... },
                "required": [ ... ],
            }
        """

    @abc.abstractmethod
    async def execute(
        self,
        session: AsyncSession,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> ToolResult:
        """Execute the tool and return a ``ToolResult``.

        Args:
            session: Async DB session; tenant RLS context is already set.
            run_id: The ``AgentRun.id`` for this execution (useful for tools
                that need to write ``Activity`` records).
            **kwargs: Tool inputs as decoded by the Anthropic SDK from the
                JSON Schema-validated ``tool_use`` block.

        Returns:
            ``ToolResult`` on success.

        Raises:
            ``ToolError(retriable=False)`` — fatal: the orchestrator marks the
                run FAILED and stops.
            ``ToolError(retriable=True)`` — transient: the orchestrator returns
                an error tool_result so Claude can adjust and retry.
            ``HumanGateSignal`` — suspend run, await human review.
            ``WorkflowCompleteSignal`` — the workflow is finished; carry output.
        """


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_REGISTRY: dict[str, AgentTool] = {}


def register_tool(tool_or_cls: AgentTool | type[AgentTool]) -> AgentTool | type[AgentTool]:
    """Register a tool instance (or class) in the global registry.

    Accepts both instances and classes (auto-instantiated)::

        @register_tool
        class MyTool(AgentTool): ...          # class → instantiated

        register_tool(MyTool())               # instance → stored directly
    """
    if isinstance(tool_or_cls, type):
        instance = tool_or_cls()
        _REGISTRY[instance.name] = instance
        return tool_or_cls
    _REGISTRY[tool_or_cls.name] = tool_or_cls
    return tool_or_cls


def get_tool(name: str) -> AgentTool | None:
    """Return the registered tool with the given name, or ``None``."""
    return _REGISTRY.get(name)


def all_tools() -> list[AgentTool]:
    """Return all registered tools in registration order."""
    return list(_REGISTRY.values())


def tool_schemas() -> list[dict[str, Any]]:
    """Return all tools formatted for the Anthropic ``tools`` parameter."""
    return [
        {
            "name": t.name,
            "description": t.description,
            "input_schema": t.input_schema,
        }
        for t in all_tools()
    ]


# ---------------------------------------------------------------------------
# Built-in control-flow tools (always registered)
# ---------------------------------------------------------------------------


class _CompleteWorkflow(AgentTool):
    """Signal successful workflow completion with a structured output."""

    name = "complete_workflow"
    description = (
        "Signal that the workflow has completed successfully. Call this once "
        "all objectives have been accomplished. Provide a human-readable "
        "summary and a structured output object with the key results."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "summary": {
                    "type": "string",
                    "description": "One-paragraph human-readable summary of what was accomplished.",
                },
                "output": {
                    "type": "object",
                    "description": (
                        "Structured results — e.g. discovered accounts, verified emails, "
                        "outreach drafts, or scored contacts."
                    ),
                },
            },
            "required": ["summary", "output"],
        }

    async def execute(
        self,
        session: AsyncSession,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> ToolResult:
        raise WorkflowCompleteSignal(
            output={
                "summary": kwargs.get("summary", ""),
                **(kwargs.get("output") or {}),
            }
        )


class _RequestHumanReview(AgentTool):
    """Suspend the run and request a human decision before proceeding."""

    name = "request_human_review"
    description = (
        "Pause the workflow and request a human to review and approve a proposed "
        "action before execution. Use this before sending outreach emails, before "
        "committing large data changes, or when you need validation of a hypothesis. "
        "The run resumes automatically once the reviewer responds."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "review_type": {
                    "type": "string",
                    "enum": [rt.value for rt in HumanReviewType],
                    "description": "Category of review: what the human is being asked to decide.",
                },
                "proposed_output": {
                    "type": "object",
                    "description": (
                        "The specific action or content requiring approval "
                        "(outreach email draft, hypothesis JSON, enrichment result, etc.)."
                    ),
                },
                "context": {
                    "type": "object",
                    "description": (
                        "Supporting evidence and reasoning to help the reviewer decide "
                        "(signals observed, data sources, confidence scores, etc.)."
                    ),
                },
            },
            "required": ["review_type", "proposed_output", "context"],
        }

    async def execute(
        self,
        session: AsyncSession,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> ToolResult:
        review_type_raw = kwargs.get("review_type", "")
        try:
            review_type = HumanReviewType(review_type_raw)
        except ValueError:
            raise ToolError(
                f"Unknown review_type '{review_type_raw}'. "
                f"Valid values: {[rt.value for rt in HumanReviewType]}",
                retriable=False,
            )
        raise HumanGateSignal(
            review_type=review_type,
            proposed_output=kwargs.get("proposed_output") or {},
            context=kwargs.get("context") or {},
        )


# Register built-in tools at module import time.
register_tool(_CompleteWorkflow())
register_tool(_RequestHumanReview())
