"""ComputeIntentScore — Stage 4 signal tool."""
import uuid
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.icp import ICP
from backbone.models.record import Record
from backbone.models.signal import Signal


class ComputeIntentScore(AgentTool):
    """Aggregate signals into an intent_score and persist it."""

    name = "compute_intent_score"
    description = (
        "Compute a weighted intent_score (0.0–1.0) for an Account record by "
        "aggregating its signals against the ICP's signal_weights. "
        "Persists the result to Record.intent_score and returns the score "
        "with a per-signal-type breakdown."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "record_id": {
                    "type": "string",
                    "description": "UUID of the Account Record.",
                },
                "icp_id": {
                    "type": "string",
                    "description": "UUID of the ICP whose signal_weights to use.",
                },
            },
            "required": ["record_id", "icp_id"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            record_id = uuid.UUID(kwargs["record_id"])
            icp_id = uuid.UUID(kwargs["icp_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid UUID: {exc}", retriable=False)

        icp_res = await session.execute(select(ICP).where(ICP.id == icp_id))
        icp = icp_res.scalar_one_or_none()
        if icp is None:
            raise ToolError(f"ICP {icp_id} not found.", retriable=False)

        sig_res = await session.execute(
            select(Signal).where(Signal.record_id == record_id)
        )
        signals = list(sig_res.scalars())

        weights: dict[str, float] = icp.signal_weights or {}
        by_type: dict[str, list[float]] = {}
        for s in signals:
            by_type.setdefault(s.signal_type.value, []).append(s.score)

        total_weight = 0.0
        weighted_sum = 0.0
        breakdown: dict[str, Any] = {}

        for sig_type, scores in by_type.items():
            weight = float(weights.get(sig_type, 0.5))
            best = max(scores)
            weighted_sum += best * weight
            total_weight += weight
            breakdown[sig_type] = {
                "best_score": round(best, 4),
                "weight": weight,
                "count": len(scores),
                "contribution": round(best * weight, 4),
            }

        intent_score = (
            round(min(1.0, weighted_sum / total_weight), 4) if total_weight > 0 else 0.0
        )

        await session.execute(
            update(Record).where(Record.id == record_id).values(intent_score=intent_score)
        )

        return ToolResult(
            provider_slug="db",
            data={
                "record_id": str(record_id),
                "intent_score": intent_score,
                "signal_count": len(signals),
                "breakdown": breakdown,
            },
        )
