"""VerifyEmail — Stage 3 enrichment tool."""
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.integrations.waterfall import resolve as waterfall_resolve

# Ensure the Hunter.io provider is registered before the waterfall is called.
from backbone.integrations.providers import hunter as _hunter_provider  # noqa: F401


class VerifyEmail(AgentTool):
    """Find a professional email for a named person via the enrichment waterfall."""

    name = "verify_email"
    description = (
        "Find and verify a professional email address for a named person at a company domain. "
        "Uses the Hunter.io integration (and any other configured providers). "
        "Returns the email with a confidence score. Does not modify any Record."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "domain": {
                    "type": "string",
                    "description": "Apex domain of the employer (e.g. 'stripe.com').",
                },
            },
            "required": ["first_name", "last_name", "domain"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        first_name = kwargs.get("first_name", "")
        last_name = kwargs.get("last_name", "")
        domain = kwargs.get("domain", "")

        if not all([first_name, last_name, domain]):
            raise ToolError(
                "first_name, last_name, and domain are all required.", retriable=False
            )

        result = await waterfall_resolve(
            "find_email",
            session=session,
            first_name=first_name,
            last_name=last_name,
            domain=domain,
        )
        return ToolResult(
            provider_slug=result.provider_slug,
            data=result.data,
            meta=result.meta,
        )
