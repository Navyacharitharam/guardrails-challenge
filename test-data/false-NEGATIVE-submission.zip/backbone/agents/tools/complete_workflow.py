"""CompleteWorkflow — built-in control-flow tool."""
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool, WorkflowCompleteSignal
from backbone.integrations.base import ToolResult


class CompleteWorkflow(AgentTool):
    """Signal successful workflow completion with a structured final output.

    This is a control-flow tool: ``execute`` always raises
    ``WorkflowCompleteSignal``, which the orchestrator catches to terminate
    the loop and mark the run ``COMPLETED``.
    """

    name = "complete_workflow"
    description = (
        "Signal that the workflow has completed successfully. Call this once "
        "all objectives have been accomplished. Provide a human-readable "
        "summary and a structured output object with the key results."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "summary": {
                    "type": "string",
                    "description": (
                        "One-paragraph human-readable summary of what was accomplished."
                    ),
                },
                "output": {
                    "type": "object",
                    "description": (
                        "Structured results — e.g. discovered accounts, verified "
                        "emails, outreach drafts, or scored contacts."
                    ),
                },
            },
            "required": ["summary", "output"],
        }

    async def execute(
        self,
        session: AsyncSession,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> ToolResult:
        raise WorkflowCompleteSignal(
            output={
                "summary": kwargs.get("summary", ""),
                **(kwargs.get("output") or {}),
            }
        )
