"""LoadICP — Stage 1 prospect tool."""
import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.icp import ICP


class LoadICP(AgentTool):
    """Load and return the criteria of an ICP record from the database."""

    name = "load_icp"
    description = (
        "Load an Ideal Customer Profile from the database by its ID. "
        "Returns firmographic criteria, technographic criteria, persona criteria, "
        "signal weights, and the ICP name. Call this first to understand who to target."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "icp_id": {
                    "type": "string",
                    "description": "UUID of the ICP to load.",
                },
            },
            "required": ["icp_id"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            icp_id = uuid.UUID(kwargs["icp_id"])
        except (ValueError, KeyError):
            raise ToolError(f"Invalid icp_id: {kwargs.get('icp_id')!r}", retriable=False)

        result = await session.execute(select(ICP).where(ICP.id == icp_id))
        icp = result.scalar_one_or_none()
        if icp is None:
            raise ToolError(f"ICP {icp_id} not found.", retriable=False)

        return ToolResult(
            provider_slug="db",
            data={
                "icp_id": str(icp.id),
                "name": icp.name,
                "description": icp.description,
                "firmographic_criteria": icp.firmographic_criteria,
                "technographic_criteria": icp.technographic_criteria,
                "persona_criteria": icp.persona_criteria,
                "signal_weights": icp.signal_weights,
                "is_active": icp.is_active,  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
            },
        )
