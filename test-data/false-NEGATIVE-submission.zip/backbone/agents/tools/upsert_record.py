"""UpsertRecord — cross-cutting data tool."""
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.enums import EnrichmentStatus
from backbone.models.object_definition import ObjectDefinition
from backbone.models.record import Record


class UpsertRecord(AgentTool):
    """Create or update a Record, idempotent on external_id."""

    name = "upsert_record"
    description = (
        "Create a new Record or update an existing one identified by external_id. "
        "Use for persisting enriched contacts, discovered companies, or any CRM entity. "
        "The object_slug must match an existing ObjectDefinition ('account' or 'contact')."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "object_slug": {
                    "type": "string",
                    "description": "ObjectDefinition slug: 'account' or 'contact'.",
                },
                "external_id": {
                    "type": "string",
                    "description": "Stable external identifier for upsert deduplication.",
                },
                "attributes": {
                    "type": "object",
                    "description": "Record attributes dict (company_name, email, etc.).",
                },
            },
            "required": ["object_slug", "attributes"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        object_slug = kwargs.get("object_slug", "")
        external_id = kwargs.get("external_id")
        attributes: dict = kwargs.get("attributes") or {}

        od_res = await session.execute(
            select(ObjectDefinition).where(ObjectDefinition.slug == object_slug).limit(1)
        )
        od = od_res.scalar_one_or_none()
        if od is None:
            raise ToolError(
                f"ObjectDefinition '{object_slug}' not found for this tenant.",
                retriable=False,
            )

        record: Record | None = None
        created = False

        if external_id:
            existing_res = await session.execute(
                select(Record).where(
                    Record.object_definition_id == od.id,
                    Record.external_id == external_id,
                )
            )
            record = existing_res.scalar_one_or_none()

        if record is None:
            record = Record(
                tenant_id=od.tenant_id,
                object_definition_id=od.id,
                external_id=external_id,
                attributes=attributes,
                enrichment_status=EnrichmentStatus.UNENRICHED,
            )
            session.add(record)
            await session.flush()
            created = True
        else:
            merged = dict(record.attributes or {})
            merged.update(attributes)
            await session.execute(
                update(Record)
                .where(Record.id == record.id)
                .values(attributes=merged, updated_at=datetime.now(timezone.utc))
            )

        return ToolResult(
            provider_slug="db",
            data={
                "record_id": str(record.id),
                "object_slug": object_slug,
                "external_id": external_id,
                "created": created,
            },
        )
