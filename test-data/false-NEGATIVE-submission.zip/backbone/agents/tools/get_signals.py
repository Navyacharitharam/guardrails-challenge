"""GetSignals — Stage 4 signal tool."""
import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.enums import SignalType
from backbone.models.signal import Signal


class GetSignals(AgentTool):
    """Load intelligence signals for a Record."""

    name = "get_signals"
    description = (
        "Load signals (funding, hiring, intent, job_change, technographic, news, "
        "web_activity) for a Record. Returns signals sorted by score descending. "
        "Use before compute_intent_score and generate_hypothesis."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "record_id": {
                    "type": "string",
                    "description": "UUID of the Record to load signals for.",
                },
                "signal_types": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": [st.value for st in SignalType],
                    },
                    "description": "Filter to specific signal types. Empty = all types.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max signals to return (default 20).",
                    "default": 20,
                },
            },
            "required": ["record_id"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            record_id = uuid.UUID(kwargs["record_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid record_id: {exc}", retriable=False)

        limit = int(kwargs.get("limit") or 20)
        type_filter = list(kwargs.get("signal_types") or [])

        query = select(Signal).where(Signal.record_id == record_id)
        if type_filter:
            valid_types = [SignalType(t) for t in type_filter]
            query = query.where(Signal.signal_type.in_(valid_types))
        query = query.order_by(Signal.score.desc()).limit(limit)

        res = await session.execute(query)
        signals = list(res.scalars())

        return ToolResult(
            provider_slug="db",
            data={
                "record_id": str(record_id),
                "signals": [
                    {
                        "signal_id": str(s.id),
                        "signal_type": s.signal_type.value,
                        "source": s.source,
                        "score": s.score,
                        "occurred_at": s.occurred_at.isoformat(),
                        "payload": s.payload,
                    }
                    for s in signals
                ],
            },
            meta={"count": len(signals)},
        )
