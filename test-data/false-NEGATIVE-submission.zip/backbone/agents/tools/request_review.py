"""RequestHumanReview — built-in human-gate tool."""
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool, HumanGateSignal
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.enums import HumanReviewType


class RequestHumanReview(AgentTool):
    """Suspend the run and request a human decision before proceeding.

    This is a control-flow tool: ``execute`` always raises
    ``HumanGateSignal``, which the orchestrator catches to persist a
    ``HumanReview`` record and return without marking the run terminal.
    The run resumes automatically once the reviewer responds.
    """

    name = "request_human_review"
    description = (
        "Pause the workflow and request a human to review and approve a proposed "
        "action before execution. Use this before sending outreach emails, before "
        "committing large data changes, or when you need validation of a hypothesis. "
        "The run resumes automatically once the reviewer responds."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "review_type": {
                    "type": "string",
                    "enum": [rt.value for rt in HumanReviewType],
                    "description": (
                        "Category of review: what the human is being asked to decide."
                    ),
                },
                "proposed_output": {
                    "type": "object",
                    "description": (
                        "The specific action or content requiring approval "
                        "(outreach email draft, hypothesis JSON, etc.)."
                    ),
                },
                "context": {
                    "type": "object",
                    "description": (
                        "Supporting evidence to help the reviewer decide "
                        "(signals, confidence scores, data sources, etc.)."
                    ),
                },
            },
            "required": ["review_type", "proposed_output", "context"],
        }

    async def execute(
        self,
        session: AsyncSession,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> ToolResult:
        review_type_raw = kwargs.get("review_type", "")
        try:
            review_type = HumanReviewType(review_type_raw)
        except ValueError:
            raise ToolError(
                f"Unknown review_type '{review_type_raw}'. "
                f"Valid values: {[rt.value for rt in HumanReviewType]}",
                retriable=False,
            )
        raise HumanGateSignal(
            review_type=review_type,
            proposed_output=kwargs.get("proposed_output") or {},
            context=kwargs.get("context") or {},
        )
