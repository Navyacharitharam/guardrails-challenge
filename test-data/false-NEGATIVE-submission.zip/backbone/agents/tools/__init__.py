"""backbone.agents.tools — agent tool package.

Provides the AgentTool ABC, control-flow signals, the global tool registry,
and all registered tool implementations.

Backwards-compatible with the previous flat-module layout: all symbols that
were importable from ``backbone.agents.tools`` (the old single-file module)
remain importable from this package.

Importing this package is sufficient to register all tools — no additional
imports are required by callers.
"""

# Re-export core abstractions from submodules so existing imports still work:
#   from backbone.agents.tools import AgentTool
#   from backbone.agents.tools import WorkflowCompleteSignal, HumanGateSignal
#   from backbone.agents.tools import register_tool, get_tool, all_tools, tool_schemas
from backbone.agents.tools.base import (
    AgentTool,
    HumanGateSignal,
    WorkflowCompleteSignal,
)
from backbone.agents.tools.registry import (
    all_tools,
    get_tool,
    register_tool,
    tool_schemas,
)

# Register built-in control-flow tools.
from backbone.agents.tools.complete_workflow import CompleteWorkflow
from backbone.agents.tools.request_review import RequestHumanReview

register_tool(CompleteWorkflow())
register_tool(RequestHumanReview())

# Register all 12 prospect-workflow tools.
# Each import triggers the module to load; registration is done by
# backbone.agents.prospect_tools (imported here to ensure it runs once).
from backbone.agents.tools.load_icp import LoadICP
from backbone.agents.tools.score_fit import ScoreCompanyFit
from backbone.agents.tools.discover import DiscoverCompanies
from backbone.agents.tools.upsert_record import UpsertRecord
from backbone.agents.tools.create_relationship import CreateRelationship
from backbone.agents.tools.create_activity import CreateActivity
from backbone.agents.tools.verify_email import VerifyEmail
from backbone.agents.tools.enrich_contact import EnrichContact
from backbone.agents.tools.get_signals import GetSignals
from backbone.agents.tools.compute_intent import ComputeIntentScore
from backbone.agents.tools.generate_hypothesis import GenerateHypothesis
from backbone.agents.tools.generate_outreach import GenerateOutreach

for _tool_instance in [
    LoadICP(),
    ScoreCompanyFit(),
    DiscoverCompanies(),
    UpsertRecord(),
    CreateRelationship(),
    CreateActivity(),
    VerifyEmail(),
    EnrichContact(),
    GetSignals(),
    ComputeIntentScore(),
    GenerateHypothesis(),
    GenerateOutreach(),
]:
    register_tool(_tool_instance)

__all__ = [
    # Abstractions
    "AgentTool",
    "WorkflowCompleteSignal",
    "HumanGateSignal",
    # Registry
    "register_tool",
    "get_tool",
    "all_tools",
    "tool_schemas",
    # Built-in control-flow tools
    "CompleteWorkflow",
    "RequestHumanReview",
    # Prospect tools
    "LoadICP",
    "ScoreCompanyFit",
    "DiscoverCompanies",
    "UpsertRecord",
    "CreateRelationship",
    "CreateActivity",
    "VerifyEmail",
    "EnrichContact",
    "GetSignals",
    "ComputeIntentScore",
    "GenerateHypothesis",
    "GenerateOutreach",
]
