"""ScoreCompanyFit — Stage 1 prospect tool."""
import uuid
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools._scoring import composite_fit_score, score_firmographic, score_technographic
from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.icp import ICP
from backbone.models.record import Record


class ScoreCompanyFit(AgentTool):
    """Compute and persist a fit_score for an Account record against an ICP."""

    name = "score_company_fit"
    description = (
        "Compute the ICP fit score (0.0–1.0) for an Account record. "
        "Scores firmographic and technographic dimensions against the ICP criteria, "
        "persists the result to Record.fit_score, and returns the score with a breakdown. "
        "Call this for each discovered account before prioritising outreach."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "record_id": {
                    "type": "string",
                    "description": "UUID of the Account Record to score.",
                },
                "icp_id": {
                    "type": "string",
                    "description": "UUID of the ICP to score against.",
                },
            },
            "required": ["record_id", "icp_id"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            record_id = uuid.UUID(kwargs["record_id"])
            icp_id = uuid.UUID(kwargs["icp_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid UUID: {exc}", retriable=False)

        record_res = await session.execute(select(Record).where(Record.id == record_id))
        record = record_res.scalar_one_or_none()
        if record is None:
            raise ToolError(f"Record {record_id} not found.", retriable=False)

        icp_res = await session.execute(select(ICP).where(ICP.id == icp_id))
        icp = icp_res.scalar_one_or_none()
        if icp is None:
            raise ToolError(f"ICP {icp_id} not found.", retriable=False)

        attrs = record.attributes or {}
        firm_score, firm_sub = score_firmographic(attrs, icp.firmographic_criteria)
        tech_score = score_technographic(attrs, icp.technographic_criteria)
        fit_score = composite_fit_score(firm_score, tech_score)

        await session.execute(
            update(Record).where(Record.id == record_id).values(fit_score=fit_score)
        )

        return ToolResult(
            provider_slug="db",
            data={
                "record_id": str(record_id),
                "company_name": attrs.get("company_name"),
                "fit_score": fit_score,
                "breakdown": {
                    "firmographic": round(firm_score, 4),
                    "firmographic_detail": firm_sub,
                    "technographic": round(tech_score, 4),
                },
            },
        )
