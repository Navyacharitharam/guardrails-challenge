"""GenerateHypothesis — Stage 5 hypothesis tool."""
import json
import uuid
from datetime import datetime, timezone
from typing import Any

import anthropic
import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.core.config import settings
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.icp import ICP
from backbone.models.record import Record

log = structlog.get_logger(__name__)

MODEL = "claude-sonnet-4-5"

_SUBMIT_TOOL: dict[str, Any] = {
    "name": "submit_hypothesis",
    "description": "Submit the completed value hypothesis.",
    "input_schema": {
        "type": "object",
        "properties": {
            "pain_points": {
                "type": "array",
                "items": {"type": "string"},
                "description": "3-5 specific pain points this company is likely experiencing.",
            },
            "value_propositions": {
                "type": "array",
                "items": {"type": "string"},
                "description": "3-5 concrete value propositions tailored to this account.",
            },
            "approach_summary": {
                "type": "string",
                "description": "One-paragraph recommended outreach approach.",
            },
            "confidence_score": {
                "type": "number",
                "description": "0.0–1.0 confidence in this hypothesis given the available evidence.",
            },
            "reasoning": {
                "type": "string",
                "description": "Evidence-based reasoning citing specific signals and attributes.",
            },
        },
        "required": [
            "pain_points",
            "value_propositions",
            "approach_summary",
            "confidence_score",
            "reasoning",
        ],
    },
}


class GenerateHypothesis(AgentTool):
    """Call Claude claude-sonnet-4-5 to generate a structured value hypothesis."""

    name = "generate_hypothesis"
    description = (
        "Generate a structured value hypothesis for an Account using Claude claude-sonnet-4-5. "
        "Synthesises fit_score, intent_score, signals, and ICP criteria into "
        "concrete pain_points, value_propositions, and a recommended outreach approach. "
        "Call after scoring and signal loading (Stages 1-4)."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "account_record_id": {
                    "type": "string",
                    "description": "UUID of the Account Record.",
                },
                "icp_id": {
                    "type": "string",
                    "description": "UUID of the ICP.",
                },
                "signals": {
                    "type": "array",
                    "description": "Signal data from get_signals (pass the full list).",
                    "items": {"type": "object"},
                },
            },
            "required": ["account_record_id", "icp_id"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            record_id = uuid.UUID(kwargs["account_record_id"])
            icp_id = uuid.UUID(kwargs["icp_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid UUID: {exc}", retriable=False)

        signals: list[dict] = kwargs.get("signals") or []

        rec_res = await session.execute(select(Record).where(Record.id == record_id))
        record = rec_res.scalar_one_or_none()
        if record is None:
            raise ToolError(f"Record {record_id} not found.", retriable=False)

        icp_res = await session.execute(select(ICP).where(ICP.id == icp_id))
        icp = icp_res.scalar_one_or_none()
        if icp is None:
            raise ToolError(f"ICP {icp_id} not found.", retriable=False)

        attrs = record.attributes or {}
        prompt = (
            f"You are a B2B sales strategist. Analyse this target account and generate a "
            f"precise, evidence-based value hypothesis.\n\n"
            f"Company: {json.dumps(attrs, default=str)}\n\n"
            f"ICP: {icp.name}\n{icp.description}\n"
            f"Targeting criteria: {json.dumps(icp.firmographic_criteria, default=str)}\n\n"
            f"Fit score: {record.fit_score or 'not yet scored'}/1.0\n"
            f"Intent score: {record.intent_score or 'not yet scored'}/1.0\n\n"
            f"Signals ({len(signals)} total):\n"
            f"{json.dumps(signals[:10], default=str, indent=2)}\n\n"
            f"Generate a hypothesis using the submit_hypothesis tool. "
            f"Ground every claim in the signals and account attributes above."
        )

        client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        try:
            response = await client.messages.create(
                model=MODEL,
                max_tokens=1024,
                system=(
                    "You are a B2B sales strategy assistant. Generate structured value "
                    "hypotheses based on account data, ICP criteria, and market signals."
                ),
                tools=[_SUBMIT_TOOL],
                tool_choice={"type": "any"},
                messages=[{"role": "user", "content": prompt}],
                metadata={"user_id": str(run_id)},
            )
        except anthropic.APIError as exc:
            raise ToolError(
                f"Claude API error generating hypothesis: {exc}", retriable=True
            )

        for block in response.content:
            if hasattr(block, "type") and block.type == "tool_use":
                hypothesis: dict[str, Any] = dict(block.input)
                hypothesis["generated_at"] = datetime.now(timezone.utc).isoformat()
                hypothesis["account_record_id"] = str(record_id)
                hypothesis["model"] = MODEL
                return ToolResult(
                    provider_slug="claude",
                    data=hypothesis,
                    meta={"usage": {
                        "input_tokens": response.usage.input_tokens,
                        "output_tokens": response.usage.output_tokens,
                    }},
                )

        raise ToolError("Claude did not return a structured hypothesis.", retriable=True)
