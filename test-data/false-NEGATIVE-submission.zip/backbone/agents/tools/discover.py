"""DiscoverCompanies — Stage 2 prospect tool."""
import uuid
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools._scoring import composite_fit_score, score_firmographic, score_technographic
from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.icp import ICP
from backbone.models.object_definition import ObjectDefinition
from backbone.models.record import Record


class DiscoverCompanies(AgentTool):
    """Return top Account records ranked by ICP fit from the tenant's database."""

    name = "discover_companies"
    description = (
        "Discover and rank Account records that match the ICP criteria. "
        "Queries the tenant's existing accounts, scores each against the ICP, "
        "and returns the top results sorted by fit_score descending. "
        "Use this as Stage 2 to build the target account list."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "icp_id": {
                    "type": "string",
                    "description": "UUID of the ICP to score accounts against.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum accounts to return (default 10, max 50).",
                    "default": 10,
                },
                "min_fit_score": {
                    "type": "number",
                    "description": "Minimum fit_score threshold (default 0.5).",
                    "default": 0.5,
                },
            },
            "required": ["icp_id"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            icp_id = uuid.UUID(kwargs["icp_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid icp_id: {exc}", retriable=False)

        limit = min(int(kwargs.get("limit") or 10), 50)
        min_score = float(kwargs.get("min_fit_score") or 0.5)

        icp_res = await session.execute(select(ICP).where(ICP.id == icp_id))
        icp = icp_res.scalar_one_or_none()
        if icp is None:
            raise ToolError(f"ICP {icp_id} not found.", retriable=False)

        od_res = await session.execute(
            select(ObjectDefinition).where(ObjectDefinition.slug == "account").limit(1)
        )
        od = od_res.scalar_one_or_none()
        if od is None:
            raise ToolError(
                "No 'account' ObjectDefinition found for this tenant. "
                "Ensure seed data has been loaded.",
                retriable=False,
            )

        records_res = await session.execute(
            select(Record).where(Record.object_definition_id == od.id)
        )
        records = list(records_res.scalars())

        scored: list[dict[str, Any]] = []
        for rec in records:
            attrs = rec.attributes or {}
            firm_score, _ = score_firmographic(attrs, icp.firmographic_criteria)
            tech_score = score_technographic(attrs, icp.technographic_criteria)
            fit = composite_fit_score(firm_score, tech_score)

            await session.execute(
                update(Record).where(Record.id == rec.id).values(fit_score=fit)
            )

            if fit >= min_score:
                scored.append(
                    {
                        "record_id": str(rec.id),
                        "external_id": rec.external_id,
                        "company_name": attrs.get("company_name"),
                        "industry": attrs.get("industry"),
                        "employee_count": attrs.get("employee_count"),
                        "funding_stage": attrs.get("funding_stage"),
                        "website": attrs.get("website"),
                        "hq_city": attrs.get("hq_city"),
                        "hq_country": attrs.get("hq_country"),
                        "fit_score": fit,
                    }
                )

        scored.sort(key=lambda x: x["fit_score"], reverse=True)
        top = scored[:limit]

        return ToolResult(
            provider_slug="db",
            data={"accounts": top, "total_evaluated": len(records), "returned": len(top)},
            meta={"icp_id": str(icp_id), "min_fit_score": min_score},
        )
