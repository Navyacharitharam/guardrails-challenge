"""Global tool registry for the agent orchestration layer.

Tools register themselves via ``register_tool`` at import time.  The
orchestrator queries the registry at run time via ``get_tool`` and
``tool_schemas``.

Registration is idempotent — registering the same name twice silently
replaces the previous entry, which lets test suites substitute stubs
without teardown gymnastics.
"""
from typing import Any

from backbone.agents.tools.base import AgentTool

_REGISTRY: dict[str, AgentTool] = {}


def register_tool(tool_or_cls: "AgentTool | type[AgentTool]") -> "AgentTool | type[AgentTool]":
    """Register a tool instance or class in the global registry.

    Accepts both instances and classes (auto-instantiated with no args)::

        @register_tool
        class MyTool(AgentTool): ...          # class → instantiated

        register_tool(MyTool())               # instance → stored directly

    Returns the argument unchanged so it can be used as a decorator.
    """
    if isinstance(tool_or_cls, type):
        instance: AgentTool = tool_or_cls()
        _REGISTRY[instance.name] = instance
        return tool_or_cls
    _REGISTRY[tool_or_cls.name] = tool_or_cls
    return tool_or_cls


def get_tool(name: str) -> AgentTool | None:
    """Return the registered tool with the given name, or ``None``."""
    return _REGISTRY.get(name)


def all_tools() -> list[AgentTool]:
    """Return all registered tools in insertion order."""
    return list(_REGISTRY.values())


def tool_schemas() -> list[dict[str, Any]]:
    """Return every registered tool formatted for the Anthropic ``tools`` parameter."""
    return [
        {
            "name": t.name,
            "description": t.description,
            "input_schema": t.input_schema,
        }
        for t in all_tools()
    ]
