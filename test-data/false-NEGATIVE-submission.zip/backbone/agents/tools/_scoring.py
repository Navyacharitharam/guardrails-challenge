"""Pure scoring helpers shared by ScoreCompanyFit and DiscoverCompanies.

These functions have no side effects and no database access — they operate
on already-loaded attribute dicts and ICP criteria dicts.
"""
from typing import Any


def score_firmographic(
    attrs: dict[str, Any], criteria: dict[str, Any]
) -> tuple[float, dict[str, float]]:
    """Return (aggregate_score, subscores) for firmographic fit.

    Subscores are 0.0–1.0 per dimension; aggregate is their mean.
    Missing data is treated as a partial match (0.5) to avoid penalising
    records that were enriched from incomplete sources.
    """
    sub: dict[str, float] = {}

    industries = criteria.get("industries") or []
    if industries:
        company_industry = (attrs.get("industry") or "").strip()
        sub["industry"] = 1.0 if company_industry in industries else 0.0

    emp_range = criteria.get("employee_count") or {}
    if emp_range:
        emp = int(attrs.get("employee_count") or 0)
        lo, hi = emp_range.get("min", 0), emp_range.get("max", 999_999)
        if lo <= emp <= hi:
            sub["employee_count"] = 1.0
        elif emp < lo and lo > 0:
            sub["employee_count"] = max(0.0, 1.0 - (lo - emp) / lo)
        else:
            sub["employee_count"] = max(0.0, 1.0 - (emp - hi) / max(hi, 1))

    arr_range = criteria.get("arr_usd") or {}
    if arr_range:
        arr = float(attrs.get("arr_usd") or 0)
        lo, hi = arr_range.get("min", 0), arr_range.get("max", 1e12)
        sub["arr"] = 1.0 if lo <= arr <= hi else 0.3

    stages = criteria.get("funding_stages") or []
    if stages:
        company_stage = (attrs.get("funding_stage") or "").strip()
        sub["funding_stage"] = 1.0 if company_stage in stages else 0.0

    geos = criteria.get("geographies") or []
    if geos:
        country = (attrs.get("hq_country") or "").strip()
        sub["geography"] = 1.0 if country in geos else 0.2

    if not sub:
        return 0.5, {}
    return sum(sub.values()) / len(sub), sub


def score_technographic(attrs: dict[str, Any], criteria: dict[str, Any]) -> float:
    """Return 0.0–1.0 technographic fit score."""
    technologies = [t.lower() for t in (attrs.get("technologies_used") or [])]
    tech_set = set(technologies)

    disqualifiers = [t.lower() for t in (criteria.get("disqualifiers") or [])]
    if any(t in tech_set for t in disqualifiers):
        return 0.0

    must_use = [t.lower() for t in (criteria.get("must_use_one_of") or [])]
    has_must = not must_use or any(t in tech_set for t in must_use)
    if not has_must:
        return 0.15

    nice = [t.lower() for t in (criteria.get("nice_to_have") or [])]
    if nice:
        matches = sum(1 for t in nice if t in tech_set)
        return 0.6 + 0.4 * (matches / len(nice))

    return 0.75 if has_must else 0.3


def composite_fit_score(firm_score: float, tech_score: float) -> float:
    """Blend firmographic (60%) and technographic (40%) into one score."""
    return round(0.60 * firm_score + 0.40 * tech_score, 4)
