"""AgentTool abstract base class and orchestrator control-flow signals.

All agent-callable tools must subclass ``AgentTool``.  Control-flow signals
(``WorkflowCompleteSignal``, ``HumanGateSignal``) are raised by tools to
communicate structured outcomes to the orchestrator without going through the
normal ToolResult path — they are caught by the orchestrator loop, never by
callers outside the agents package.
"""
import abc
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from backbone.integrations.base import ToolError, ToolResult
from backbone.models.enums import HumanReviewType


# ---------------------------------------------------------------------------
# Control-flow signals
# ---------------------------------------------------------------------------


class WorkflowCompleteSignal(Exception):
    """Raised by ``complete_workflow`` to terminate the orchestrator loop.

    Carries the structured final output of the run.  Not an error.
    """

    def __init__(self, output: dict[str, Any]) -> None:
        self.output = output


class HumanGateSignal(Exception):
    """Raised by ``request_human_review`` to suspend the orchestrator loop.

    The orchestrator catches this, persists a ``HumanReview`` record, and
    returns without marking the run terminal.  Execution resumes once a
    reviewer approves, rejects, or modifies the proposed output.
    """

    def __init__(
        self,
        review_type: HumanReviewType,
        proposed_output: dict[str, Any],
        context: dict[str, Any],
    ) -> None:
        self.review_type = review_type
        self.proposed_output = proposed_output
        self.context = context


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------


class AgentTool(abc.ABC):
    """Abstract base for every agent-callable tool.

    Subclasses must:
      1. Set ``name`` and ``description`` as class variables.
      2. Implement the ``input_schema`` property (JSON Schema for Anthropic).
      3. Implement ``execute(session, run_id, **kwargs)``.

    Registration is done separately via ``backbone.agents.tools.registry``::

        from backbone.agents.tools.registry import register_tool

        @register_tool
        class MyTool(AgentTool):
            name = "my_tool"
            ...
    """

    name: str
    description: str

    @property
    @abc.abstractmethod
    def input_schema(self) -> dict[str, Any]:
        """JSON Schema passed verbatim to the Anthropic ``tools`` parameter.

        Must conform to the Claude tool schema format::

            {
                "type": "object",
                "properties": { ... },
                "required": [ ... ],
            }
        """

    @abc.abstractmethod
    async def execute(
        self,
        session: AsyncSession,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> ToolResult:
        """Execute the tool.

        Args:
            session: Async DB session; tenant RLS context already set.
            run_id: The ``AgentRun.id`` being executed.
            **kwargs: Validated inputs from the Anthropic ``tool_use`` block.

        Returns:
            ``ToolResult`` on success.

        Raises:
            ``ToolError(retriable=False)`` — fatal failure; run is stopped.
            ``ToolError(retriable=True)`` — transient; Claude may retry.
            ``WorkflowCompleteSignal`` — workflow finished; carry output.
            ``HumanGateSignal`` — suspend run; await human review.
        """
