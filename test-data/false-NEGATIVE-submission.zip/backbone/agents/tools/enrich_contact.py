"""EnrichContact — Stage 3 enrichment tool."""
import uuid
from datetime import datetime, timezone
from typing import Any

import structlog
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.integrations.waterfall import (
    NoProvidersConfiguredError,
    resolve as waterfall_resolve,
)
from backbone.integrations.providers import hunter as _hunter_provider  # noqa: F401
from backbone.models.enums import EnrichmentStatus
from backbone.models.record import Record

log = structlog.get_logger(__name__)


class EnrichContact(AgentTool):
    """Enrich a Contact Record with verified email and position data."""

    name = "enrich_contact"
    description = (
        "Enrich a Contact record using its first_name, last_name, and the parent "
        "account's domain. Calls the enrichment waterfall (Hunter.io), persists "
        "the verified email and position to Record.attributes, sets "
        "enrichment_status = 'enriched', and returns the enriched data."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "contact_record_id": {
                    "type": "string",
                    "description": "UUID of the Contact Record to enrich.",
                },
                "domain": {
                    "type": "string",
                    "description": "Apex domain of the contact's employer.",
                },
            },
            "required": ["contact_record_id", "domain"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            contact_id = uuid.UUID(kwargs["contact_record_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid contact_record_id: {exc}", retriable=False)

        domain = kwargs.get("domain", "")
        if not domain:
            raise ToolError("domain is required.", retriable=False)

        rec_res = await session.execute(select(Record).where(Record.id == contact_id))
        record = rec_res.scalar_one_or_none()
        if record is None:
            raise ToolError(f"Contact record {contact_id} not found.", retriable=False)

        attrs = dict(record.attributes or {})
        first_name = attrs.get("first_name", "")
        last_name = attrs.get("last_name", "")

        if not first_name or not last_name:
            raise ToolError(
                f"Contact {contact_id} is missing first_name or last_name.",
                retriable=False,
            )

        try:
            result = await waterfall_resolve(
                "find_email",
                session=session,
                first_name=first_name,
                last_name=last_name,
                domain=domain,
            )
        except NoProvidersConfiguredError:
            log.warning(
                "enrich_contact.no_providers",
                contact_id=str(contact_id),
                domain=domain,
            )
            return ToolResult(
                provider_slug="none",
                data={
                    "contact_record_id": str(contact_id),
                    "enriched_fields": [],
                    "skipped": True,
                    "reason": "No enrichment providers configured for this tenant.",
                },
            )
        except ToolError as exc:
            await session.execute(
                update(Record)
                .where(Record.id == contact_id)
                .values(enrichment_status=EnrichmentStatus.FAILED)
            )
            if not exc.retriable:
                # Permanent failure (email not found, 404, bad request).
                # Return a soft result so the orchestrator passes it to Claude
                # and the workflow can continue to outreach drafting.
                log.warning(
                    "enrich_contact.not_found",
                    contact_id=str(contact_id),
                    domain=domain,
                    error=str(exc),
                )
                return ToolResult(
                    provider_slug="none",
                    data={
                        "contact_record_id": str(contact_id),
                        "enriched_fields": [],
                        "not_found": True,
                        "reason": f"Enrichment failed for {first_name} {last_name} @ {domain}: {exc}",
                    },
                )
            raise ToolError(
                f"Enrichment failed for {first_name} {last_name} @ {domain}: {exc}",
                retriable=True,
            ) from exc

        enriched: dict[str, Any] = {}
        if result.data.get("email"):
            enriched["email"] = result.data["email"]
            enriched["email_score"] = result.data.get("score")
        if result.data.get("position"):
            enriched["job_title"] = result.data["position"]
        if result.data.get("linkedin_url"):
            enriched["linkedin_url"] = result.data["linkedin_url"]
        enriched["enrichment_source"] = result.provider_slug
        enriched["enriched_at"] = datetime.now(timezone.utc).isoformat()

        attrs.update(enriched)
        await session.execute(
            update(Record)
            .where(Record.id == contact_id)
            .values(
                attributes=attrs,
                enrichment_status=EnrichmentStatus.ENRICHED,
                updated_at=datetime.now(timezone.utc),
            )
        )

        log.info(
            "enrich_contact.success",
            contact_id=str(contact_id),
            provider=result.provider_slug,
        )

        return ToolResult(
            provider_slug=result.provider_slug,
            data={
                "contact_record_id": str(contact_id),
                "enriched_fields": list(enriched.keys()),
                **{k: v for k, v in result.data.items() if k != "sources"},
            },
        )
