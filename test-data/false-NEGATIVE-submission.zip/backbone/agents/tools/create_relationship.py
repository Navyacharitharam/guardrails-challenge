"""CreateRelationship — cross-cutting data tool."""
import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.record import Record
from backbone.models.relationship import RecordRelationship


class CreateRelationship(AgentTool):
    """Create a directed RecordRelationship edge between two Records."""

    name = "create_relationship"
    description = (
        "Create a typed, directed edge between two Records. "
        "Typical usage: link a Contact to its Account with relationship_type='works_at'."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "from_record_id": {
                    "type": "string",
                    "description": "UUID of the source Record.",
                },
                "to_record_id": {
                    "type": "string",
                    "description": "UUID of the target Record.",
                },
                "relationship_type": {
                    "type": "string",
                    "description": "Verb-form type: 'works_at', 'reports_to', 'invested_in', etc.",
                },
                "attributes": {
                    "type": "object",
                    "description": "Optional edge metadata (start_date, role, etc.).",
                },
            },
            "required": ["from_record_id", "to_record_id", "relationship_type"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            from_id = uuid.UUID(kwargs["from_record_id"])
            to_id = uuid.UUID(kwargs["to_record_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid UUID: {exc}", retriable=False)

        rel_type = kwargs.get("relationship_type", "")
        attrs = kwargs.get("attributes") or {}

        from_res = await session.execute(select(Record).where(Record.id == from_id))
        from_rec = from_res.scalar_one_or_none()
        if from_rec is None:
            raise ToolError(f"Record {from_id} not found.", retriable=False)

        rel = RecordRelationship(
            tenant_id=from_rec.tenant_id,
            from_record_id=from_id,
            to_record_id=to_id,
            relationship_type=rel_type,
            attributes=attrs,
        )
        session.add(rel)
        await session.flush()

        return ToolResult(
            provider_slug="db",
            data={
                "relationship_id": str(rel.id),
                "from_record_id": str(from_id),
                "to_record_id": str(to_id),
                "relationship_type": rel_type,
            },
        )
