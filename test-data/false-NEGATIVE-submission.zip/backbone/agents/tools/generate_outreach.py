"""GenerateOutreach — Stage 6 outreach tool."""
import uuid
from datetime import datetime, timezone
from typing import Any

import anthropic
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.core.config import settings
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.activity import Activity
from backbone.models.record import Record

MODEL = "claude-sonnet-4-5"

_SUBMIT_TOOL: dict[str, Any] = {
    "name": "submit_outreach",
    "description": "Submit the completed outreach email.",
    "input_schema": {
        "type": "object",
        "properties": {
            "subject": {
                "type": "string",
                "description": "Email subject line (max 60 characters, no clickbait).",
            },
            "body": {
                "type": "string",
                "description": "Email body in plain text. Under 200 words. No unsubscribe jargon.",
            },
            "personalization_elements": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Specific facts from signals or account data used to personalise.",
            },
            "personalization_score": {
                "type": "number",
                "description": "0.0–1.0 self-assessed personalisation quality.",
            },
            "tone": {
                "type": "string",
                "enum": ["formal", "conversational", "direct"],
            },
        },
        "required": [
            "subject",
            "body",
            "personalization_elements",
            "personalization_score",
            "tone",
        ],
    },
}


class GenerateOutreach(AgentTool):
    """Call Claude claude-sonnet-4-5 to generate a personalised outreach email."""

    name = "generate_outreach"
    description = (
        "Generate a personalised outreach email for a Contact using Claude claude-sonnet-4-5. "
        "Uses the value hypothesis, contact attributes, and account context to produce "
        "a subject line and body under 200 words. Always call request_human_review "
        "with the output before considering the workflow complete."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "contact_record_id": {
                    "type": "string",
                    "description": "UUID of the Contact Record to write the email for.",
                },
                "account_record_id": {
                    "type": "string",
                    "description": "UUID of the parent Account Record.",
                },
                "hypothesis": {
                    "type": "object",
                    "description": (
                        "Output of generate_hypothesis "
                        "(pain_points, value_propositions, etc.)."
                    ),
                },
            },
            "required": ["contact_record_id", "account_record_id", "hypothesis"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            contact_id = uuid.UUID(kwargs["contact_record_id"])
            account_id = uuid.UUID(kwargs["account_record_id"])
        except (ValueError, KeyError) as exc:
            raise ToolError(f"Invalid UUID: {exc}", retriable=False)

        hypothesis: dict = kwargs.get("hypothesis") or {}

        contact_res = await session.execute(select(Record).where(Record.id == contact_id))
        contact = contact_res.scalar_one_or_none()
        if contact is None:
            raise ToolError(f"Contact record {contact_id} not found.", retriable=False)

        account_res = await session.execute(select(Record).where(Record.id == account_id))
        account = account_res.scalar_one_or_none()
        if account is None:
            raise ToolError(f"Account record {account_id} not found.", retriable=False)

        ca = contact.attributes or {}
        aa = account.attributes or {}

        prompt = (
            f"Write a concise, personalised B2B outreach email.\n\n"
            f"Recipient:\n"
            f"  Name: {ca.get('first_name', '')} {ca.get('last_name', '')}\n"
            f"  Title: {ca.get('job_title', 'Unknown')}\n"
            f"  Department: {ca.get('department', 'Unknown')}\n\n"
            f"Their company:\n"
            f"  Name: {aa.get('company_name', 'Unknown')}\n"
            f"  Industry: {aa.get('industry', 'Unknown')}\n"
            f"  Size: {aa.get('employee_count', 'Unknown')} employees\n"
            f"  Stage: {aa.get('funding_stage', 'Unknown')}\n\n"
            f"Value hypothesis:\n"
            f"  Pain points: {hypothesis.get('pain_points', [])}\n"
            f"  Value props: {hypothesis.get('value_propositions', [])}\n"
            f"  Approach: {hypothesis.get('approach_summary', '')}\n\n"
            f"Rules:\n"
            f"- Under 200 words\n"
            f"- No generic openers ('I hope this finds you well')\n"
            f"- Reference one specific, concrete fact about the company\n"
            f"- One clear call to action\n"
            f"- No attachments, no links\n\n"
            f"Use the submit_outreach tool to return your answer."
        )

        client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        try:
            response = await client.messages.create(
                model=MODEL,
                max_tokens=1024,
                system=(
                    "You are an expert B2B copywriter. Write concise, personalised "
                    "outreach emails that are specific, relevant, and drive responses."
                ),
                tools=[_SUBMIT_TOOL],
                tool_choice={"type": "any"},
                messages=[{"role": "user", "content": prompt}],
                metadata={"user_id": str(run_id)},
            )
        except anthropic.APIError as exc:
            raise ToolError(
                f"Claude API error generating outreach: {exc}", retriable=True
            )

        for block in response.content:
            if hasattr(block, "type") and block.type == "tool_use":
                outreach: dict[str, Any] = dict(block.input)
                outreach["generated_at"] = datetime.now(timezone.utc).isoformat()
                outreach["contact_record_id"] = str(contact_id)
                outreach["account_record_id"] = str(account_id)
                outreach["model"] = MODEL

                # Persist outreach draft as an Activity record so the data model
                # captures the generated copy (REQ_11: outreach stored in data model).
                activity = Activity(
                    tenant_id=contact.tenant_id,
                    record_ids=[contact_id, account_id],
                    activity_type="outreach_draft_created",
                    payload={
                        "subject": outreach.get("subject", ""),
                        "body": outreach.get("body", ""),
                        "contact_id": str(contact_id),
                        "personalization_score": outreach.get("personalization_score", 0.0),
                    },
                    agent_run_id=run_id,
                )
                session.add(activity)
                await session.flush()

                return ToolResult(
                    provider_slug="claude",
                    data=outreach,
                    meta={"usage": {
                        "input_tokens": response.usage.input_tokens,
                        "output_tokens": response.usage.output_tokens,
                    }},
                )

        raise ToolError("Claude did not return a structured outreach email.", retriable=True)
