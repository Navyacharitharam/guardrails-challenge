"""CreateActivity — cross-cutting audit-trail tool."""
import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tools.base import AgentTool
from backbone.integrations.base import ToolError, ToolResult
from backbone.models.activity import Activity
from backbone.models.record import Record


class CreateActivity(AgentTool):
    """Append an immutable Activity event to the audit trail."""

    name = "create_activity"
    description = (
        "Record an activity event involving one or more Records. "
        "Use after enrichment, outreach generation, or any significant agent action "
        "to maintain an auditable history. activity_type should be a stable slug like "
        "'enrichment_completed', 'outreach_generated', 'signal_detected'."
    )

    @property
    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "record_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "UUIDs of Records involved in this activity.",
                },
                "activity_type": {
                    "type": "string",
                    "description": (
                        "Stable slug: 'enrichment_completed', 'outreach_generated', etc."
                    ),
                },
                "payload": {
                    "type": "object",
                    "description": "Activity-specific data (enrichment source, email copy, etc.).",
                },
            },
            "required": ["record_ids", "activity_type"],
        }

    async def execute(
        self, session: AsyncSession, run_id: uuid.UUID, **kwargs: Any
    ) -> ToolResult:
        try:
            record_ids = [uuid.UUID(rid) for rid in (kwargs.get("record_ids") or [])]
        except ValueError as exc:
            raise ToolError(f"Invalid record_id UUID: {exc}", retriable=False)

        if not record_ids:
            raise ToolError("record_ids must not be empty.", retriable=False)

        first_res = await session.execute(select(Record).where(Record.id == record_ids[0]))
        first_rec = first_res.scalar_one_or_none()
        if first_rec is None:
            raise ToolError(f"Record {record_ids[0]} not found.", retriable=False)

        activity = Activity(
            tenant_id=first_rec.tenant_id,
            record_ids=record_ids,
            activity_type=kwargs.get("activity_type", "agent_action"),
            payload=kwargs.get("payload") or {},
            agent_run_id=run_id,
        )
        session.add(activity)
        await session.flush()

        return ToolResult(
            provider_slug="db",
            data={
                "activity_id": str(activity.id),
                "activity_type": activity.activity_type,
                "record_ids": [str(r) for r in record_ids],
            },
        )
