"""Prospect workflow tool registration.

All 12 prospect tools are now defined in individual modules under
``backbone.agents.tools``.  This module exists for backwards compatibility
and to ensure all tools are registered when it is imported.

Importing ``backbone.agents.tools`` (the package) is sufficient to trigger
registration — this file is kept so that code which does
``import backbone.agents.prospect_tools`` continues to work without changes.
"""

# Importing the tools package registers all 12 prospect tools plus the two
# built-in control-flow tools (complete_workflow, request_human_review).
import backbone.agents.tools  # noqa: F401

# Re-export the tool classes so existing code that imported them from here
# can continue to do so without modification.
from backbone.agents.tools import (
    ComputeIntentScore,
    CreateActivity,
    CreateRelationship,
    DiscoverCompanies,
    EnrichContact,
    GenerateHypothesis,
    GenerateOutreach,
    GetSignals,
    LoadICP,
    ScoreCompanyFit,
    UpsertRecord,
    VerifyEmail,
)

__all__ = [
    "LoadICP",
    "ScoreCompanyFit",
    "DiscoverCompanies",
    "UpsertRecord",
    "CreateRelationship",
    "CreateActivity",
    "VerifyEmail",
    "EnrichContact",
    "GetSignals",
    "ComputeIntentScore",
    "GenerateHypothesis",
    "GenerateOutreach",
]
