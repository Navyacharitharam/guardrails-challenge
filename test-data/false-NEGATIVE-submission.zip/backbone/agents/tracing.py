"""AgentStep persistence helpers — the write-before/write-after tracing contract.

CLAUDE.md rule #4 requires that every AgentStep is written to the database
BEFORE the corresponding operation executes and updated AFTER — even on
failure.  A process crash between the two writes leaves the step in status
RUNNING, which monitoring can detect as a stale/hung step.

These helpers are extracted from the orchestrator so they can be reused by
custom workflow implementations and tested independently.
"""
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.models.agent_run import AgentRun
from backbone.models.agent_step import AgentStep
from backbone.models.enums import AgentStepStatus, AgentStepType


async def next_step_number(session: AsyncSession, run_id: uuid.UUID) -> int:
    """Return one higher than the current max step_number for this run.

    Safe to call concurrently: two callers racing will each get different
    numbers because ``flush()`` is called inside a transaction that serialises
    the inserts.
    """
    result = await session.execute(
        select(AgentStep.step_number)
        .where(AgentStep.run_id == run_id)
        .order_by(AgentStep.step_number.desc())
        .limit(1)
    )
    last = result.scalar_one_or_none()
    return (last or 0) + 1


async def write_step(
    session: AsyncSession,
    *,
    run: AgentRun,
    step_number: int,
    step_type: AgentStepType,
    tool_name: str | None = None,
    reasoning: str | None = None,
    input_payload: dict[str, Any],
) -> AgentStep:
    """Persist a new AgentStep in RUNNING status — the 'before' write.

    Args:
        session: Open async session with tenant context set.
        run: The owning ``AgentRun`` (provides tenant_id and run_id).
        step_number: Sequential number within the run (1-based).
        step_type: ``LLM_CALL``, ``TOOL_CALL``, ``HUMAN_GATE``, or ``ERROR``.
        tool_name: Tool name for ``TOOL_CALL`` steps; ``None`` otherwise.
        reasoning: LLM text explaining why this step was chosen.
        input_payload: Structured inputs to the operation.

    Returns:
        The persisted ``AgentStep`` with ``id`` populated by the flush.
    """
    step = AgentStep(
        tenant_id=run.tenant_id,
        run_id=run.id,
        step_number=step_number,
        step_type=step_type,
        tool_name=tool_name,
        reasoning=reasoning or None,
        input_payload=input_payload,
        status=AgentStepStatus.RUNNING,
        started_at=datetime.now(timezone.utc),
    )
    session.add(step)
    await session.flush()
    return step


async def complete_step(
    session: AsyncSession,
    step: AgentStep,
    output_payload: dict[str, Any],
    duration_ms: int,
) -> None:
    """Mark a step COMPLETED with its output — the 'after' write on success.

    Args:
        session: The same session the step was created in.
        step: The step to update (mutated in place).
        output_payload: Structured result of the operation.
        duration_ms: Wall-clock milliseconds the operation took.
    """
    step.status = AgentStepStatus.COMPLETED
    step.output_payload = output_payload
    step.completed_at = datetime.now(timezone.utc)
    step.duration_ms = duration_ms
    await session.flush()


async def fail_step(
    session: AsyncSession,
    step: AgentStep,
    error_message: str,
    duration_ms: int,
) -> None:
    """Mark a step FAILED — the 'after' write on error.

    Args:
        session: The same session the step was created in.
        step: The step to update (mutated in place).
        error_message: Human-readable error description (truncated to 2048 chars).
        duration_ms: Wall-clock milliseconds until failure.
    """
    step.status = AgentStepStatus.FAILED
    step.error_message = error_message[:2048]
    step.completed_at = datetime.now(timezone.utc)
    step.duration_ms = duration_ms
    await session.flush()
