"""AgentContext — immutable snapshot of an agent run's execution state.

The orchestrator constructs an ``AgentContext`` at the start of a run and
threads it through the loop.  Storing all mutable state in the database
(not in this object) means the context can be reconstructed from scratch
after a process restart, enabling reliable resumption of suspended runs.
"""
import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentContext:
    """Snapshot of an agent run's execution state at a single loop iteration.

    Attributes:
        run_id: Primary key of the ``AgentRun`` being executed.
        tenant_id: Tenant owning this run (used for RLS context and logging).
        workflow_type: Stable workflow slug (e.g. ``"prospect"``).
        system_prompt: Full system prompt passed to Claude on every API call.
        messages: Anthropic message history for the current run (grows each
            iteration as assistant and tool-result turns are appended).
        step_counter: Next sequential step number to assign.  Monotonically
            increasing; never reused within a run.
        icp_id: Optional ICP the run is targeting (prospect workflow only).
        input_payload: Raw user-supplied parameters from ``AgentRun.input_payload``.
    """

    run_id: uuid.UUID
    tenant_id: uuid.UUID
    workflow_type: str
    system_prompt: str
    messages: list[dict[str, Any]] = field(default_factory=list)
    step_counter: int = 1
    icp_id: uuid.UUID | None = None
    input_payload: dict[str, Any] = field(default_factory=dict)

    def advance_step(self) -> int:
        """Return the current step number and increment the counter.

        Used by the orchestrator when writing a new AgentStep::

            step_number = ctx.advance_step()
        """
        current = self.step_counter
        self.step_counter += 1
        return current

    def append_assistant_turn(self, content: list[Any]) -> None:
        """Add an assistant message to the conversation history."""
        self.messages.append({"role": "assistant", "content": content})

    def append_tool_results(self, results: list[dict[str, Any]]) -> None:
        """Add a batch of tool result messages to the conversation history."""
        if results:
            self.messages.append({"role": "user", "content": results})
