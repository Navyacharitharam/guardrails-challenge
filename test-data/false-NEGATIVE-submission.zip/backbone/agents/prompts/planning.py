"""Planning prompts for multi-stage workflow decomposition.

These prompts are passed to Claude when the orchestrator needs the agent to
reason about *which* sub-goals to pursue before diving into tool calls.
Using a separate planning turn is optional — the main prospect workflow
doesn't require it because the stage order is deterministic.  Custom
workflows with branching logic (e.g. ABM vs. PLG) can inject planning
prompts before the main tool-use loop.
"""
from typing import Any

PROSPECT_PLANNING_PROMPT = """\
Before using any tools, outline a concise execution plan for the prospect workflow:

1. ICP loading — identify which ICP criteria matter most.
2. Discovery — how many accounts to evaluate and your minimum fit threshold.
3. Enrichment — which contacts to prioritise for email verification.
4. Signals — which signal types are most relevant given the ICP's weights.
5. Hypothesis — what evidence you need before generating a hypothesis.
6. Outreach — confirm you will request_human_review before completing.

Keep the plan to 6–8 bullet points. Do not call any tools yet.
"""

ENRICHMENT_PLANNING_PROMPT = """\
Before enriching contacts, plan your enrichment strategy:

1. Which contacts lack a verified email and have complete first/last name data.
2. The order in which to enrich (prioritise by fit_score descending).
3. What to do if the enrichment waterfall fails for a contact.
4. Maximum number of contacts to enrich in this run (default: 5).

State your plan, then proceed with tool calls.
"""


def build_planning_message(workflow_type: str, context: dict[str, Any] | None = None) -> str:
    """Return the planning prompt for a given workflow type.

    Args:
        workflow_type: Stable workflow slug (e.g. ``"prospect"``).
        context: Optional additional context dict to interpolate.

    Returns:
        Planning prompt string, or an empty string if no planning prompt is
        defined for the given workflow type.
    """
    _PROMPTS: dict[str, str] = {
        "prospect": PROSPECT_PLANNING_PROMPT,
        "enrichment": ENRICHMENT_PLANNING_PROMPT,
    }
    return _PROMPTS.get(workflow_type, "")
