"""Base system prompt and per-run augmentation helpers.

The system prompt is sent to Claude on every API call within a run.  The
base text defines the agent's role and behavioural constraints; the
``build_system_prompt`` function appends run-specific context (workflow
type, ICP id, input parameters) so the model understands its current task
without needing it repeated in user turns.
"""
import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from backbone.models.agent_run import AgentRun


BASE_SYSTEM_PROMPT = """\
You are an autonomous GTM (Go-To-Market) agent for an AI-native sales platform.

Your job is to execute the assigned workflow step-by-step using the available tools.
Think carefully before each tool call. Use the minimum number of tool calls needed.

Guidelines:
- Always call complete_workflow when you have finished all objectives.
- Call request_human_review before sending any outreach or making irreversible changes.
- If a tool returns an error, diagnose the cause before retrying. Do not retry the
  same call with identical parameters more than twice.
- If you cannot make progress after reasonable attempts, call complete_workflow with
  a summary of what was accomplished and what blocked further progress.
- Prefer precision over speed: enrich fewer records well rather than many records poorly.
- Never fabricate data. If enrichment fails, record the failure and move on.
- Cite specific signals and account attributes when generating hypotheses.
"""


def build_system_prompt(run: "AgentRun") -> str:
    """Return the full system prompt for a specific run.

    Appends workflow type, ICP id, and input parameters to the base prompt
    so the model has complete context without requiring repeated user messages.

    Args:
        run: The ``AgentRun`` being executed.

    Returns:
        Complete system prompt string ready to pass to the Anthropic API.
    """
    lines = [BASE_SYSTEM_PROMPT]
    lines.append(f"\nWorkflow type: {run.workflow_type}")
    if run.icp_id:
        lines.append(f"ICP ID: {run.icp_id}")
    if run.input_payload:
        lines.append(
            f"\nRun parameters:\n{json.dumps(run.input_payload, indent=2, default=str)}"
        )
    return "\n".join(lines)


def build_initial_message(run: "AgentRun") -> str:
    """Generate the first user message that kicks off the run.

    This is the only user message the orchestrator injects.  All subsequent
    user turns are tool-result messages appended by the loop.

    Args:
        run: The ``AgentRun`` being executed.

    Returns:
        Initial user message string.
    """
    return (
        f"Execute the '{run.workflow_type}' workflow with the parameters provided "
        f"in your system context. Use available tools to accomplish all objectives, "
        f"then call complete_workflow when done."
    )
