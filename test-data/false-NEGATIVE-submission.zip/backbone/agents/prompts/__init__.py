"""Agent prompt templates package.

Submodules:
    system   — Base system prompt and run-context augmentation helpers.
    planning — Planning prompts for multi-stage workflow decomposition.
"""
from backbone.agents.prompts.system import (
    BASE_SYSTEM_PROMPT,
    build_initial_message,
    build_system_prompt,
)

__all__ = [
    "BASE_SYSTEM_PROMPT",
    "build_system_prompt",
    "build_initial_message",
]
