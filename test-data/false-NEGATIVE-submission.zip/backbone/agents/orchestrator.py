"""Custom agent execution loop — no LangChain, no agent frameworks.

Loop invariant (CLAUDE.md rule #4):
  Every AgentStep is written to the database BEFORE the corresponding
  operation executes and updated AFTER — even on failure.  A process crash
  between the two writes leaves the step in status RUNNING, which the
  monitoring layer can detect as a stale/hung step.

Execution flow
--------------

  Orchestrator.run(run_id, session)
    │
    ├─ ① load_run_state       — fetch AgentRun, validate status
    │
    ├─ ② mark_run_running     — QUEUED → RUNNING, stamp started_at
    │
    └─ loop (max MAX_STEPS iterations):
         │
         ├─ ③ write llm_call step (RUNNING)
         │
         ├─ ④ call Claude claude-sonnet-4-5 with tool_use
         │
         ├─ ⑤ update llm_call step (COMPLETED)
         │
         ├─ branch on stop_reason:
         │    end_turn   → mark COMPLETED, return
         │    tool_use   → process each tool_use block:
         │                   ⑥ write tool_call step (RUNNING)
         │                   ⑦ AgentTool.execute(session, run_id, **inputs)
         │                   ⑧ update step (COMPLETED / FAILED)
         │                 branch on outcome:
         │                   WorkflowCompleteSignal → mark COMPLETED, return
         │                   HumanGateSignal        → create HumanReview,
         │                                            keep RUNNING, return
         │                   ToolError(fatal)       → mark FAILED, raise
         │                   ToolError(retriable)   → add error tool_result,
         │                                            continue loop
         │                   success                → add tool_result,
         │                                            continue loop
         │
         └─ (exceeded MAX_STEPS) → mark FAILED
"""
import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import anthropic
import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.prompts.system import build_initial_message, build_system_prompt
from backbone.agents.tools import (
    AgentTool,
    HumanGateSignal,
    WorkflowCompleteSignal,
    all_tools,
    get_tool,
    tool_schemas,
)
from backbone.agents.tracing import complete_step, fail_step, next_step_number, write_step
from backbone.core.config import settings
from backbone.core.database.rls import set_tenant_context
from backbone.integrations.base import ToolError
from backbone.models.agent_run import AgentRun
from backbone.models.agent_step import AgentStep
from backbone.models.enums import (
    AgentRunStatus,
    AgentStepStatus,
    AgentStepType,
    HumanReviewStatus,
)
from backbone.models.human_review import HumanReview

log = structlog.get_logger(__name__)

MODEL = "claude-sonnet-4-5"
MAX_STEPS = 50  # Hard cap to prevent runaway loops
MAX_TOKENS = 4096

# ---------------------------------------------------------------------------
# Response helpers
# ---------------------------------------------------------------------------


def _extract_text_reasoning(content: list[Any]) -> str:
    """Concatenate all text blocks from a Claude response into a single string."""
    parts = [
        block.text
        for block in content
        if hasattr(block, "type") and block.type == "text" and block.text.strip()
    ]
    return " ".join(parts).strip()


def _content_to_json(content: list[Any]) -> dict[str, Any]:
    """Summarise a Claude response content list for AgentStep.output_payload."""
    return {
        "blocks": [
            {
                "type": getattr(b, "type", "unknown"),
                **({"text": b.text} if hasattr(b, "text") else {}),
                **({"name": b.name, "id": b.id} if hasattr(b, "name") else {}),
            }
            for b in content
        ]
    }


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------


async def _load_run(session: AsyncSession, run_id: uuid.UUID) -> AgentRun:
    result = await session.execute(
        select(AgentRun).where(AgentRun.id == run_id)
    )
    run = result.scalar_one_or_none()
    if run is None:
        raise OrchestratorError(f"AgentRun {run_id} not found.")
    return run


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class OrchestratorError(Exception):
    """Raised for unrecoverable orchestrator-level failures."""


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


class Orchestrator:
    """Stateless agent execution loop.

    Instantiate once and call ``run`` for each AgentRun.  The orchestrator
    holds no mutable state between runs — all state lives in the database.

    Args:
        max_steps: Maximum number of loop iterations before forcing failure.
            Prevents runaway agents; defaults to ``MAX_STEPS``.
    """

    def __init__(self, max_steps: int = MAX_STEPS) -> None:
        self.max_steps = max_steps
        self._client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def run(self, run_id: uuid.UUID, session: AsyncSession) -> None:
        """Execute an agent run to completion (or suspension).

        The session must already have the tenant context set via
        ``SELECT set_current_tenant('<tenant_id>')``.

        Args:
            run_id: The ``AgentRun.id`` to execute.
            session: Async session with RLS context set.

        Raises:
            OrchestratorError: If the run is not found, is in a terminal
                state, or exceeds the step limit.

        Side effects:
            - Transitions ``AgentRun.status`` from QUEUED → RUNNING → terminal.
            - Writes ``AgentStep`` records (before and after each operation).
            - Creates ``HumanReview`` records when human_gate is triggered.
        """
        # ① Load run state -------------------------------------------------
        run = await _load_run(session, run_id)

        if run.status not in (AgentRunStatus.QUEUED, AgentRunStatus.RUNNING):
            raise OrchestratorError(
                f"AgentRun {run_id} is already in terminal state '{run.status}'."
            )

        log.info("orchestrator.start", run_id=str(run_id), workflow=run.workflow_type)

        # ② Mark run RUNNING -----------------------------------------------
        run.status = AgentRunStatus.RUNNING
        run.started_at = run.started_at or datetime.now(timezone.utc)
        await session.flush()
        await session.commit()

        # Build conversation history
        system_prompt = build_system_prompt(run)
        messages: list[dict[str, Any]] = [
            {"role": "user", "content": build_initial_message(run)}
        ]
        schemas = tool_schemas()
        step_counter = await next_step_number(session, run.id)

        try:
            await self._loop(
                run=run,
                session=session,
                system_prompt=system_prompt,
                messages=messages,
                schemas=schemas,
                step_counter=step_counter,
            )
        except Exception:
            # Ensure the run is marked FAILED if an unexpected exception
            # escapes the loop (e.g. network error on the Claude API call).
            if run.status == AgentRunStatus.RUNNING:
                run.status = AgentRunStatus.FAILED
                run.completed_at = datetime.now(timezone.utc)
                await session.commit()
            raise

    async def _loop(
        self,
        run: AgentRun,
        session: AsyncSession,
        system_prompt: str,
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
        step_counter: int,
    ) -> None:
        """Inner loop — separated so the outer ``run()`` can wrap it cleanly."""
        iteration = 0

        while iteration < self.max_steps:
            iteration += 1

            # ③ Write llm_call step (BEFORE the Claude API call) -----------
            llm_step = await write_step(
                session,
                run=run,
                step_number=step_counter,
                step_type=AgentStepType.LLM_CALL,
                input_payload={
                    "model": MODEL,
                    "messages_count": len(messages),
                    "tools_available": [s["name"] for s in schemas],
                },
            )
            step_counter += 1
            await session.commit()

            # ④ Call Claude claude-sonnet-4-5 with tool_use ----------------
            t0 = time.monotonic()
            try:
                response = await self._client.messages.create(
                    model=MODEL,
                    max_tokens=MAX_TOKENS,
                    system=system_prompt,
                    tools=schemas,  # type: ignore[arg-type]
                    messages=messages,
                    metadata={"user_id": str(run.id)},
                )
            except anthropic.APIError as exc:
                await fail_step(
                    session, llm_step,
                    error_message=f"Anthropic API error: {exc}",
                    duration_ms=int((time.monotonic() - t0) * 1000),
                )
                run.status = AgentRunStatus.FAILED
                run.error_message = str(exc)[:2048]
                run.completed_at = datetime.now(timezone.utc)
                await session.commit()
                raise OrchestratorError(f"Claude API call failed: {exc}") from exc

            llm_duration = int((time.monotonic() - t0) * 1000)

            # ⑤ Update llm_call step (AFTER) --------------------------------
            await complete_step(
                session, llm_step,
                output_payload={
                    "stop_reason": response.stop_reason,
                    "model": response.model,
                    "usage": {
                        "input_tokens": response.usage.input_tokens,
                        "output_tokens": response.usage.output_tokens,
                    },
                    **_content_to_json(response.content),
                },
                duration_ms=llm_duration,
            )
            await session.commit()

            log.debug(
                "orchestrator.llm_response",
                run_id=str(run.id),
                stop_reason=response.stop_reason,
                iteration=iteration,
            )

            # Add assistant turn to history
            messages.append({"role": "assistant", "content": response.content})

            # ⑥ Branch on stop_reason --------------------------------------
            if response.stop_reason == "end_turn":
                text = _extract_text_reasoning(response.content)
                await self._complete_run(session, run, output={"final_message": text})
                return

            if response.stop_reason != "tool_use":
                # Unexpected stop reason (max_tokens, content_filter, etc.)
                await self._fail_run(
                    session, run,
                    reason=f"Unexpected stop_reason: {response.stop_reason}",
                )
                return

            # ⑦ Process tool_use blocks ------------------------------------
            reasoning = _extract_text_reasoning(response.content)
            tool_results: list[dict[str, Any]] = []
            should_break = False

            for block in response.content:
                if not hasattr(block, "type") or block.type != "tool_use":
                    continue

                tool_name: str = block.name
                tool_input: dict[str, Any] = dict(block.input or {})
                tool_use_id: str = block.id

                step_type = (
                    AgentStepType.HUMAN_GATE
                    if tool_name == "request_human_review"
                    else AgentStepType.TOOL_CALL
                )

                # ⑧ Write tool step (BEFORE execution) --------------------
                tool_step = await write_step(
                    session,
                    run=run,
                    step_number=step_counter,
                    step_type=step_type,
                    tool_name=tool_name,
                    reasoning=reasoning,
                    input_payload=tool_input,
                )
                step_counter += 1
                await session.commit()

                tool = get_tool(tool_name)
                if tool is None:
                    err_msg = f"Unknown tool '{tool_name}'. Available: {[t.name for t in all_tools()]}"
                    await fail_step(
                        session, tool_step,
                        error_message=err_msg,
                        duration_ms=0,
                    )
                    tool_results.append(
                        _error_result(tool_use_id, err_msg)
                    )
                    await session.commit()
                    continue

                # Execute the tool -----------------------------------------
                t_tool = time.monotonic()
                outcome = await self._dispatch(
                    tool=tool,
                    session=session,
                    run=run,
                    tool_step=tool_step,
                    tool_use_id=tool_use_id,
                    tool_input=tool_input,
                    tool_results=tool_results,
                    step_counter=step_counter,
                )
                _ = int((time.monotonic() - t_tool) * 1000)  # timing logged inside

                await session.commit()

                if outcome == "complete":
                    should_break = True
                    break
                if outcome == "human_gate":
                    return  # Run stays RUNNING; suspended for review.
                if outcome == "fatal":
                    return  # Run already marked FAILED inside _dispatch.

                # outcome == "continue": add result and keep looping

            # Append all tool results as a single user turn
            if tool_results:
                messages.append({"role": "user", "content": tool_results})

            if should_break:
                return

        # Exceeded max_steps -----------------------------------------------
        await self._fail_run(
            session, run,
            reason=f"Exceeded maximum step limit ({self.max_steps}).",
        )

    async def _dispatch(
        self,
        *,
        tool: AgentTool,
        session: AsyncSession,
        run: AgentRun,
        tool_step: AgentStep,
        tool_use_id: str,
        tool_input: dict[str, Any],
        tool_results: list[dict[str, Any]],
        step_counter: int,
    ) -> str:
        """Execute one tool call and update step + tool_results in-place.

        Returns a string outcome code:
          ``"continue"``   — success or retriable error; loop should continue.
          ``"complete"``   — WorkflowCompleteSignal received; run done.
          ``"human_gate"`` — HumanGateSignal received; run suspended.
          ``"fatal"``      — ToolError(retriable=False); run marked FAILED.
        """
        t0 = time.monotonic()

        # Re-stamp the RLS tenant context before every tool execution.
        # The orchestrator commits multiple times between tool calls; each
        # commit ends the transaction and clears any is_local=TRUE set_config.
        # Re-setting here ensures tools that query the DB (e.g. waterfall
        # _load_active_connections) always see the correct tenant rows.
        await set_tenant_context(session, run.tenant_id)

        try:
            result = await tool.execute(
                session=session,
                run_id=run.id,
                **tool_input,
            )
        except WorkflowCompleteSignal as sig:
            duration_ms = int((time.monotonic() - t0) * 1000)
            await complete_step(
                session, tool_step,
                output_payload=sig.output,
                duration_ms=duration_ms,
            )
            tool_results.append(
                _ok_result(tool_use_id, f"Workflow complete. {sig.output.get('summary', '')}")
            )
            await self._complete_run(session, run, output=sig.output)
            log.info("orchestrator.complete", run_id=str(run.id))
            return "complete"

        except HumanGateSignal as gate:
            duration_ms = int((time.monotonic() - t0) * 1000)
            # Step stays RUNNING (pending human decision); step_type already HUMAN_GATE
            tool_step.status = AgentStepStatus.PENDING
            tool_step.duration_ms = duration_ms
            await session.flush()

            review = HumanReview(
                tenant_id=run.tenant_id,
                run_id=run.id,
                step_id=tool_step.id,
                review_type=gate.review_type,
                proposed_output=gate.proposed_output,
                context=gate.context,
                status=HumanReviewStatus.PENDING,
            )
            session.add(review)
            await session.flush()

            log.info(
                "orchestrator.human_gate",
                run_id=str(run.id),
                review_type=gate.review_type.value,
                review_id=str(review.id),
            )
            return "human_gate"

        except ToolError as exc:
            duration_ms = int((time.monotonic() - t0) * 1000)
            await fail_step(
                session, tool_step,
                error_message=str(exc),
                duration_ms=duration_ms,
            )
            log.warning(
                "orchestrator.tool_error",
                run_id=str(run.id),
                tool=tool.name,
                retriable=exc.retriable,
                error=str(exc),
            )

            if exc.retriable:
                tool_results.append(_error_result(tool_use_id, str(exc)))
                return "continue"

            # Fatal tool error
            tool_results.append(_error_result(tool_use_id, f"FATAL: {exc}"))
            await self._fail_run(session, run, reason=f"{tool.name}: {exc}")
            return "fatal"

        except Exception as exc:
            # Unexpected exception — treat as fatal.
            duration_ms = int((time.monotonic() - t0) * 1000)
            await fail_step(
                session, tool_step,
                error_message=f"Unexpected error: {exc}",
                duration_ms=duration_ms,
            )
            await self._fail_run(
                session, run,
                reason=f"Unexpected error in {tool.name}: {exc}",
            )
            raise

        # ⑧ Update tool step (AFTER success) --------------------------------
        duration_ms = int((time.monotonic() - t0) * 1000)
        await complete_step(
            session, tool_step,
            output_payload=result.data,
            duration_ms=duration_ms,
        )
        tool_results.append(
            _ok_result(tool_use_id, json.dumps(result.data, default=str))
        )
        log.debug(
            "orchestrator.tool_success",
            run_id=str(run.id),
            tool=tool.name,
            provider=result.provider_slug,
        )
        return "continue"

    # ------------------------------------------------------------------
    # Run-level state transitions
    # ------------------------------------------------------------------

    @staticmethod
    async def _complete_run(
        session: AsyncSession,
        run: AgentRun,
        output: dict[str, Any],
    ) -> None:
        run.status = AgentRunStatus.COMPLETED
        run.output_payload = output
        run.completed_at = datetime.now(timezone.utc)
        await session.flush()
        await session.commit()

    @staticmethod
    async def _fail_run(
        session: AsyncSession,
        run: AgentRun,
        reason: str,
    ) -> None:
        run.status = AgentRunStatus.FAILED
        run.error_message = reason[:2048]
        run.completed_at = datetime.now(timezone.utc)
        await session.flush()
        await session.commit()
        log.error("orchestrator.run_failed", run_id=str(run.id), reason=reason)


# ---------------------------------------------------------------------------
# Tool-result helpers
# ---------------------------------------------------------------------------


def _ok_result(tool_use_id: str, content: str) -> dict[str, Any]:
    return {"type": "tool_result", "tool_use_id": tool_use_id, "content": content}


def _error_result(tool_use_id: str, message: str) -> dict[str, Any]:
    return {
        "type": "tool_result",
        "tool_use_id": tool_use_id,
        "content": message,
        "is_error": True,
    }
