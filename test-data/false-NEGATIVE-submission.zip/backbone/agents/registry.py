"""Top-level re-export of the tool registry for convenient access.

Callers can import from either location:

    from backbone.agents.registry import get_tool, register_tool
    from backbone.agents.tools.registry import get_tool, register_tool   # same

Importing this module does NOT trigger tool registration — import
``backbone.agents.tools`` to ensure all tools are registered first.
"""
from backbone.agents.tools.registry import (
    all_tools,
    get_tool,
    register_tool,
    tool_schemas,
)

__all__ = ["register_tool", "get_tool", "all_tools", "tool_schemas"]
