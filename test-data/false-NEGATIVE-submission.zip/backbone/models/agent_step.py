import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backbone.core.database.base import Base
from backbone.models.enums import AgentStepStatus, AgentStepType


class AgentStep(Base):
    """A single step within an AgentRun — the atom of agent tracing.

    The orchestrator writes a step record BEFORE executing the tool and
    updates it AFTER, per CLAUDE.md rule #4. This gives a complete audit
    trail even if the process dies mid-execution.

    ``input_payload`` / ``output_payload`` hold the raw tool inputs and
    outputs so the trace viewer can render them as structured JSON.
    ``reasoning`` is the LLM's natural-language explanation of why it
    chose this tool call.
    """

    __tablename__ = "agent_steps"
    __table_args__ = (
        Index("ix_agent_steps_tenant_run", "tenant_id", "run_id"),
        Index("ix_agent_steps_run_number", "run_id", "step_number"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agent_runs.id", ondelete="CASCADE"),
        nullable=False,
    )
    # 1-based execution order within the run
    step_number: Mapped[int] = mapped_column(Integer, nullable=False)
    step_type: Mapped[AgentStepType] = mapped_column(
        SAEnum(
            AgentStepType,
            name="agent_step_type_enum",
            native_enum=False,
            values_callable=lambda x: [e.value for e in x],
        ),
        nullable=False,
    )
    # Null for llm_call and human_gate steps
    tool_name: Mapped[Optional[str]] = mapped_column(String(63), nullable=True)
    # LLM-generated explanation of why this step was chosen
    reasoning: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # Typed inputs passed to the tool or LLM
    input_payload: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    # Populated on completion; null while status is PENDING or RUNNING
    output_payload: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    status: Mapped[AgentStepStatus] = mapped_column(
        SAEnum(
            AgentStepStatus,
            name="agent_step_status_enum",
            native_enum=False,
            values_callable=lambda x: [e.value for e in x],
        ),
        server_default=AgentStepStatus.PENDING.value,
        nullable=False,
    )
    error_message: Mapped[Optional[str]] = mapped_column(String(2048), nullable=True)
    # Wall-clock milliseconds for performance observability
    duration_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    run: Mapped["AgentRun"] = relationship(  # type: ignore[name-defined]
        "AgentRun", back_populates="steps", lazy="raise"
    )
