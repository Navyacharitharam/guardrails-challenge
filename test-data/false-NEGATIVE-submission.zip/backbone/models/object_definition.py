import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from backbone.core.database.base import Base


class ObjectDefinition(Base):
    """Defines a named CRM object type (Account, Contact, Lead …) for a tenant.

    Records reference an ObjectDefinition to declare their "type". The
    schema_definition JSONB stores the field spec — names, types, and
    whether each field is required — so tenants can extend the schema
    without migrations.
    """

    __tablename__ = "object_definitions"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "slug", name="uq_object_definitions_tenant_slug"
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # URL-safe identifier used in API paths and agent tool inputs
    slug: Mapped[str] = mapped_column(String(63), nullable=False)
    # JSON Schema-like field definitions: [{name, type, required}]
    schema_definition: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
