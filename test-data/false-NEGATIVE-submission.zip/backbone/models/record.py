import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Enum as SAEnum, Float, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backbone.core.database.base import Base
from backbone.models.enums import EnrichmentStatus


class Record(Base):
    """A CRM record — an Account, Contact, Lead, or any ObjectDefinition type.

    All domain objects live in this single table. The object_definition_id
    determines the type. The ``attributes`` JSONB column holds all typed
    fields (company name, industry, headcount, email, etc.) as defined by the
    ObjectDefinition's schema_definition.

    RLS policy: tenant_id must equal app.current_tenant for all DML/SELECT.
    """

    __tablename__ = "records"
    __table_args__ = (
        Index("ix_records_tenant_object", "tenant_id", "object_definition_id"),
        Index("ix_records_tenant_external", "tenant_id", "external_id"),
        # GIN index on attributes is created in migration 002 via raw DDL
        # because SQLAlchemy Index() doesn't expose postgresql_using directly
        # for JSONB columns in a clean way at model definition time.
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    object_definition_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("object_definitions.id", ondelete="RESTRICT"),
        nullable=False,
    )
    # Stable external identifier for upsert deduplication (domain, CRM ID, etc.)
    external_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    # All typed fields for this record (company_name, industry, headcount, email, …)
    attributes: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    # Computed by icp_scorer.py against the active ICP — null until scored
    fit_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    # Aggregated from Signal.score values by intent_scorer.py — null until scored
    intent_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    enrichment_status: Mapped[EnrichmentStatus] = mapped_column(
        SAEnum(
            EnrichmentStatus,
            name="enrichment_status_enum",
            native_enum=False,
            values_callable=lambda x: [e.value for e in x],
        ),
        server_default=EnrichmentStatus.UNENRICHED.value,
        nullable=False,
        index=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    # Relationships (selectin avoids N+1 in async context)
    signals: Mapped[list["Signal"]] = relationship(  # type: ignore[name-defined]
        "Signal", back_populates="record", lazy="selectin"
    )
