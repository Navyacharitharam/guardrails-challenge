import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum as SAEnum, Float, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backbone.core.database.base import Base
from backbone.models.enums import SignalType


class Signal(Base):
    """An intelligence signal observed about a Record.

    Examples: a funding announcement, a senior hire, a job posting that
    signals a technology adoption, an intent spike from web activity.

    Signals feed ``intent_scorer.py`` which aggregates them into
    ``Record.intent_score`` using the active ICP's ``signal_weights``.
    """

    __tablename__ = "signals"
    __table_args__ = (
        Index("ix_signals_tenant_record", "tenant_id", "record_id"),
        Index("ix_signals_tenant_type", "tenant_id", "signal_type"),
        Index("ix_signals_occurred_at", "tenant_id", "occurred_at"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    # The Account or Contact this signal is about
    record_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("records.id", ondelete="CASCADE"),
        nullable=False,
    )
    signal_type: Mapped[SignalType] = mapped_column(
        SAEnum(
            SignalType,
            name="signal_type_enum",
            native_enum=False,
            values_callable=lambda x: [e.value for e in x],
        ),
        nullable=False,
    )
    # Data source slug: "crunchbase", "hunter", "apollo", "web_scrape", etc.
    source: Mapped[str] = mapped_column(String(63), nullable=False)
    # Signal-specific data: funding amount + round, job title, technology slug, etc.
    payload: Mapped[dict] = mapped_column(JSONB, server_default="{}", nullable=False)
    # Normalised importance: 0.0 (noise) → 1.0 (strongest possible signal)
    score: Mapped[float] = mapped_column(Float, nullable=False, default=0.5)
    # When the underlying event happened (not when we detected it)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    record: Mapped["Record"] = relationship(  # type: ignore[name-defined]
        "Record", back_populates="signals", lazy="raise"
    )
