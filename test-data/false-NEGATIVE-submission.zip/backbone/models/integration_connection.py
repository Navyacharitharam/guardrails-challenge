import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from backbone.core.database.base import Base


class IntegrationConnection(Base):
    """A tenant's connected instance of an external provider.

    ``credentials`` stores the Fernet-encrypted JSON blob containing API keys
    or OAuth tokens. It is NEVER stored in plain text (CLAUDE.md rule #5).
    Decrypt with ``backbone.core.security.encryption.decrypt_credentials``.

    ``rate_limit_state`` tracks provider-specific rate limit info so the
    waterfall resolver can skip exhausted providers:
    ``{"calls_remaining": 23, "reset_at": "2025-03-01T00:00:00Z"}``
    """

    __tablename__ = "integration_connections"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "provider_slug",
            name="uq_integration_connections_tenant_provider",
        ),
        Index("ix_integration_connections_tenant_active", "tenant_id", "is_active"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    # Stable identifier matching BaseIntegration.slug: "hunter", "apollo", "clearbit"
    provider_slug: Mapped[str] = mapped_column(String(63), nullable=False)
    # Human-readable label (e.g. "Hunter.io (prod)")
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)
    # Fernet-encrypted JSON: {"api_key": "..."} or {"access_token": "...", "refresh_token": "..."}
    credentials: Mapped[str] = mapped_column(Text, nullable=False)
    is_active: Mapped[bool] = mapped_column(
        Boolean, server_default="true", nullable=False
    )
    # Mutable JSON tracking calls_remaining, reset_at, last_error, etc.
    rate_limit_state: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    last_used_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
