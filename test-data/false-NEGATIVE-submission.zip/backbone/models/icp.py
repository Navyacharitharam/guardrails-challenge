import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from backbone.core.database.base import Base


class ICP(Base):
    """Ideal Customer Profile — defines who a tenant wants to sell to.

    Three JSONB criteria fields let the scorer weight different dimensions:

    - ``firmographic_criteria``: industry, employee_count range, ARR range,
      geography, funding_stage list.
    - ``technographic_criteria``: technologies the company must / must-not use.
    - ``persona_criteria``: target contact job_titles, seniority levels,
      departments.

    ``signal_weights`` maps SignalType values to 0-1 floats so intent_scorer
    can compute a weighted aggregate across signal types.

    Example::

        {
            "firmographic_criteria": {
                "industries": ["SaaS", "FinTech"],
                "employee_count": {"min": 50, "max": 1000},
                "funding_stages": ["Series A", "Series B", "Series C"]
            },
            "signal_weights": {
                "funding": 0.9,
                "hiring": 0.6,
                "intent": 0.8
            }
        }
    """

    __tablename__ = "icps"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, server_default="", nullable=False)
    firmographic_criteria: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    technographic_criteria: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    persona_criteria: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    # {signal_type_value: float weight} — used by intent_scorer
    signal_weights: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, server_default="true", nullable=False, index=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
