import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backbone.core.database.base import Base
from backbone.models.enums import AgentRunStatus


class AgentRun(Base):
    """A single execution of an agent workflow (e.g. the 6-stage Prospect loop).

    Created when a user triggers a run. Status transitions:
    QUEUED → RUNNING → COMPLETED | FAILED | CANCELLED

    ``input_payload`` captures what the user passed (ICP ID, seed accounts, etc.).
    ``output_payload`` captures the final results once the run completes.
    """

    __tablename__ = "agent_runs"
    __table_args__ = (
        Index("ix_agent_runs_tenant_status", "tenant_id", "status"),
        Index("ix_agent_runs_tenant_created", "tenant_id", "created_at"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    # e.g. "prospect" — identifies which workflow to execute
    workflow_type: Mapped[str] = mapped_column(String(63), nullable=False, index=True)
    status: Mapped[AgentRunStatus] = mapped_column(
        SAEnum(
            AgentRunStatus,
            name="agent_run_status_enum",
            native_enum=False,
            values_callable=lambda x: [e.value for e in x],
        ),
        server_default=AgentRunStatus.QUEUED.value,
        nullable=False,
    )
    # The ICP this run is prospecting for (null for non-prospect workflows)
    icp_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("icps.id", ondelete="SET NULL"),
        nullable=True,
    )
    # User-supplied parameters (seed_accounts, filters, etc.)
    input_payload: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    # Populated on completion: discovered accounts, scored contacts, outreach drafts
    output_payload: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    error_message: Mapped[Optional[str]] = mapped_column(String(2048), nullable=True)
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    steps: Mapped[list["AgentStep"]] = relationship(  # type: ignore[name-defined]
        "AgentStep",
        back_populates="run",
        order_by="AgentStep.step_number",
        lazy="selectin",
    )
    reviews: Mapped[list["HumanReview"]] = relationship(  # type: ignore[name-defined]
        "HumanReview", back_populates="run", lazy="selectin"
    )
