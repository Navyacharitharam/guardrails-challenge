import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from backbone.core.database.base import Base


class RecordRelationship(Base):
    """A typed, directed edge between two Records.

    Examples: (Contact) --works_at--> (Account)
              (Account) --partner_of--> (Account)

    Named RecordRelationship to avoid shadowing SQLAlchemy's ``relationship``
    function in import namespaces.
    """

    __tablename__ = "record_relationships"
    __table_args__ = (
        Index(
            "ix_record_relationships_tenant_from",
            "tenant_id",
            "from_record_id",
        ),
        Index(
            "ix_record_relationships_tenant_to",
            "tenant_id",
            "to_record_id",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    from_record_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("records.id", ondelete="CASCADE"),
        nullable=False,
    )
    to_record_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("records.id", ondelete="CASCADE"),
        nullable=False,
    )
    # Verb-form type: "works_at", "reports_to", "partner_of", "invested_in"
    relationship_type: Mapped[str] = mapped_column(
        String(63), nullable=False, index=True
    )
    # Extra edge attributes (start_date, ownership_pct, etc.)
    attributes: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
