import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from backbone.core.database.base import Base


class Activity(Base):
    """An event or action involving one or more Records.

    Activities form the immutable audit trail: enrichment calls, outreach
    generation, signal detections, agent decisions. ``record_ids`` is a
    PostgreSQL array so a single Activity can reference multiple parties
    (e.g. an email involves both a Contact and its parent Account).
    """

    __tablename__ = "activities"
    __table_args__ = (
        Index("ix_activities_tenant_type", "tenant_id", "activity_type"),
        Index("ix_activities_tenant_run", "tenant_id", "agent_run_id"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    # All Records involved in this activity (PostgreSQL array, GIN-indexed in migration)
    record_ids: Mapped[list[uuid.UUID]] = mapped_column(
        ARRAY(UUID(as_uuid=True)),
        server_default="{}",
        nullable=False,
    )
    # e.g. "enrichment_completed", "outreach_generated", "signal_detected"
    activity_type: Mapped[str] = mapped_column(String(63), nullable=False)
    # Activity-specific data (enrichment source, outreach copy, signal detail, etc.)
    payload: Mapped[dict] = mapped_column(JSONB, server_default="{}", nullable=False)
    # Null for manual or system activities; set when triggered by an agent run
    agent_run_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agent_runs.id", ondelete="SET NULL"),
        nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
