import enum


class EnrichmentStatus(str, enum.Enum):
    """Lifecycle state of a Record's enrichment."""

    UNENRICHED = "unenriched"
    ENRICHED = "enriched"
    FAILED = "failed"


class SignalType(str, enum.Enum):
    """Category of intelligence signal."""

    FUNDING = "funding"
    HIRING = "hiring"
    JOB_CHANGE = "job_change"
    INTENT = "intent"
    TECHNOGRAPHIC = "technographic"
    NEWS = "news"
    WEB_ACTIVITY = "web_activity"


class AgentRunStatus(str, enum.Enum):
    """Lifecycle state of an AgentRun."""

    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AgentStepType(str, enum.Enum):
    """What kind of work an AgentStep represents."""

    TOOL_CALL = "tool_call"
    LLM_CALL = "llm_call"
    HUMAN_GATE = "human_gate"
    ERROR = "error"


class AgentStepStatus(str, enum.Enum):
    """Execution state of a single AgentStep."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRIED = "retried"


class HumanReviewType(str, enum.Enum):
    """What the reviewer is being asked to approve."""

    HYPOTHESIS_APPROVAL = "hypothesis_approval"
    OUTREACH_APPROVAL = "outreach_approval"
    ENRICHMENT_VALIDATION = "enrichment_validation"


class HumanReviewStatus(str, enum.Enum):
    """Resolution state of a HumanReview."""

    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    MODIFIED = "modified"
