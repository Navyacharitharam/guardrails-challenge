import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from backbone.core.database.base import Base


class Tenant(Base):
    """Top-level tenant (organisation). No tenant_id — IS the tenant root."""

    __tablename__ = "tenants"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    # slug is used as the X-Tenant-ID header value and must be URL-safe
    slug: Mapped[str] = mapped_column(
        String(63), nullable=False, unique=True, index=True
    )
    # Admin credentials — one admin account per tenant for demo purposes
    admin_email: Mapped[str] = mapped_column(
        String(255), nullable=False, unique=True, index=True
    )
    admin_password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    # Arbitrary per-tenant configuration (feature flags, UI prefs, etc.)
    settings: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, server_default="true", nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
