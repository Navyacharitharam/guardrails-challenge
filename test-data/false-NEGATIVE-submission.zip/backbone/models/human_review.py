import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Index, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backbone.core.database.base import Base
from backbone.models.enums import HumanReviewStatus, HumanReviewType


class HumanReview(Base):
    """A gate in the agent loop that requires a human decision before proceeding.

    Created when the orchestrator hits a human_gate step (hypothesis or outreach
    approval). The run stays RUNNING and the worker polls for resolution.

    ``proposed_output`` is what the agent wants to commit (the hypothesis JSON
    or outreach draft). ``context`` is the supporting evidence the reviewer
    needs to make a decision. ``modified_output`` holds the reviewer's edited
    version when status is MODIFIED.
    """

    __tablename__ = "human_reviews"
    __table_args__ = (
        Index("ix_human_reviews_tenant_status", "tenant_id", "status"),
        Index("ix_human_reviews_tenant_run", "tenant_id", "run_id"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tenants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agent_runs.id", ondelete="CASCADE"),
        nullable=False,
    )
    # The specific AgentStep that created this review gate
    step_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agent_steps.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,  # One review per step
    )
    review_type: Mapped[HumanReviewType] = mapped_column(
        SAEnum(
            HumanReviewType,
            name="human_review_type_enum",
            native_enum=False,
            values_callable=lambda x: [e.value for e in x],
        ),
        nullable=False,
    )
    # The agent's proposed action (hypothesis or outreach draft)
    proposed_output: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    # Signals, enriched data, and reasoning supporting the proposal
    context: Mapped[dict] = mapped_column(
        JSONB, server_default="{}", nullable=False
    )
    status: Mapped[HumanReviewStatus] = mapped_column(
        SAEnum(
            HumanReviewStatus,
            name="human_review_status_enum",
            native_enum=False,
            values_callable=lambda x: [e.value for e in x],
        ),
        server_default=HumanReviewStatus.PENDING.value,
        nullable=False,
    )
    reviewer_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # Populated only when status = MODIFIED
    modified_output: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    resolved_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    run: Mapped["AgentRun"] = relationship(  # type: ignore[name-defined]
        "AgentRun", back_populates="reviews", lazy="raise"
    )
