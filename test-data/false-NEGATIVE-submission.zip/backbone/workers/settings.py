"""ARQ worker configuration.

Run the worker with:
    python -m arq backbone.workers.settings.WorkerSettings
"""
import os
from urllib.parse import urlparse

import structlog
from arq.connections import RedisSettings

from backbone.workers.agent_worker import run_prospect_workflow

log = structlog.get_logger(__name__)


def _redis_settings_from_url(url: str) -> RedisSettings:
    """Parse a redis://host:port/db URL into an ARQ RedisSettings object."""  # nosemgrep: trailofbits.generic.redis-unencrypted-transport.redis-unencrypted-transport
    parsed = urlparse(url)
    return RedisSettings(
        host=parsed.hostname or "localhost",
        port=parsed.port or 6379,
        database=int(parsed.path.lstrip("/") or 0),
        password=parsed.password,
    )


_REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")  # nosemgrep: trailofbits.generic.redis-unencrypted-transport.redis-unencrypted-transport


async def startup(ctx: dict) -> None:
    """Worker startup hook — log startup."""
    log.info("worker.startup")


async def shutdown(ctx: dict) -> None:
    """Worker shutdown hook — clean up resources."""
    log.info("worker.shutdown")


class WorkerSettings:
    """ARQ worker configuration.

    ``functions`` must list every job function the worker can execute.
    """

    redis_settings = _redis_settings_from_url(_REDIS_URL)
    on_startup = startup
    on_shutdown = shutdown
    max_jobs = 10
    job_timeout = 600  # 10 minutes max per job

    functions = [run_prospect_workflow]
