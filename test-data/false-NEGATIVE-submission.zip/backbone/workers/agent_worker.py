"""ARQ job handler for the agent orchestration worker.

Every agent run is executed here — off the HTTP request path — by an ARQ
worker process.  The job receives the run ID and tenant ID, opens a database
session with the correct RLS context, then delegates to the Orchestrator.
"""
import uuid

import structlog
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from backbone.agents.orchestrator import Orchestrator, OrchestratorError

# Import prospect tools so they register themselves in the tool registry.
import backbone.agents.prospect_tools  # noqa: F401

from backbone.core.config import settings
from backbone.core.database.rls import set_tenant_context

log = structlog.get_logger(__name__)

_engine = None
_SessionFactory = None


def _get_engine():
    global _engine, _SessionFactory
    if _engine is None:
        _engine = create_async_engine(settings.DATABASE_URL, echo=False, pool_pre_ping=True)
        _SessionFactory = async_sessionmaker(
            _engine, class_=AsyncSession, expire_on_commit=False, autoflush=False
        )
    return _engine, _SessionFactory


async def run_prospect_workflow(ctx: dict, run_id: str, tenant_id: str) -> dict:
    """ARQ job: execute an agent run for the given tenant.

    Args:
        ctx: ARQ job context (contains redis connection, etc.).
        run_id: String UUID of the AgentRun to execute.
        tenant_id: String UUID of the tenant that owns the run.

    Returns:
        A dict summarising the outcome (for ARQ result storage).
    """
    run_uuid = uuid.UUID(run_id)
    tenant_uuid = uuid.UUID(tenant_id)

    log.info("worker.job_start", run_id=run_id, tenant_id=tenant_id)

    _, SessionFactory = _get_engine()

    try:
        async with SessionFactory() as session:
            # is_local=False: connection-level setting so it survives the many
            # session.commit() calls the orchestrator makes during its loop.
            await set_tenant_context(session, tenant_uuid, is_local=False)
            orchestrator = Orchestrator()
            await orchestrator.run(run_uuid, session)
            log.info("worker.job_complete", run_id=run_id)
            return {"status": "completed", "run_id": run_id}
    except OrchestratorError as exc:
        log.error("worker.orchestrator_error", run_id=run_id, error=str(exc))
        return {"status": "failed", "run_id": run_id, "error": str(exc)}
    except Exception as exc:
        log.exception("worker.unexpected_error", run_id=run_id, error=str(exc))
        return {"status": "error", "run_id": run_id, "error": str(exc)}
