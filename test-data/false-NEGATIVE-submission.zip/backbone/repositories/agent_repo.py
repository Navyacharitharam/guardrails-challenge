"""Data access layer for AgentRun, AgentStep, and HumanReview entities."""
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.models.agent_run import AgentRun
from backbone.models.agent_step import AgentStep
from backbone.models.enums import AgentRunStatus, HumanReviewStatus
from backbone.models.human_review import HumanReview


async def create_agent_run(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    workflow_type: str,
    icp_id: Optional[uuid.UUID] = None,
    input_payload: dict[str, Any],
) -> AgentRun:
    """Create and persist a new AgentRun in QUEUED status."""
    run = AgentRun(
        tenant_id=tenant_id,
        workflow_type=workflow_type,
        icp_id=icp_id,
        input_payload=input_payload,
        status=AgentRunStatus.QUEUED,
    )
    session.add(run)
    await session.flush()
    await session.refresh(run)
    return run


async def get_agent_run(
    session: AsyncSession, run_id: uuid.UUID
) -> Optional[AgentRun]:
    """Return an AgentRun by primary key, or None."""
    result = await session.execute(select(AgentRun).where(AgentRun.id == run_id))
    return result.scalar_one_or_none()


async def list_agent_runs(
    session: AsyncSession,
    *,
    limit: int = 20,
    offset: int = 0,
    status: Optional[AgentRunStatus] = None,
) -> list[AgentRun]:
    """Return paginated agent runs, optionally filtered by status."""
    stmt = (
        select(AgentRun)
        .order_by(AgentRun.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if status:
        stmt = stmt.where(AgentRun.status == status)
    result = await session.execute(stmt)
    return list(result.scalars().all())


async def list_steps_for_run(
    session: AsyncSession, run_id: uuid.UUID
) -> list[AgentStep]:
    """Return all steps for a run ordered by step_number."""
    result = await session.execute(
        select(AgentStep)
        .where(AgentStep.run_id == run_id)
        .order_by(AgentStep.step_number)
    )
    return list(result.scalars().all())


async def list_pending_reviews(
    session: AsyncSession,
    *,
    limit: int = 20,
    offset: int = 0,
) -> list[HumanReview]:
    """Return all pending human reviews, oldest first."""
    result = await session.execute(
        select(HumanReview)
        .where(HumanReview.status == HumanReviewStatus.PENDING)
        .order_by(HumanReview.created_at.asc())
        .limit(limit)
        .offset(offset)
    )
    return list(result.scalars().all())


async def get_human_review(
    session: AsyncSession, review_id: uuid.UUID
) -> Optional[HumanReview]:
    """Return a HumanReview by primary key, or None."""
    result = await session.execute(
        select(HumanReview).where(HumanReview.id == review_id)
    )
    return result.scalar_one_or_none()


async def resolve_human_review(
    session: AsyncSession,
    review: HumanReview,
    *,
    status: HumanReviewStatus,
    reviewer_notes: Optional[str] = None,
    modified_output: Optional[dict[str, Any]] = None,
) -> HumanReview:
    """Apply a reviewer's decision to a HumanReview record."""
    review.status = status
    review.reviewer_notes = reviewer_notes
    review.modified_output = modified_output
    review.resolved_at = datetime.now(timezone.utc)
    await session.flush()
    return review
