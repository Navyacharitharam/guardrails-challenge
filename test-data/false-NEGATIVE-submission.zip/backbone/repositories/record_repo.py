"""Data access layer for Record and ObjectDefinition entities."""
import uuid
from typing import Any, Optional

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.models.object_definition import ObjectDefinition
from backbone.models.record import Record


async def get_object_definition_by_api_name(
    session: AsyncSession, api_name: str
) -> Optional[ObjectDefinition]:
    """Return the ObjectDefinition with the given api_name, or None."""
    result = await session.execute(
        select(ObjectDefinition).where(ObjectDefinition.api_name == api_name)
    )
    return result.scalar_one_or_none()


async def list_records(
    session: AsyncSession,
    *,
    object_definition_id: Optional[uuid.UUID] = None,
    limit: int = 50,
    offset: int = 0,
) -> list[Record]:
    """Return paginated records, optionally filtered by object definition."""
    stmt = select(Record).order_by(Record.created_at.desc()).limit(limit).offset(offset)
    if object_definition_id:
        stmt = stmt.where(Record.object_definition_id == object_definition_id)
    result = await session.execute(stmt)
    return list(result.scalars().all())


async def get_record(session: AsyncSession, record_id: uuid.UUID) -> Optional[Record]:
    """Return a Record by primary key, or None."""
    result = await session.execute(select(Record).where(Record.id == record_id))
    return result.scalar_one_or_none()


async def get_record_by_external_id(
    session: AsyncSession,
    *,
    object_definition_id: uuid.UUID,
    external_id: str,
) -> Optional[Record]:
    """Return a Record matching the object type + external_id pair, or None."""
    result = await session.execute(
        select(Record).where(
            Record.object_definition_id == object_definition_id,
            Record.external_id == external_id,
        )
    )
    return result.scalar_one_or_none()


async def create_record(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    object_definition_id: uuid.UUID,
    external_id: Optional[str] = None,
    attributes: dict[str, Any],
) -> Record:
    """Persist a new Record and return it."""
    record = Record(
        tenant_id=tenant_id,
        object_definition_id=object_definition_id,
        external_id=external_id,
        attributes=attributes,
    )
    session.add(record)
    await session.flush()
    await session.refresh(record)
    return record


async def update_record_attributes(
    session: AsyncSession,
    record_id: uuid.UUID,
    attributes: dict[str, Any],
) -> None:
    """Merge new attribute values into an existing Record."""
    await session.execute(
        update(Record)
        .where(Record.id == record_id)
        .values(attributes=Record.attributes.op("||")(attributes))
    )


async def upsert_record(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    object_definition_id: uuid.UUID,
    external_id: str,
    attributes: dict[str, Any],
) -> tuple[Record, bool]:
    """Create or update a Record identified by (object_definition_id, external_id).

    Returns:
        A (record, created) tuple where ``created`` is True for new records.
    """
    existing = await get_record_by_external_id(
        session,
        object_definition_id=object_definition_id,
        external_id=external_id,
    )
    if existing:
        existing.attributes = {**existing.attributes, **attributes}
        await session.flush()
        return existing, False

    record = await create_record(
        session,
        tenant_id=tenant_id,
        object_definition_id=object_definition_id,
        external_id=external_id,
        attributes=attributes,
    )
    return record, True
