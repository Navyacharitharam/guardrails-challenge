"""Data access layer for ICP entities."""
import uuid
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.models.icp import ICP


async def list_icps(session: AsyncSession) -> list[ICP]:
    """Return all ICPs for the current tenant."""
    result = await session.execute(select(ICP).order_by(ICP.created_at.desc()))
    return list(result.scalars().all())


async def get_icp(session: AsyncSession, icp_id: uuid.UUID) -> Optional[ICP]:
    """Return an ICP by primary key, or None."""
    result = await session.execute(select(ICP).where(ICP.id == icp_id))
    return result.scalar_one_or_none()


async def get_active_icp(session: AsyncSession) -> Optional[ICP]:
    """Return the first active ICP for the current tenant, or None."""
    result = await session.execute(
        select(ICP).where(ICP.is_active.is_(True)).limit(1)  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
    )
    return result.scalar_one_or_none()


async def create_icp(session: AsyncSession, *, tenant_id: uuid.UUID, **kwargs) -> ICP:
    """Create and persist a new ICP."""
    icp = ICP(tenant_id=tenant_id, **kwargs)
    session.add(icp)
    await session.flush()
    await session.refresh(icp)
    return icp
