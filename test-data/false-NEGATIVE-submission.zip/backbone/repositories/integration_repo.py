"""Data access layer for IntegrationConnection entities."""
import uuid
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.core.security.encryption import encrypt_credentials
from backbone.models.integration_connection import IntegrationConnection


async def list_integrations(session: AsyncSession) -> list[IntegrationConnection]:
    """Return all integration connections for the current tenant."""
    result = await session.execute(
        select(IntegrationConnection).order_by(IntegrationConnection.provider_slug)
    )
    return list(result.scalars().all())


async def get_integration(
    session: AsyncSession, connection_id: uuid.UUID
) -> Optional[IntegrationConnection]:
    """Return an IntegrationConnection by primary key, or None."""
    result = await session.execute(
        select(IntegrationConnection).where(IntegrationConnection.id == connection_id)
    )
    return result.scalar_one_or_none()


async def get_active_integrations_by_slug(
    session: AsyncSession, provider_slug: str
) -> list[IntegrationConnection]:
    """Return all active connections for a given provider slug."""
    result = await session.execute(
        select(IntegrationConnection).where(
            IntegrationConnection.provider_slug == provider_slug,
            IntegrationConnection.is_active.is_(True),  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
        )
    )
    return list(result.scalars().all())


async def create_integration(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    provider_slug: str,
    display_name: str,
    credentials: dict,
) -> IntegrationConnection:
    """Create a new integration connection with encrypted credentials."""
    conn = IntegrationConnection(
        tenant_id=tenant_id,
        provider_slug=provider_slug,
        display_name=display_name,
        credentials=encrypt_credentials(credentials),
    )
    session.add(conn)
    await session.flush()
    await session.refresh(conn)
    return conn


async def update_integration_credentials(
    session: AsyncSession,
    connection: IntegrationConnection,
    credentials: dict,
) -> None:
    """Re-encrypt and save new credentials for an existing connection."""
    connection.credentials = encrypt_credentials(credentials)
    await session.flush()
