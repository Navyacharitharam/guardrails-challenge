"""Data access layer for Signal entities."""
import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.models.enums import SignalType
from backbone.models.signal import Signal


async def list_signals_for_record(
    session: AsyncSession,
    record_id: uuid.UUID,
    *,
    signal_type: Optional[SignalType] = None,
    limit: int = 50,
) -> list[Signal]:
    """Return signals for a record, ordered by occurrence date descending."""
    stmt = (
        select(Signal)
        .where(Signal.record_id == record_id)
        .order_by(Signal.occurred_at.desc())
        .limit(limit)
    )
    if signal_type:
        stmt = stmt.where(Signal.signal_type == signal_type)
    result = await session.execute(stmt)
    return list(result.scalars().all())


async def create_signal(
    session: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    record_id: uuid.UUID,
    signal_type: SignalType,
    source: str,
    payload: dict,
    score: float,
    occurred_at: Optional[datetime] = None,
) -> Signal:
    """Persist a new Signal and return it."""
    signal = Signal(
        tenant_id=tenant_id,
        record_id=record_id,
        signal_type=signal_type,
        source=source,
        payload=payload,
        score=score,
        occurred_at=occurred_at or datetime.now(timezone.utc),
    )
    session.add(signal)
    await session.flush()
    return signal
