"""Pydantic schemas for tenant and authentication endpoints."""
import uuid
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class TenantCreate(BaseModel):
    """Request body for POST /tenants."""

    name: str = Field(..., min_length=2, max_length=128)
    slug: str = Field(..., min_length=2, max_length=64, pattern=r"^[a-z0-9-]+$")
    admin_email: EmailStr
    admin_password: str = Field(..., min_length=8)


class TenantRead(BaseModel):
    """Response shape for a Tenant record."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    name: str
    slug: str
    admin_email: str
    created_at: datetime


class LoginRequest(BaseModel):
    """Request body for POST /auth/login."""

    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Response for successful authentication."""

    access_token: str
    token_type: str = "bearer"
    tenant_id: uuid.UUID
