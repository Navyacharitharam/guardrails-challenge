"""Pydantic schemas for AgentRun, AgentStep, and HumanReview endpoints."""
import uuid
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field

from backbone.models.enums import (
    AgentRunStatus,
    AgentStepStatus,
    AgentStepType,
    HumanReviewStatus,
    HumanReviewType,
)


class AgentRunCreate(BaseModel):
    """Request body for POST /api/runs."""

    workflow_type: str = Field(..., min_length=1, max_length=63)
    icp_id: Optional[uuid.UUID] = None
    input_payload: dict[str, Any] = Field(default_factory=dict)


class AgentRunRead(BaseModel):
    """Response shape for an AgentRun (without steps — use the /steps endpoint)."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    tenant_id: uuid.UUID
    workflow_type: str
    status: AgentRunStatus
    icp_id: Optional[uuid.UUID]
    input_payload: dict[str, Any]
    output_payload: Optional[dict[str, Any]]
    error_message: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime


class AgentStepRead(BaseModel):
    """Response shape for a single AgentStep (trace atom)."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    run_id: uuid.UUID
    step_number: int
    step_type: AgentStepType
    tool_name: Optional[str]
    reasoning: Optional[str]
    input_payload: dict[str, Any]
    output_payload: Optional[dict[str, Any]]
    status: AgentStepStatus
    error_message: Optional[str]
    duration_ms: Optional[int]
    started_at: datetime
    completed_at: Optional[datetime]


class HumanReviewRead(BaseModel):
    """Response shape for a HumanReview record."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    tenant_id: uuid.UUID
    run_id: uuid.UUID
    step_id: uuid.UUID
    review_type: HumanReviewType
    proposed_output: dict[str, Any]
    context: dict[str, Any]
    status: HumanReviewStatus
    reviewer_notes: Optional[str]
    modified_output: Optional[dict[str, Any]]
    created_at: datetime
    resolved_at: Optional[datetime]


class HumanReviewResolve(BaseModel):
    """Request body for PATCH /api/reviews/{id}."""

    status: HumanReviewStatus = Field(..., description="approved, rejected, or modified")
    reviewer_notes: Optional[str] = None
    modified_output: Optional[dict[str, Any]] = None
