"""Pydantic schemas for IntegrationConnection endpoints."""
import uuid
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class IntegrationConnectionCreate(BaseModel):
    """Request body to connect a new integration provider."""

    provider_slug: str = Field(..., max_length=63)
    display_name: str = Field(..., max_length=255)
    credentials: dict[str, Any] = Field(
        ..., description="Plain-text credentials (encrypted at rest by the API)."
    )


class IntegrationConnectionUpdate(BaseModel):
    """Request body to update an existing integration."""

    display_name: Optional[str] = Field(None, max_length=255)
    credentials: Optional[dict[str, Any]] = None
    is_active: Optional[bool] = None


class IntegrationConnectionRead(BaseModel):
    """Response shape — credentials are NEVER returned."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    tenant_id: uuid.UUID
    provider_slug: str
    display_name: str
    is_active: bool
    rate_limit_state: dict[str, Any]
    last_used_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime


class IntegrationTestResult(BaseModel):
    """Result of a connectivity test for an integration."""

    provider_slug: str
    success: bool
    message: str
    data: Optional[dict[str, Any]] = None
