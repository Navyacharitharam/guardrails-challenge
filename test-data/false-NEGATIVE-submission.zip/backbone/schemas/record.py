"""Pydantic schemas for Record and ObjectDefinition endpoints."""
import uuid
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field

from backbone.models.enums import EnrichmentStatus


class RecordCreate(BaseModel):
    """Request body to create a new Record."""

    object_definition_id: uuid.UUID
    external_id: Optional[str] = None
    attributes: dict[str, Any] = Field(default_factory=dict)


class RecordUpdate(BaseModel):
    """Request body to partially update a Record."""

    attributes: Optional[dict[str, Any]] = None
    external_id: Optional[str] = None


class RecordRead(BaseModel):
    """Response shape for a Record."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    tenant_id: uuid.UUID
    object_definition_id: uuid.UUID
    external_id: Optional[str]
    attributes: dict[str, Any]
    fit_score: Optional[float]
    intent_score: Optional[float]
    enrichment_status: EnrichmentStatus
    created_at: datetime
    updated_at: datetime


class ObjectDefinitionRead(BaseModel):
    """Response shape for an ObjectDefinition."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    tenant_id: uuid.UUID
    name: str
    slug: str
    schema_definition: dict[str, Any]
    created_at: datetime
