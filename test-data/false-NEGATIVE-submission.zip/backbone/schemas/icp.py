"""Pydantic schemas for ICP (Ideal Customer Profile) endpoints."""
import uuid
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class ICPCreate(BaseModel):
    """Request body to create a new ICP."""

    name: str = Field(..., min_length=2, max_length=255)
    description: str = ""
    firmographic_criteria: dict[str, Any] = Field(default_factory=dict)
    technographic_criteria: dict[str, Any] = Field(default_factory=dict)
    persona_criteria: dict[str, Any] = Field(default_factory=dict)
    signal_weights: dict[str, float] = Field(default_factory=dict)
    is_active: bool = True


class ICPUpdate(BaseModel):
    """Request body to partially update an ICP."""

    name: Optional[str] = Field(None, min_length=2, max_length=255)
    description: Optional[str] = None
    firmographic_criteria: Optional[dict[str, Any]] = None
    technographic_criteria: Optional[dict[str, Any]] = None
    persona_criteria: Optional[dict[str, Any]] = None
    signal_weights: Optional[dict[str, float]] = None
    is_active: Optional[bool] = None


class ICPRead(BaseModel):
    """Response shape for an ICP."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    tenant_id: uuid.UUID
    name: str
    description: str
    firmographic_criteria: dict[str, Any]
    technographic_criteria: dict[str, Any]
    persona_criteria: dict[str, Any]
    signal_weights: dict[str, Any]
    is_active: bool
    created_at: datetime
    updated_at: datetime
