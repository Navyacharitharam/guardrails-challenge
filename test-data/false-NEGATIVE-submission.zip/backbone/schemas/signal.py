"""Pydantic schemas for Signal endpoints."""
import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from backbone.models.enums import SignalType


class SignalCreate(BaseModel):
    """Request body to create a Signal."""

    record_id: uuid.UUID
    signal_type: SignalType
    source: str = Field(..., max_length=63)
    payload: dict[str, Any] = Field(default_factory=dict)
    score: float = Field(default=0.5, ge=0.0, le=1.0)
    occurred_at: datetime


class SignalRead(BaseModel):
    """Response shape for a Signal."""

    model_config = {"from_attributes": True}

    id: uuid.UUID
    tenant_id: uuid.UUID
    record_id: uuid.UUID
    signal_type: SignalType
    source: str
    payload: dict[str, Any]
    score: float
    occurred_at: datetime
    created_at: datetime
