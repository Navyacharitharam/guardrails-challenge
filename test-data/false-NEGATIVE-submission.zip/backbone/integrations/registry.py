"""Provider registry — thin re-export of the waterfall's internal registry.

The canonical registration point is ``backbone.integrations.waterfall``
(providers self-register via ``@register_provider`` at import time).  This
module exposes the registry operations as a clean public API so callers
don't need to reach into the waterfall's internals.

Usage::

    from backbone.integrations.registry import register_provider, registered_slugs

    @register_provider
    class MyProvider(BaseIntegration):
        slug = "my_provider"
        ...
"""
from backbone.integrations.base import BaseIntegration
from backbone.integrations.waterfall import (
    _REGISTRY as _PROVIDER_REGISTRY,
    register_provider,
    registered_slugs,
)

__all__ = [
    "register_provider",
    "registered_slugs",
    "get_provider_class",
]


def get_provider_class(slug: str) -> type[BaseIntegration] | None:
    """Return the registered provider class for ``slug``, or ``None``.

    Args:
        slug: The stable provider slug (e.g. ``"hunter"``).

    Returns:
        The ``BaseIntegration`` subclass, or ``None`` if not registered.
    """
    return _PROVIDER_REGISTRY.get(slug)
