"""Hunter.io integration provider.

Implements two endpoints from the Hunter.io v2 API:

  * ``/v2/email-finder``   — find one professional email for a named person
  * ``/v2/domain-search``  — list all discoverable emails at a domain

Rate-limit contract
-------------------
Hunter.io uses a monthly credit system rather than per-minute throttling.
The free tier ships with 25 credits/month; paid plans scale higher.  The
API returns HTTP 429 when the quota is exhausted.

This provider tracks state in ``IntegrationConnection.rate_limit_state``:

  ``{"calls_remaining": 23, "reset_at": "2025-04-01T00:00:00+00:00"}``

On every successful response ``calls_remaining`` is decremented.  On a 429
it is set to 0 and ``reset_at`` is set to the first second of the next
calendar month (UTC).  The waterfall resolver will skip this provider while
``calls_remaining <= 0`` and ``reset_at`` is still in the future.

Credentials format (stored encrypted in IntegrationConnection.credentials):

  ``{"api_key": "<hunter-api-key>"}``
"""
import calendar
from datetime import datetime, timezone
from typing import Any

import httpx
import structlog

from backbone.integrations.base import BaseIntegration, ToolError, ToolResult
from backbone.integrations.waterfall import register_provider
from sqlalchemy.ext.asyncio import AsyncSession

log = structlog.get_logger(__name__)

_BASE_URL = "https://api.hunter.io"
_TIMEOUT_SECONDS = 15.0

# Default assumed remaining calls when the state has not been initialised yet.
# Avoids blocking brand-new connections before the first real API call confirms
# the actual balance.
_DEFAULT_CALLS_REMAINING = 25


def _next_month_reset(now: datetime) -> datetime:
    """Return midnight UTC on the first day of the month after ``now``."""
    year = now.year + (1 if now.month == 12 else 0)
    month = 1 if now.month == 12 else now.month + 1
    return datetime(year, month, 1, tzinfo=timezone.utc)


def _calls_remaining(state: dict[str, Any]) -> int:
    """Extract calls_remaining from rate_limit_state, defaulting gracefully."""
    val = state.get("calls_remaining")
    if val is None:
        return _DEFAULT_CALLS_REMAINING
    try:
        return int(val)
    except (TypeError, ValueError):
        return _DEFAULT_CALLS_REMAINING


@register_provider
class HunterIntegration(BaseIntegration):
    """Hunter.io data-enrichment provider.

    Registered as slug ``"hunter"``.  Create an ``IntegrationConnection`` with
    ``provider_slug="hunter"`` and credentials encrypted via
    ``backbone.core.security.encryption.encrypt_credentials({"api_key": "…"})``.
    """

    slug = "hunter"
    display_name = "Hunter.io"

    # ------------------------------------------------------------------
    # Internal HTTP helpers
    # ------------------------------------------------------------------

    def _api_key(self) -> str:
        creds = self._credentials()
        key = creds.get("api_key", "")
        if not key:
            raise ToolError(
                "Hunter.io credentials missing 'api_key'.", retriable=False
            )
        return key

    async def _get(
        self,
        path: str,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Issue a GET request to the Hunter.io API and return parsed JSON.

        Handles HTTP-level errors and translates them to ``ToolError``.
        """
        params["api_key"] = self._api_key()
        url = f"{_BASE_URL}{path}"

        async with httpx.AsyncClient(timeout=_TIMEOUT_SECONDS) as client:
            try:
                response = await client.get(url, params=params)
            except httpx.TimeoutException as exc:
                raise ToolError(
                    f"Hunter.io request timed out after {_TIMEOUT_SECONDS}s: {exc}",
                    retriable=True,
                )
            except httpx.RequestError as exc:
                raise ToolError(
                    f"Hunter.io network error: {exc}",
                    retriable=True,
                )

        if response.status_code == 429:
            log.warning("hunter.rate_limit_hit", path=path)
            raise _RateLimitError()

        if response.status_code == 400:
            # Bad request — malformed params, not a transient error.
            body = _safe_json(response)
            detail = _first_error_detail(body)
            raise ToolError(
                f"Hunter.io bad request ({path}): {detail}",
                retriable=False,
            )

        if response.status_code == 401:
            raise ToolError(
                "Hunter.io authentication failed — check the stored api_key.",
                retriable=False,
            )

        if response.status_code == 404:
            # "Not found" in Hunter's context means "no result" — not a system error.
            raise ToolError(
                f"Hunter.io returned 404 for {path}: no result found.",
                retriable=False,
            )

        if not response.is_success:  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
            raise ToolError(
                f"Hunter.io {path} returned HTTP {response.status_code}.",
                retriable=True,
            )

        body = _safe_json(response)

        # Hunter wraps errors in a successful HTTP response in some edge cases.
        if "errors" in body:
            detail = _first_error_detail(body)
            code = (body["errors"][0].get("code") if body["errors"] else None)
            if code == 429:
                raise _RateLimitError()
            raise ToolError(
                f"Hunter.io API error ({path}): {detail}",
                retriable=code not in (400, 401, 404),
            )

        return body

    # ------------------------------------------------------------------
    # Rate-limit state management
    # ------------------------------------------------------------------

    async def _decrement_and_persist(self, session: AsyncSession) -> None:
        """Decrement calls_remaining by 1 and flush to the DB."""
        state = self.connection.rate_limit_state or {}
        remaining = _calls_remaining(state) - 1
        await self._persist_rate_limit_state(
            session,
            calls_remaining=max(remaining, 0),
        )

    async def _handle_rate_limit(self, session: AsyncSession) -> None:
        """Set calls_remaining=0 and schedule reset for next month."""
        reset_dt = _next_month_reset(datetime.now(timezone.utc))
        await self._persist_rate_limit_state(
            session,
            calls_remaining=0,
            reset_at=reset_dt,
        )

    # ------------------------------------------------------------------
    # Public operations
    # ------------------------------------------------------------------

    async def find_email(
        self,
        session: AsyncSession,
        *,
        first_name: str,
        last_name: str,
        domain: str,
    ) -> ToolResult:
        """Call ``/v2/email-finder`` and return the best email match.

        Args:
            session: Active async session with RLS tenant context set.
            first_name: Target contact's given name.
            last_name: Target contact's family name.
            domain: Employer's apex domain (e.g. ``"stripe.com"``).

        Returns:
            ``ToolResult`` with::

                data = {
                    "email": "sarah@stripe.com",
                    "score": 94,
                    "first_name": "Sarah",
                    "last_name": "Chen",
                    "position": "VP of Sales",
                    "domain": "stripe.com",
                    "linkedin_url": "https://linkedin.com/in/...",
                    "sources": [...],
                }
                meta = {"params": {...}}

        Raises:
            ToolError(retriable=False): 4xx non-rate-limit response or missing
                api_key.
            ToolError(retriable=True): network/timeout/5xx or rate limit
                after persisting ``calls_remaining=0``.
        """
        try:
            body = await self._get(
                "/v2/email-finder",
                params={
                    "domain": domain,
                    "first_name": first_name,
                    "last_name": last_name,
                },
            )
        except _RateLimitError:
            await self._handle_rate_limit(session)
            raise ToolError(
                "Hunter.io monthly credit limit reached. "
                "Credits reset on the first of next month.",
                retriable=True,
            )

        await self._decrement_and_persist(session)

        data_block: dict[str, Any] = body.get("data") or {}

        email = data_block.get("email")
        if not email:
            raise ToolError(
                f"Hunter.io could not find an email for {first_name} {last_name} "
                f"at {domain}.",
                retriable=False,
            )

        return ToolResult(
            provider_slug=self.slug,
            data={
                "email": email,
                "score": data_block.get("score"),
                "first_name": data_block.get("first_name"),
                "last_name": data_block.get("last_name"),
                "position": data_block.get("position"),
                "domain": data_block.get("domain"),
                "linkedin_url": data_block.get("linkedin_url"),
                "twitter": data_block.get("twitter"),
                "phone_number": data_block.get("phone_number"),
                "sources": data_block.get("sources", []),
            },
            meta=body.get("meta") or {},
        )

    async def search_domain(
        self,
        session: AsyncSession,
        *,
        domain: str,
        limit: int = 10,
    ) -> ToolResult:
        """Call ``/v2/domain-search`` and return discovered email contacts.

        Args:
            session: Active async session with RLS tenant context set.
            domain: Apex domain to search (e.g. ``"stripe.com"``).
            limit: Maximum emails to return (Hunter.io caps at 100 per request).

        Returns:
            ``ToolResult`` with::

                data = {
                    "domain": "stripe.com",
                    "organization": "Stripe",
                    "pattern": "{first}@{domain}",
                    "emails": [
                        {
                            "email": "...",
                            "first_name": "...",
                            "last_name": "...",
                            "position": "...",
                            "seniority": "executive",
                            "department": "sales",
                            "confidence": 92,
                            "linkedin": "...",
                            "sources": [...],
                        },
                        ...
                    ],
                }
                meta = {"results": 10, "limit": 10, "offset": 0, ...}

        Raises:
            ToolError: same semantics as ``find_email``.
        """
        capped_limit = min(limit, 100)  # Hunter.io hard cap per request

        try:
            body = await self._get(
                "/v2/domain-search",
                params={"domain": domain, "limit": capped_limit},
            )
        except _RateLimitError:
            await self._handle_rate_limit(session)
            raise ToolError(
                "Hunter.io monthly credit limit reached. "
                "Credits reset on the first of next month.",
                retriable=True,
            )

        await self._decrement_and_persist(session)

        data_block: dict[str, Any] = body.get("data") or {}
        raw_emails: list[dict[str, Any]] = data_block.get("emails") or []

        emails = [
            {
                "email": e.get("value"),
                "first_name": e.get("first_name"),
                "last_name": e.get("last_name"),
                "position": e.get("position"),
                "seniority": e.get("seniority"),
                "department": e.get("department"),
                "confidence": e.get("confidence"),
                "linkedin": e.get("linkedin"),
                "twitter": e.get("twitter"),
                "phone_number": e.get("phone_number"),
                "sources": e.get("sources", []),
            }
            for e in raw_emails
        ]

        return ToolResult(
            provider_slug=self.slug,
            data={
                "domain": data_block.get("domain"),
                "organization": data_block.get("organization"),
                "pattern": data_block.get("pattern"),
                "disposable": data_block.get("disposable"),
                "webmail": data_block.get("webmail"),
                "emails": emails,
            },
            meta=body.get("meta") or {},
        )


# ---------------------------------------------------------------------------
# Internal sentinel — keeps rate-limit handling DRY
# ---------------------------------------------------------------------------


class _RateLimitError(Exception):
    """Internal signal raised when Hunter.io returns a 429 response.

    Never propagated outside this module; converted to ToolError by the
    callers after rate-limit state is persisted.
    """


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _safe_json(response: httpx.Response) -> dict[str, Any]:
    """Parse JSON from response; return empty dict on parse failure."""
    try:
        return response.json()
    except Exception:
        return {}


def _first_error_detail(body: dict[str, Any]) -> str:
    """Extract the first error detail string from a Hunter.io error response."""
    errors = body.get("errors") or []
    if errors and isinstance(errors, list):
        first = errors[0]
        return first.get("details") or first.get("id") or str(first)
    return str(body)
