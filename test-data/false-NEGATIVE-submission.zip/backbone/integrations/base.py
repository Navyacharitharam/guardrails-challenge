"""Abstract base class and shared types for all integration providers.

Every provider must subclass ``BaseIntegration``, set the ``slug`` and
``display_name`` class variables, and implement the abstract methods it
supports.  Unsupported methods may be left raising ``NotImplementedError``
— the waterfall resolver will skip them automatically.

Contract (mirrors CLAUDE.md agent-tool rules):
  • Methods accept plain typed parameters (callers build Pydantic inputs).
  • Successful calls return ``ToolResult``.
  • Failures raise ``ToolError``; set ``retriable=False`` for terminal errors
    (bad input, missing resource) so the waterfall does not waste API credits
    trying other providers for the same unresolvable request.
"""
import abc
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.core.security.encryption import decrypt_credentials
from backbone.models.integration_connection import IntegrationConnection


# ---------------------------------------------------------------------------
# Result / error types
# ---------------------------------------------------------------------------


@dataclass
class ToolResult:
    """Successful result returned by any integration method.

    Attributes:
        data: The primary payload (e.g. ``{"email": "...", "score": 92}``).
        provider_slug: Which provider produced this result.
        meta: Supplementary metadata (pagination, confidence, sources, etc.).
    """

    data: dict[str, Any]
    provider_slug: str
    meta: dict[str, Any] = field(default_factory=dict)


class ToolError(Exception):
    """Raised when an integration call fails.

    Args:
        message: Human-readable description.
        retriable: ``True`` (default) means the waterfall should try the next
            provider.  ``False`` means the error is terminal — do not retry.
    """

    def __init__(self, message: str, *, retriable: bool = True) -> None:
        super().__init__(message)
        self.retriable = retriable


# ---------------------------------------------------------------------------
# BaseIntegration
# ---------------------------------------------------------------------------


class BaseIntegration(abc.ABC):
    """Abstract base for all external data-enrichment providers.

    Subclasses must:
      1. Set ``slug`` to the stable identifier stored in
         ``IntegrationConnection.provider_slug`` (e.g. ``"hunter"``).
      2. Set ``display_name`` to a human-readable label (e.g. ``"Hunter.io"``).
      3. Implement the abstract methods they support.

    Instances are constructed by the waterfall resolver — callers never
    instantiate providers directly.
    """

    slug: str
    display_name: str

    def __init__(self, connection: IntegrationConnection) -> None:
        self.connection = connection

    # ------------------------------------------------------------------
    # Credential helpers
    # ------------------------------------------------------------------

    def _credentials(self) -> dict[str, Any]:
        """Decrypt and return the stored credentials dict."""
        return decrypt_credentials(self.connection.credentials)

    # ------------------------------------------------------------------
    # Rate-limit helpers
    # ------------------------------------------------------------------

    def is_rate_limited(self) -> bool:
        """Return ``True`` if this connection is currently exhausted.

        A connection is exhausted when ``calls_remaining <= 0`` AND the
        ``reset_at`` timestamp is still in the future.  If ``reset_at`` has
        passed, the counter is considered stale and the provider is allowed
        to try again (the real API will confirm if limits are still in effect).
        """
        state = self.connection.rate_limit_state or {}
        remaining = state.get("calls_remaining")
        if remaining is not None and int(remaining) <= 0:
            reset_str = state.get("reset_at")
            if reset_str:
                try:
                    reset_dt = datetime.fromisoformat(reset_str.replace("Z", "+00:00"))
                    if datetime.now(timezone.utc) < reset_dt:
                        return True
                except ValueError:
                    pass
        return False

    async def _persist_rate_limit_state(
        self,
        session: AsyncSession,
        *,
        calls_remaining: int,
        reset_at: datetime | None = None,
    ) -> None:
        """Write updated rate-limit fields back to ``integration_connections``.

        Merges into the existing ``rate_limit_state`` JSONB so that unrelated
        keys (e.g. ``last_error``) are preserved.  Also stamps ``last_used_at``.
        """
        state: dict[str, Any] = dict(self.connection.rate_limit_state or {})
        state["calls_remaining"] = calls_remaining
        if reset_at is not None:
            state["reset_at"] = reset_at.isoformat()

        await session.execute(
            update(IntegrationConnection)
            .where(IntegrationConnection.id == self.connection.id)
            .values(
                rate_limit_state=state,
                last_used_at=datetime.now(timezone.utc),
            )
        )
        # Keep in-memory state consistent for the lifetime of this object.
        self.connection.rate_limit_state = state

    # ------------------------------------------------------------------
    # Abstract operations — implement the ones your provider supports.
    # Return ToolResult on success; raise ToolError on failure.
    # ------------------------------------------------------------------

    @abc.abstractmethod
    async def find_email(
        self,
        session: AsyncSession,
        *,
        first_name: str,
        last_name: str,
        domain: str,
    ) -> ToolResult:
        """Locate the professional email for a named person at a domain.

        Args:
            session: Active async database session (tenant context already set).
            first_name: Given name of the target contact.
            last_name: Family name of the target contact.
            domain: Apex domain of their employer (e.g. ``"stripe.com"``).

        Returns:
            ``ToolResult`` with ``data["email"]``, ``data["score"]``, etc.

        Raises:
            ToolError(retriable=False): when the domain or name is
                fundamentally not findable (4xx non-rate-limit response).
            ToolError(retriable=True): transient failure — try next provider.
        """

    @abc.abstractmethod
    async def search_domain(
        self,
        session: AsyncSession,
        *,
        domain: str,
        limit: int = 10,
    ) -> ToolResult:
        """Return a list of email contacts discovered at a domain.

        Args:
            session: Active async database session.
            domain: Apex domain to search (e.g. ``"stripe.com"``).
            limit: Maximum number of contacts to return (provider-dependent cap).

        Returns:
            ``ToolResult`` with ``data["emails"]`` list and ``meta["total"]``.

        Raises:
            ToolError: as described in ``find_email``.
        """
