"""Waterfall resolver — executes an integration operation across providers.

Usage
-----
Register providers at module load time with the ``@register_provider``
decorator (done in each provider's module).  Import the provider modules
before calling ``resolve`` so the decorator runs::

    from backbone.integrations.providers import hunter  # noqa: F401
    from backbone.integrations.waterfall import resolve

    result = await resolve(
        "find_email",
        session=session,
        first_name="Sarah",
        last_name="Chen",
        domain="datastax.com",
    )

Resolver behaviour
------------------
1. Loads all active ``IntegrationConnection`` rows for the current tenant
   (RLS enforces tenant scoping — no explicit tenant_id filter in the query).
2. Skips connections whose provider slug is not in the registry.
3. Skips connections that are currently rate-limited.
4. Calls ``provider.<operation>(session=session, **kwargs)`` in order.
5. Returns the first ``ToolResult``.
6. If a provider raises ``ToolError(retriable=False)``, propagates immediately.
7. After exhausting all providers, re-raises the last retriable error.
"""
import uuid
from typing import Any

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.integrations.base import BaseIntegration, ToolError, ToolResult
from backbone.models.integration_connection import IntegrationConnection

log = structlog.get_logger(__name__)


class NoProvidersConfiguredError(ToolError):
    """Raised when no active IntegrationConnection rows exist for this tenant.

    Distinct from a provider-level failure so callers can gracefully degrade
    (e.g. skip enrichment) rather than aborting the entire workflow run.
    """

    def __init__(self, operation: str) -> None:
        super().__init__(
            f"No active integration connections found for operation '{operation}'.",
            retriable=False,
        )

# slug → provider class.  Populated at import time by @register_provider.
_REGISTRY: dict[str, type[BaseIntegration]] = {}


def register_provider(cls: type[BaseIntegration]) -> type[BaseIntegration]:
    """Class decorator that registers a provider in the global waterfall registry.

    Usage::

        @register_provider
        class HunterIntegration(BaseIntegration):
            slug = "hunter"
            ...
    """
    if not hasattr(cls, "slug") or not cls.slug:
        raise TypeError(f"{cls.__name__} must define a non-empty 'slug' class variable")
    _REGISTRY[cls.slug] = cls
    return cls


def registered_slugs() -> list[str]:
    """Return the slugs of all currently registered providers (useful for tests)."""
    return list(_REGISTRY.keys())


async def _load_active_connections(session: AsyncSession) -> list[IntegrationConnection]:
    """Fetch active IntegrationConnections for the current RLS tenant.

    RLS automatically scopes this to the tenant set via ``set_current_tenant``.
    Connections are ordered by ``created_at`` so the first-created (typically
    the primary) provider is tried first.
    """
    result = await session.execute(
        select(IntegrationConnection)
        .where(IntegrationConnection.is_active.is_(True))  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
        .order_by(IntegrationConnection.created_at)
    )
    return list(result.scalars())


async def resolve(
    operation: str,
    session: AsyncSession,
    **kwargs: Any,
) -> ToolResult:
    """Execute ``operation`` using the first available active provider.

    Args:
        operation: Method name on ``BaseIntegration`` (e.g. ``"find_email"``).
        session: Async session with the tenant context already set via RLS.
        **kwargs: Keyword arguments forwarded to the provider method.

    Returns:
        The ``ToolResult`` from the first provider that succeeds.

    Raises:
        ToolError(retriable=False): Immediately when a provider signals a
            terminal error (bad domain, invalid input, etc.) or when no
            provider is available at all.
        ToolError(retriable=True): After all available providers have been
            tried and all raised retriable errors.
    """
    connections = await _load_active_connections(session)

    if not connections:
        raise NoProvidersConfiguredError(operation)

    last_error: ToolError | None = None
    tried = 0

    for conn in connections:
        provider_cls = _REGISTRY.get(conn.provider_slug)
        if provider_cls is None:
            log.debug(
                "waterfall.unknown_slug",
                slug=conn.provider_slug,
                connection_id=str(conn.id),
            )
            continue

        provider = provider_cls(conn)

        if provider.is_rate_limited():
            log.info(
                "waterfall.skip_rate_limited",
                slug=conn.provider_slug,
                connection_id=str(conn.id),
                operation=operation,
            )
            continue

        method = getattr(provider, operation, None)
        if method is None or not callable(method):
            log.debug(
                "waterfall.unsupported_operation",
                slug=conn.provider_slug,
                operation=operation,
            )
            continue

        tried += 1
        try:
            result: ToolResult = await method(session=session, **kwargs)
            log.info(
                "waterfall.success",
                slug=conn.provider_slug,
                operation=operation,
            )
            return result
        except ToolError as exc:
            log.warning(
                "waterfall.provider_error",
                slug=conn.provider_slug,
                operation=operation,
                error=str(exc),
                retriable=exc.retriable,
            )
            if not exc.retriable:
                raise
            last_error = exc
            # Continue to next provider.

    if tried == 0:
        raise ToolError(
            f"No registered provider supports operation '{operation}'. "
            f"Known slugs: {registered_slugs()}",
            retriable=False,
        )

    # All tried providers raised retriable errors.
    raise last_error or ToolError(
        f"All providers failed for operation '{operation}'.",
        retriable=False,
    )
