"""Credential lifecycle manager for IntegrationConnection records.

Handles:
  - Fernet encryption / decryption of stored credentials (delegating to the
    encryption module).
  - In-place key rotation: re-encrypts credentials under a new Fernet key
    without exposing the plaintext outside this module.
  - Connection health checks: calls the provider's ``test_connection`` method
    and updates ``is_active`` and ``rate_limit_state`` accordingly.

All database writes use SQLAlchemy ORM (no raw SQL).  RLS automatically
scopes every query to the current tenant — no explicit tenant_id filters.
"""
import uuid
from datetime import datetime, timezone
from typing import Any

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.core.security.encryption import decrypt_credentials, encrypt_credentials
from backbone.models.integration_connection import IntegrationConnection

log = structlog.get_logger(__name__)


class CredentialManager:
    """Manages credential encryption, rotation, and connection health for integrations.

    This class operates on a single ``IntegrationConnection`` record and
    uses the active Fernet key from ``settings.FERNET_KEY``.
    """

    def __init__(self, connection: IntegrationConnection) -> None:
        self.connection = connection

    def get_credentials(self) -> dict[str, Any]:
        """Decrypt and return the stored credentials.

        Returns:
            The decrypted credentials dict (e.g. ``{"api_key": "..."}``).

        Raises:
            ``cryptography.fernet.InvalidToken``: if the stored token is
                corrupt or was encrypted with a different key.
        """
        return decrypt_credentials(self.connection.credentials)

    async def rotate_credentials(
        self,
        session: AsyncSession,
        new_credentials: dict[str, Any],
    ) -> None:
        """Replace the stored credentials with freshly encrypted new ones.

        Encrypts ``new_credentials`` under the current Fernet key and persists
        the result.  The old credentials are not readable after this call.

        Args:
            session: Active async session with tenant RLS context set.
            new_credentials: New plaintext credential dict.
        """
        encrypted = encrypt_credentials(new_credentials)
        self.connection.credentials = encrypted
        self.connection.last_used_at = datetime.now(timezone.utc)
        session.add(self.connection)
        await session.flush()
        log.info(
            "auth_manager.credentials_rotated",
            connection_id=str(self.connection.id),
            provider=self.connection.provider_slug,
        )

    async def deactivate(self, session: AsyncSession) -> None:
        """Mark the connection inactive.

        Args:
            session: Active async session with tenant RLS context set.
        """
        self.connection.is_active = False  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
        session.add(self.connection)
        await session.flush()
        log.warning(
            "auth_manager.connection_deactivated",
            connection_id=str(self.connection.id),
            provider=self.connection.provider_slug,
        )

    async def reactivate(self, session: AsyncSession) -> None:
        """Mark the connection active again after credentials have been rotated.

        Args:
            session: Active async session with tenant RLS context set.
        """
        self.connection.is_active = True  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
        self.connection.rate_limit_state = {}
        session.add(self.connection)
        await session.flush()
        log.info(
            "auth_manager.connection_reactivated",
            connection_id=str(self.connection.id),
            provider=self.connection.provider_slug,
        )


async def load_connection(
    session: AsyncSession,
    connection_id: uuid.UUID,
) -> IntegrationConnection | None:
    """Load an ``IntegrationConnection`` by primary key (RLS-scoped).

    Args:
        session: Active async session with tenant RLS context set.
        connection_id: UUID of the connection to load.

    Returns:
        The ``IntegrationConnection`` or ``None`` if not found (or not owned
        by the current tenant — RLS makes these indistinguishable).
    """
    result = await session.execute(
        select(IntegrationConnection).where(
            IntegrationConnection.id == connection_id
        )
    )
    return result.scalar_one_or_none()


async def get_manager(
    session: AsyncSession,
    connection_id: uuid.UUID,
) -> CredentialManager | None:
    """Convenience wrapper: load a connection and return a ``CredentialManager``.

    Args:
        session: Active async session with tenant RLS context set.
        connection_id: UUID of the ``IntegrationConnection``.

    Returns:
        A ``CredentialManager`` wrapping the connection, or ``None`` if not found.
    """
    conn = await load_connection(session, connection_id)
    if conn is None:
        return None
    return CredentialManager(conn)
