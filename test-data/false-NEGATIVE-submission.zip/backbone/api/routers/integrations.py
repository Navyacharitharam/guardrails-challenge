"""Integration connection management endpoints."""
import uuid
from typing import Annotated

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_id, get_tenant_session
from backbone.repositories.integration_repo import (
    create_integration,
    get_integration,
    list_integrations,
    update_integration_credentials,
)
from backbone.schemas.integration import (
    IntegrationConnectionCreate,
    IntegrationConnectionRead,
    IntegrationConnectionUpdate,
    IntegrationTestResult,
)

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/integrations", tags=["integrations"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]
_TenantId = Annotated[uuid.UUID, Depends(get_tenant_id)]


@router.get("", response_model=list[IntegrationConnectionRead])
async def list_all(session: _Session) -> list[IntegrationConnectionRead]:
    """Return all integration connections for the authenticated tenant."""
    return await list_integrations(session)


@router.post("", response_model=IntegrationConnectionRead, status_code=status.HTTP_201_CREATED)
async def create(
    body: IntegrationConnectionCreate,
    session: _Session,
    tenant_id: _TenantId,
) -> IntegrationConnectionRead:
    """Connect a new integration provider (credentials are encrypted at rest)."""
    try:
        conn = await create_integration(
            session,
            tenant_id=tenant_id,
            provider_slug=body.provider_slug,
            display_name=body.display_name,
            credentials=body.credentials,
        )
        await session.commit()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"A '{body.provider_slug}' integration is already connected. "
                "Use the existing connection or update its credentials instead."
            ),
        )
    log.info("integration.created", provider=body.provider_slug, tenant_id=str(tenant_id))
    return conn


@router.get("/{connection_id}", response_model=IntegrationConnectionRead)
async def get_one(connection_id: uuid.UUID, session: _Session) -> IntegrationConnectionRead:
    """Return a single integration connection by ID."""
    conn = await get_integration(session, connection_id)
    if conn is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integration not found.")
    return conn


@router.patch("/{connection_id}", response_model=IntegrationConnectionRead)
async def update(
    connection_id: uuid.UUID,
    body: IntegrationConnectionUpdate,
    session: _Session,
) -> IntegrationConnectionRead:
    """Update an existing integration connection."""
    conn = await get_integration(session, connection_id)
    if conn is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integration not found.")
    if body.display_name is not None:
        conn.display_name = body.display_name
    if body.is_active is not None:  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
        conn.is_active = body.is_active  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
    if body.credentials is not None:
        await update_integration_credentials(session, conn, body.credentials)
    await session.flush()
    await session.commit()
    return conn


@router.post("/{connection_id}/test", response_model=IntegrationTestResult)
async def test_connection(
    connection_id: uuid.UUID,
    session: _Session,
) -> IntegrationTestResult:
    """Test connectivity for an integration.

    Verifies that credentials are stored and decryptable. For Hunter.io, also
    performs a lightweight domain-search call when the key looks like a real
    production key (not a placeholder).
    """
    conn = await get_integration(session, connection_id)
    if conn is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integration not found.")

    from backbone.core.security.encryption import decrypt_credentials
    from backbone.integrations.base import ToolError

    # Step 1: verify the credentials can be decrypted.
    try:
        creds = decrypt_credentials(conn.credentials)
    except Exception as exc:
        return IntegrationTestResult(
            provider_slug=conn.provider_slug,
            success=False,
            message=f"Credential decryption failed: {exc}",
        )

    if conn.provider_slug == "hunter":
        api_key: str = creds.get("api_key", "")
        if not api_key:
            return IntegrationTestResult(
                provider_slug=conn.provider_slug,
                success=False,
                message="No api_key found in stored credentials.",
            )

        # Skip live network call for obvious placeholder/test keys.
        if api_key.startswith("sk-hunter-test") or len(api_key) < 20:
            return IntegrationTestResult(
                provider_slug=conn.provider_slug,
                success=True,
                message=(
                    "Credentials stored and decrypted successfully. "
                    "Replace with a real Hunter.io API key to enable live enrichment."
                ),
            )

        # Real key — attempt a lightweight domain-search call.
        try:
            from backbone.integrations.providers.hunter import HunterIntegration

            provider = HunterIntegration(conn)
            result = await provider.search_domain(session, domain="anthropic.com", limit=1)
            return IntegrationTestResult(
                provider_slug=conn.provider_slug,
                success=True,
                message="Connection successful.",
                data={"sample_email_count": len(result.data.get("emails", []))},
            )
        except ToolError as exc:
            return IntegrationTestResult(
                provider_slug=conn.provider_slug,
                success=False,
                message=str(exc),
            )
        except Exception as exc:
            return IntegrationTestResult(
                provider_slug=conn.provider_slug,
                success=False,
                message=f"Unexpected error during connectivity test: {exc}",
            )

    return IntegrationTestResult(
        provider_slug=conn.provider_slug,
        success=True,
        message=f"Credentials stored and decrypted successfully for '{conn.provider_slug}'.",
    )


@router.delete("/{connection_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(connection_id: uuid.UUID, session: _Session) -> None:
    """Permanently delete an integration connection."""
    conn = await get_integration(session, connection_id)
    if conn is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integration not found.")
    await session.delete(conn)
    await session.commit()
