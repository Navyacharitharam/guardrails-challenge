"""Tenant self-service endpoints."""
import uuid
from typing import Annotated

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_id, get_tenant_session
from backbone.models.tenant import Tenant
from backbone.schemas.tenant import TenantRead

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/tenants", tags=["tenants"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]
_TenantId = Annotated[uuid.UUID, Depends(get_tenant_id)]


@router.get("/me", response_model=TenantRead)
async def get_me(tenant_id: _TenantId, session: _Session) -> TenantRead:
    """Return the authenticated tenant's profile."""
    result = await session.execute(select(Tenant).where(Tenant.id == tenant_id))
    tenant = result.scalar_one_or_none()
    if tenant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant not found.",
        )
    return TenantRead.model_validate(tenant)
