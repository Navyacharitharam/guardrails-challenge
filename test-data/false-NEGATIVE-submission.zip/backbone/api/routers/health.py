"""Health check endpoint."""
from fastapi import APIRouter

from backbone.core.config import settings

router = APIRouter(tags=["meta"])


@router.get("/health")
async def health() -> dict:
    """Liveness probe — returns service status, version, and environment."""
    return {"status": "ok", "version": "1.0.0", "environment": settings.ENVIRONMENT}
