"""Agent run endpoints — trigger, poll status, stream steps."""
import uuid
from typing import Annotated

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_id, get_tenant_session
from backbone.repositories.agent_repo import (
    create_agent_run,
    get_agent_run,
    list_agent_runs,
    list_steps_for_run,
)
from backbone.schemas.agent import AgentRunCreate, AgentRunRead, AgentStepRead

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/runs", tags=["agent-runs"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]
_TenantId = Annotated[uuid.UUID, Depends(get_tenant_id)]


@router.post("", response_model=AgentRunRead, status_code=status.HTTP_202_ACCEPTED)
async def start_run(
    body: AgentRunCreate,
    session: _Session,
    tenant_id: _TenantId,
) -> AgentRunRead:
    """Enqueue a new agent run and return the run record immediately.

    The run executes asynchronously in the ARQ worker pool.
    Poll GET /api/runs/{id} to check status.
    """
    run = await create_agent_run(
        session,
        tenant_id=tenant_id,
        workflow_type=body.workflow_type,
        icp_id=body.icp_id,
        input_payload=body.input_payload,
    )
    await session.commit()

    # Enqueue the job in ARQ — import lazily to avoid circular imports.
    try:
        from arq import create_pool
        from backbone.workers.settings import WorkerSettings

        redis = await create_pool(WorkerSettings.redis_settings)
        await redis.enqueue_job(
            "run_prospect_workflow",
            str(run.id),
            str(tenant_id),
        )
        await redis.aclose()
    except Exception as exc:
        log.warning("agent_run.enqueue_failed", run_id=str(run.id), error=str(exc))

    log.info("agent_run.created", run_id=str(run.id), workflow=body.workflow_type)
    return run


@router.get("", response_model=list[AgentRunRead])
async def list_runs(
    session: _Session,
    limit: int = 20,
    offset: int = 0,
) -> list[AgentRunRead]:
    """Return recent agent runs for the authenticated tenant."""
    return await list_agent_runs(session, limit=limit, offset=offset)


@router.get("/{run_id}", response_model=AgentRunRead)
async def get_run(run_id: uuid.UUID, session: _Session) -> AgentRunRead:
    """Return an agent run by ID (poll this for live status)."""
    run = await get_agent_run(session, run_id)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")
    return run


@router.get("/{run_id}/steps", response_model=list[AgentStepRead])
async def get_run_steps(run_id: uuid.UUID, session: _Session) -> list[AgentStepRead]:
    """Return all steps for an agent run (the full execution trace)."""
    run = await get_agent_run(session, run_id)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found.")
    return await list_steps_for_run(session, run_id)
