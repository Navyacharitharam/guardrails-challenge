"""ICP (Ideal Customer Profile) CRUD endpoints."""
import uuid
from typing import Annotated

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_id, get_tenant_session
from backbone.repositories.icp_repo import create_icp, get_icp, list_icps
from backbone.schemas.icp import ICPCreate, ICPRead, ICPUpdate

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/icps", tags=["icps"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]
_TenantId = Annotated[uuid.UUID, Depends(get_tenant_id)]


@router.get("", response_model=list[ICPRead])
async def list_all_icps(session: _Session) -> list[ICPRead]:
    """Return all ICPs for the authenticated tenant."""
    return await list_icps(session)


@router.post("", response_model=ICPRead, status_code=status.HTTP_201_CREATED)
async def create_new_icp(
    body: ICPCreate,
    session: _Session,
    tenant_id: _TenantId,
) -> ICPRead:
    """Create a new ICP for the authenticated tenant."""
    icp = await create_icp(
        session,
        tenant_id=tenant_id,
        name=body.name,
        description=body.description,
        firmographic_criteria=body.firmographic_criteria,
        technographic_criteria=body.technographic_criteria,
        persona_criteria=body.persona_criteria,
        signal_weights=body.signal_weights,
        is_active=body.is_active,  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
    )
    await session.commit()
    log.info("icp.created", icp_id=str(icp.id), tenant_id=str(tenant_id))
    return icp


@router.get("/{icp_id}", response_model=ICPRead)
async def get_one_icp(icp_id: uuid.UUID, session: _Session) -> ICPRead:
    """Return a single ICP by ID."""
    icp = await get_icp(session, icp_id)
    if icp is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="ICP not found.")
    return icp


@router.patch("/{icp_id}", response_model=ICPRead)
async def update_icp(
    icp_id: uuid.UUID,
    body: ICPUpdate,
    session: _Session,
) -> ICPRead:
    """Partially update an ICP."""
    icp = await get_icp(session, icp_id)
    if icp is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="ICP not found.")
    for field, value in body.model_dump(exclude_none=True).items():
        setattr(icp, field, value)
    await session.flush()
    await session.commit()
    return icp
