"""Human review queue endpoints."""
import uuid
from typing import Annotated

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_session
from backbone.models.enums import HumanReviewStatus
from backbone.repositories.agent_repo import (
    get_human_review,
    list_pending_reviews,
    resolve_human_review,
)
from backbone.schemas.agent import HumanReviewRead, HumanReviewResolve

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/reviews", tags=["reviews"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]


@router.get("/pending", response_model=list[HumanReviewRead])
async def list_pending(
    session: _Session,
    limit: int = 20,
    offset: int = 0,
) -> list[HumanReviewRead]:
    """Return all pending human reviews, oldest first."""
    return await list_pending_reviews(session, limit=limit, offset=offset)


@router.get("/{review_id}", response_model=HumanReviewRead)
async def get_review(review_id: uuid.UUID, session: _Session) -> HumanReviewRead:
    """Return a single human review by ID."""
    review = await get_human_review(session, review_id)
    if review is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Review not found.")
    return review


@router.patch("/{review_id}", response_model=HumanReviewRead)
async def resolve_review(
    review_id: uuid.UUID,
    body: HumanReviewResolve,
    session: _Session,
) -> HumanReviewRead:
    """Approve, reject, or modify a pending human review."""
    review = await get_human_review(session, review_id)
    if review is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Review not found.")
    if review.status != HumanReviewStatus.PENDING:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Review is already resolved (status: {review.status.value}).",
        )
    if body.status == HumanReviewStatus.MODIFIED and not body.modified_output:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="modified_output is required when status is 'modified'.",
        )
    updated = await resolve_human_review(
        session,
        review,
        status=body.status,
        reviewer_notes=body.reviewer_notes,
        modified_output=body.modified_output,
    )
    await session.commit()
    log.info(
        "review.resolved",
        review_id=str(review_id),
        status=body.status.value,
    )
    return updated
