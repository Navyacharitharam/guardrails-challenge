"""Authentication router — login and token refresh."""
import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.core.database.engine import AsyncSessionFactory
from backbone.core.security.auth import create_access_token, decode_token, verify_password
from backbone.models.tenant import Tenant
from backbone.schemas.tenant import LoginRequest, TokenResponse

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/auth", tags=["auth"])

_bearer = HTTPBearer(auto_error=True)


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest) -> TokenResponse:
    """Authenticate with email + password and receive a JWT.

    The token encodes the tenant_id as the ``sub`` claim.
    Present it in subsequent requests as ``Authorization: Bearer <token>``.
    """
    async with AsyncSessionFactory() as session:
        result = await session.execute(
            select(Tenant).where(Tenant.admin_email == body.email)
        )
        tenant = result.scalar_one_or_none()

    if tenant is None or not verify_password(body.password, tenant.admin_password_hash):
        log.warning("auth.login_failed", email=body.email)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = create_access_token(tenant_id=tenant.id, email=tenant.admin_email)
    log.info("auth.login_success", tenant_id=str(tenant.id))
    return TokenResponse(access_token=token, tenant_id=tenant.id)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
) -> TokenResponse:
    """Validate the current JWT and issue a fresh token with a reset expiry.

    Present the existing Bearer token — if it is still valid the response
    contains a new token with a full expiry window.
    """
    try:
        tenant_id = decode_token(credentials.credentials)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    async with AsyncSessionFactory() as session:
        result = await session.execute(
            select(Tenant).where(Tenant.id == tenant_id)
        )
        tenant = result.scalar_one_or_none()

    if tenant is None or not tenant.is_active:  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tenant not found or inactive.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = create_access_token(tenant_id=tenant.id, email=tenant.admin_email)
    log.info("auth.refresh_success", tenant_id=str(tenant.id))
    return TokenResponse(access_token=token, tenant_id=tenant.id)
