"""Record CRUD endpoints (Accounts, Contacts, any object type)."""
import uuid
from typing import Annotated, Optional

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_id, get_tenant_session
from backbone.repositories.record_repo import (
    create_record,
    get_record,
    list_records,
    update_record_attributes,
)
from backbone.schemas.record import RecordCreate, RecordRead, RecordUpdate

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/records", tags=["records"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]
_TenantId = Annotated[uuid.UUID, Depends(get_tenant_id)]


@router.get("", response_model=list[RecordRead])
async def list_all_records(
    session: _Session,
    object_definition_id: Optional[uuid.UUID] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
) -> list[RecordRead]:
    """Return paginated records, optionally filtered by object type."""
    return await list_records(
        session,
        object_definition_id=object_definition_id,
        limit=limit,
        offset=offset,
    )


@router.post("", response_model=RecordRead, status_code=status.HTTP_201_CREATED)
async def create_new_record(
    body: RecordCreate,
    session: _Session,
    tenant_id: _TenantId,
) -> RecordRead:
    """Create a new Record of the given object type."""
    record = await create_record(
        session,
        tenant_id=tenant_id,
        object_definition_id=body.object_definition_id,
        external_id=body.external_id,
        attributes=body.attributes,
    )
    await session.commit()
    return record


@router.get("/{record_id}", response_model=RecordRead)
async def get_one_record(record_id: uuid.UUID, session: _Session) -> RecordRead:
    """Return a single Record by ID."""
    record = await get_record(session, record_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Record not found.")
    return record


@router.patch("/{record_id}", response_model=RecordRead)
async def update_record(
    record_id: uuid.UUID,
    body: RecordUpdate,
    session: _Session,
) -> RecordRead:
    """Partially update a Record's attributes."""
    record = await get_record(session, record_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Record not found.")
    if body.attributes:
        await update_record_attributes(session, record_id, body.attributes)
    if body.external_id is not None:
        record.external_id = body.external_id
    await session.flush()
    await session.commit()
    await session.refresh(record)
    return record
