"""Signal read endpoints."""
import uuid
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_session
from backbone.models.enums import SignalType
from backbone.repositories.signal_repo import list_signals_for_record
from backbone.schemas.signal import SignalRead

router = APIRouter(prefix="/signals", tags=["signals"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]


@router.get("", response_model=list[SignalRead])
async def list_signals(
    session: _Session,
    record_id: uuid.UUID = Query(...),
    signal_type: Optional[SignalType] = Query(None),
    limit: int = Query(50, ge=1, le=200),
) -> list[SignalRead]:
    """Return signals for a specific record."""
    return await list_signals_for_record(
        session,
        record_id,
        signal_type=signal_type,
        limit=limit,
    )
