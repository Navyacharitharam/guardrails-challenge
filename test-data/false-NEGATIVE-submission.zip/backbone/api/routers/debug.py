"""Development-only diagnostic endpoints."""
import uuid
from typing import Annotated, Any

from fastapi import APIRouter, Depends
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.api.deps import get_tenant_id, get_tenant_session
from backbone.models.icp import ICP

router = APIRouter(prefix="/debug", tags=["debug"])

_Session = Annotated[AsyncSession, Depends(get_tenant_session)]
_TenantId = Annotated[uuid.UUID, Depends(get_tenant_id)]


@router.get("/tenant")
async def debug_tenant(session: _Session, tenant_id: _TenantId) -> dict[str, Any]:
    """Return tenant context diagnostics.

    Shows the tenant_id from the JWT, the tenant_id that PostgreSQL RLS
    sees via current_tenant_id(), and the number of ICPs visible to this
    tenant.  Useful for diagnosing 'No ICP configured' when seed data exists.
    """
    pg_result = await session.execute(text("SELECT current_tenant_id()"))
    pg_tenant_id: uuid.UUID | None = pg_result.scalar()

    icp_count_result = await session.execute(
        select(func.count()).select_from(ICP)
    )
    icp_count: int = icp_count_result.scalar() or 0

    return {
        "jwt_tenant_id": str(tenant_id),
        "pg_tenant_id": str(pg_tenant_id) if pg_tenant_id else None,
        "rls_match": pg_tenant_id == tenant_id,
        "icp_count_visible": icp_count,
        "diagnosis": (
            "OK — RLS is passing the right tenant to PostgreSQL."
            if pg_tenant_id == tenant_id and icp_count > 0
            else (
                "ICP count is 0. Seed data may belong to a different tenant UUID. "
                "Sign out, sign back in, and check again."
                if pg_tenant_id == tenant_id
                else "RLS tenant mismatch — jwt_tenant_id != pg_tenant_id."
            )
        ),
    }
