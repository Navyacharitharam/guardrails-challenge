"""TenantMiddleware — sets the PostgreSQL RLS tenant context from the JWT.

For routes that go through ``get_tenant_session`` (the FastAPI dependency),
the RLS context is set per-request inside the dependency.  This middleware
provides an *additional* layer: it validates the JWT early in the request
pipeline and attaches the decoded tenant_id to ``request.state`` so it is
available to any component without repeating the JWT decode.

Middleware vs. dependency trade-offs
-------------------------------------
- The FastAPI dependency (``backbone.api.deps.get_tenant_session``) is the
  primary mechanism for database isolation.  It sets ``SET LOCAL`` so the
  context is transaction-scoped and never leaks across requests.
- This middleware is a request-scoped annotation layer only — it does NOT
  open a database connection or set any PostgreSQL variable.  Any route that
  needs a real DB session must still use the dependency.
- Routes that bypass authentication (``/health``, ``/docs``, ``/auth/login``)
  are passed through without a JWT requirement.

Error handling
--------------
If the JWT is missing or invalid the middleware returns a 401 JSON response
directly without calling the route handler.  This means unauthenticated
requests never reach application code on protected routes.
"""
import uuid
from collections.abc import Callable

import structlog
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from backbone.core.security.auth import decode_token

log = structlog.get_logger(__name__)

# Paths that do not require a valid JWT.
_OPEN_PATHS: frozenset[str] = frozenset(
    {
        "/health",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/auth/login",
    }
)


class TenantMiddleware(BaseHTTPMiddleware):
    """Starlette middleware that decodes the JWT and stamps ``request.state``.

    Sets:
        ``request.state.tenant_id`` — ``uuid.UUID`` of the authenticated tenant,
            or ``None`` for open (unauthenticated) paths.

    Returns ``401 Unauthorized`` for protected paths with a missing or
    invalid Bearer token.
    """

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        path = request.url.path

        if path in _OPEN_PATHS or path.startswith("/docs") or path.startswith("/redoc"):
            request.state.tenant_id = None
            return await call_next(request)

        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return JSONResponse(
                status_code=401,
                content={"detail": "Missing or malformed Authorization header."},
            )

        token = auth_header.removeprefix("Bearer ").strip()
        try:
            tenant_id: uuid.UUID = decode_token(token)
        except Exception:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or expired access token."},
            )

        request.state.tenant_id = tenant_id
        log.debug(
            "tenant_middleware.authenticated",
            tenant_id=str(tenant_id),
            path=path,
            method=request.method,
        )
        return await call_next(request)


