"""Response envelope middleware.

Wraps every JSON response in a consistent shape:
  - 2xx: ``{"data": <original_body>, "meta": {"timestamp": ..., "request_id": ...}}``
  - 4xx/5xx: ``{"error": {"code": ..., "message": ..., "details": ...}, "meta": {...}}``

Responses with no body (204) or non-JSON content-type are passed through unchanged,
with only the ``X-Request-ID`` header appended.
"""
import json
import uuid
from collections.abc import Callable
from datetime import datetime, timezone

import structlog
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from starlette.types import ASGIApp

log = structlog.get_logger(__name__)


class EnvelopeMiddleware(BaseHTTPMiddleware):
    """Outermost middleware that stamps request_id and wraps JSON responses."""

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id

        response = await call_next(request)

        content_type = response.headers.get("content-type", "")

        if response.status_code == 204 or "application/json" not in content_type:
            response.headers["X-Request-ID"] = request_id
            return response

        # Buffer the body iterator so we can inspect and re-wrap it.
        body_chunks: list[bytes] = []
        async for chunk in response.body_iterator:
            body_chunks.append(chunk)
        body_bytes = b"".join(body_chunks)

        try:
            original = json.loads(body_bytes)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return Response(
                content=body_bytes,
                status_code=response.status_code,
                media_type=content_type,
                headers={"X-Request-ID": request_id},
            )

        meta = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "request_id": request_id,
        }

        if response.status_code < 400:
            wrapped: dict = {"data": original, "meta": meta}
        else:
            detail = original.get("detail", str(original))
            if isinstance(detail, str):
                error = {
                    "code": response.status_code,
                    "message": detail,
                    "details": None,
                }
            else:
                # Pydantic validation errors return a list
                error = {
                    "code": response.status_code,
                    "message": "Request validation failed.",
                    "details": detail,
                }
            wrapped = {"error": error, "meta": meta}

        return JSONResponse(
            content=wrapped,
            status_code=response.status_code,
            headers={"X-Request-ID": request_id},
        )
