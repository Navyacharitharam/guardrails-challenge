"""FastAPI application factory."""
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import structlog
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backbone.api.middleware.envelope import EnvelopeMiddleware
from backbone.api.middleware.logging import LoggingMiddleware
from backbone.api.middleware.tenant import TenantMiddleware
from backbone.api.routers import (
    agent_runs,
    auth,
    debug,
    health,
    human_reviews,
    icps,
    integrations,
    records,
    signals,
    tenants,
)
from backbone.core.config import settings
from backbone.core.logging import configure_logging

configure_logging()
log = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan — runs startup logic, yields, then runs shutdown."""
    log.info(
        "gtm_platform.startup",
        version="1.0.0",
        environment=settings.ENVIRONMENT,
    )
    yield
    log.info("gtm_platform.shutdown")


app = FastAPI(
    title="GTM Platform API",
    description=(
        "AI-native Go-To-Market platform. "
        "Custom agent orchestration with full trace visibility."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Exception handlers
# ---------------------------------------------------------------------------


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """Return a 422 with structured validation errors."""
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors()},
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Catch-all handler — log and return a 500."""
    log.exception("unhandled_exception", path=request.url.path, error=str(exc))
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An unexpected error occurred."},
    )


# ---------------------------------------------------------------------------
# Middleware (add_middleware inserts at front → last call = outermost layer)
# ---------------------------------------------------------------------------

# Innermost: CORS handles preflight OPTIONS and injects CORS headers on all responses.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://frontend:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# TenantMiddleware: decodes JWT and stamps request.state.tenant_id.
app.add_middleware(TenantMiddleware)

# LoggingMiddleware: structured request/response logging (reads tenant_id from state).
app.add_middleware(LoggingMiddleware)

# Outermost: EnvelopeMiddleware stamps request_id and wraps JSON bodies.
app.add_middleware(EnvelopeMiddleware)


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------

# Open endpoints (no /api prefix, no auth required)
app.include_router(health.router)
app.include_router(auth.router)

# Authenticated API endpoints
_API_PREFIX = "/api"
app.include_router(tenants.router, prefix=_API_PREFIX)
app.include_router(icps.router, prefix=_API_PREFIX)
app.include_router(records.router, prefix=_API_PREFIX)
app.include_router(signals.router, prefix=_API_PREFIX)
app.include_router(agent_runs.router, prefix=_API_PREFIX)
app.include_router(human_reviews.router, prefix=_API_PREFIX)
app.include_router(integrations.router, prefix=_API_PREFIX)

# Debug endpoints — only mounted in non-production environments.
if settings.ENVIRONMENT != "production":
    app.include_router(debug.router, prefix=_API_PREFIX)
