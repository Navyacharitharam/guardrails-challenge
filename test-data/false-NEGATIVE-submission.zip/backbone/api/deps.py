"""FastAPI dependency factories shared across routers.

Usage::

    @router.get("/things")
    async def list_things(
        tenant_id: uuid.UUID = Depends(get_tenant_id),
        session: AsyncSession = Depends(get_tenant_session),
    ) -> list[ThingRead]:
        ...
"""
import uuid
from collections.abc import AsyncGenerator

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.core.database.engine import AsyncSessionFactory
from backbone.core.database.rls import set_tenant_context
from backbone.core.security.auth import get_current_tenant_id


async def get_tenant_id(
    tenant_id: uuid.UUID = Depends(get_current_tenant_id),
) -> uuid.UUID:
    """Return the authenticated tenant's UUID."""
    return tenant_id


async def get_tenant_session(
    tenant_id: uuid.UUID = Depends(get_tenant_id),
) -> AsyncGenerator[AsyncSession, None]:
    """Yield a session with the tenant RLS context already set."""
    async with AsyncSessionFactory() as session:
        await set_tenant_context(session, tenant_id)
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
