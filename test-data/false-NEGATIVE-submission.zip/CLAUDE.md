# GTM Platform — Claude Code Instructions

## Project
AI-native GTM platform. Competition submission. All architectural decisions are finalized.
Never propose alternative architectures. Implement what is specified.

## Stack
- Backend: Python 3.12, FastAPI, SQLAlchemy 2.0 async, Alembic, ARQ, PostgreSQL 16
- LLM: Anthropic Claude claude-sonnet-4-5 via official SDK (NEVER LangChain)
- Frontend: Next.js 14 App Router, TypeScript, Tailwind CSS, Radix UI primitives
- Queue: ARQ + Redis
- Auth: JWT + bcrypt

## Critical rules
1. NEVER use LangChain, LlamaIndex, or any agent framework
2. NEVER use WHERE tenant_id = ? — RLS handles tenant filtering automatically  
3. NEVER write raw SQL — use SQLAlchemy ORM only
4. ALL agent tool calls MUST write an AgentStep record before AND after execution
5. ALL credentials stored in IntegrationConnection MUST be encrypted (Fernet)
6. Pydantic models are the single source of truth for API request/response shapes
7. Every async function must have a corresponding test in /tests/

## Code style
- Black formatter, 88 char line length
- isort for imports (stdlib, third-party, local — separated by blank lines)
- Type hints on every function signature
- Docstrings on every class and public method
- No print() — use structlog logger
- No TODO comments — either implement or file as a known limitation in README

## File naming
- Snake_case for all Python files and variables
- PascalCase for classes
- kebab-case for Next.js files and CSS classes
- SCREAMING_SNAKE_CASE for constants

## When generating database models
Always include: id (UUID PK), tenant_id (UUID FK), created_at (timestamp with default)
Always use: UUID as primary keys (not integer autoincrement)
Always add: appropriate indexes (tenant_id + common query fields)

## When generating agent tools
Each tool must:
1. Accept typed Pydantic input
2. Return ToolResult (success) or raise ToolError (retriable/fatal)
3. Have no side effects except through the data_tools.py functions
4. Be independently testable without the orchestrator

## Seed data requirement
Seed data must be realistic:
- Company names: real-sounding SaaS companies (not "Acme Corp")
- Contacts: real-sounding names with realistic job titles
- Signals: realistic signal data (specific funding amounts, specific job posting titles)