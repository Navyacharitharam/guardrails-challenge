# GTM Platform

AI-native Go-To-Market platform. A Claude-powered autonomous agent runs a 6-stage Prospect workflow — discovering accounts, enriching contacts, scoring intent, generating value hypotheses, and drafting personalized outreach — pausing for human approval before irreversible actions.

**Demo:** https://youtu.be/FMq1C-jzvaw

## Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.12, FastAPI, SQLAlchemy 2.0 async, Alembic |
| LLM | Claude claude-sonnet-4-5 via Anthropic SDK (no LangChain) |
| Queue | ARQ + Redis |
| Database | PostgreSQL 16 with Row-Level Security |
| Auth | JWT (HS256) + bcrypt |
| Frontend | Next.js 14 App Router, TypeScript, Tailwind CSS |

## Prerequisites

- Docker Desktop (or Docker Engine + Compose plugin)
- Anthropic API key (`sk-ant-...`)
- Hunter.io API key (optional — enrichment degrades gracefully without it)

## Setup

**1. Clone and configure**

```bash
git clone <repo-url>
cd gtm-platform
cp .env.example .env   # or create .env manually
```

Edit `.env`:

```env
ANTHROPIC_API_KEY=sk-ant-api03-your-key-here
HUNTER_API_KEY=your-hunter-key          # optional
FERNET_KEY=your-fernet-key-here  # keep default for dev
SECRET_KEY=your-secret-key-here          # keep default for dev
```

**2. Start all services**

```bash
docker compose up --build
```

This runs in order:
1. `postgres` + `redis` (health-checked)
2. `db-init` — Alembic migrations + seed data (two demo tenants, ICP, accounts, contacts, signals, Hunter.io connection)
3. `backend` (port 8001) + `worker` + `frontend` (port 3001)

**3. Open the UI**

Navigate to `http://localhost:3001`. Log in with the seed credentials:

| Tenant | Email | Password |
|--------|-------|----------|
| Acme GTM | `admin@acme-gtm.io` | `acme_password_2025` |
| Velocity Sales | `admin@velocitysales.io` | `velocity_password_2025` |

## Running the Prospect Loop

**Via the UI:**
1. Log in → navigate to **Runs** → **New Run**
2. Select workflow type `prospect` and your ICP
3. Click **Start** — the agent starts immediately

**Via the API:**
```bash
# 1. Authenticate
TOKEN=$(curl -s -X POST http://localhost:8001/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@acme-gtm.io","password":"acme_password_2025"}' \
  | jq -r '.data.access_token')

# 2. Get your ICP id
ICP_ID=$(curl -s http://localhost:8001/api/icps \
  -H "Authorization: Bearer $TOKEN" | jq -r '.data[0].id')

# 3. Start a run
RUN_ID=$(curl -s -X POST http://localhost:8001/api/runs \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"workflow_type\":\"prospect\",\"icp_id\":\"$ICP_ID\"}" \
  | jq -r '.data.id')

# 4. Poll until status != "running"
curl -s http://localhost:8001/api/runs/$RUN_ID \
  -H "Authorization: Bearer $TOKEN" | jq '.data.status'

# 5. View execution steps
curl -s http://localhost:8001/api/runs/$RUN_ID/steps \
  -H "Authorization: Bearer $TOKEN" | jq '.data[].tool_name'

# 6. Approve the outreach (when status is pending_review)
REVIEW_ID=$(curl -s http://localhost:8001/api/runs/$RUN_ID \
  -H "Authorization: Bearer $TOKEN" | jq -r '.data.pending_review_id')

curl -s -X PATCH http://localhost:8001/api/reviews/$REVIEW_ID \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status":"approved","reviewer_notes":"Looks good, send it."}'
```

The run proceeds through 6 stages automatically:

```
Stage 1: Load ICP         → read target criteria
Stage 2: Discover         → score all accounts against ICP, rank by fit_score
Stage 3: Enrich           → find professional emails via Hunter.io waterfall
Stage 4: Signals          → load funding/hiring/intent signals, compute intent_score
Stage 5: Hypothesis       → Claude drafts a value hypothesis (pain + relevance)
Stage 6: Outreach         → Claude drafts 2 email variants → PAUSES for human review
```

## Running Tests

The RLS tests require a running PostgreSQL instance. All other tests run without Docker.

```bash
# Create the test database (once, only needed for test_rls.py)
docker compose exec postgres psql -U gtm -d gtm -c "CREATE DATABASE gtm_test;"

# Run the full suite (14 pass without Docker; 3 RLS tests require Docker)
python -m pytest tests/ -v

# Run individual modules
python -m pytest tests/test_agent_tools.py -v   # pure unit tests, no DB
python -m pytest tests/test_health.py -v         # FastAPI TestClient, no DB
python -m pytest tests/test_rls.py -v            # requires Docker + gtm_test DB
```

`pytest.ini` configures `asyncio_mode = auto`. The RLS tests create a non-superuser role `gtm_rls_tester` automatically during setup to properly exercise row-level security.

## Repository Map

```
gtm-platform/
├── backbone/                   Backend Python package
│   ├── agents/                 Orchestrator + 14 agent tools
│   │   ├── orchestrator.py     Main agentic loop (≤50 iterations)
│   │   ├── prospect_tools.py   Tool registry for the Prospect workflow
│   │   └── tools/              One file per tool (load_icp, enrich_contact, …)
│   ├── api/                    FastAPI application
│   │   ├── app.py              ASGI app, middleware, router mounts
│   │   ├── deps.py             JWT auth + RLS session dependencies
│   │   ├── middleware/         Tenant isolation, envelope wrapper, logging
│   │   └── routers/            REST endpoints (runs, reviews, icps, records, …)
│   ├── core/                   Shared utilities
│   │   ├── config.py           Pydantic settings (env vars)
│   │   ├── database/           SQLAlchemy engine + Base
│   │   └── security/           JWT helpers, bcrypt hashing, Fernet encryption
│   ├── integrations/           External data provider framework
│   │   ├── base.py             BaseIntegration, ToolResult, ToolError
│   │   ├── waterfall.py        Multi-provider resolver with rate-limit awareness
│   │   └── providers/          hunter.py — more providers added here
│   ├── models/                 SQLAlchemy ORM models (all RLS-protected)
│   ├── repositories/           Data access layer (agent_repo, signal_repo, …)
│   ├── schemas/                Pydantic request/response shapes
│   ├── workers/                ARQ worker settings + job entrypoints
│   └── alembic/                Migration scripts (5 revisions)
│
├── prospect/                   Prospect workflow package
│   ├── scoring/                icp_scorer.py, intent_scorer.py
│   └── workflows/              ProspectWorkflow + 6 stage modules
│
├── frontend/                   Next.js 14 App Router UI
│   └── src/app/                Pages: dashboard, runs, reviews, settings
│
├── data/                       Seed data (2 tenants, realistic accounts/contacts)
├── infra/                      Dockerfiles, postgres init SQL
├── tests/                      Pytest test suite (17 tests)
├── traces/                     3 real agent execution traces (JSON)
├── docs/                       Architecture, agents, integrations docs
├── compose.yml                 Docker Compose (6 services)
└── pytest.ini                  asyncio_mode=auto, testpaths=tests
```

## What Is Built vs. Stubbed

| Feature | Status | Notes |
|---------|--------|-------|
| PostgreSQL RLS multi-tenancy | Built | Auto-applied DDL trigger; zero `WHERE tenant_id=?` in app code |
| JWT auth + bcrypt | Built | Login, refresh; bcrypt 5.x direct (no passlib) |
| 6-stage Prospect workflow | Built | Stages 1–6 all implemented and tested |
| Agent orchestration loop | Built | Max 50 iterations, before/after AgentStep writes |
| ICP fit scoring | Built | Firmographic (0.50) + technographic (0.20) + persona (0.30); disqualifier short-circuit |
| Intent scoring | Built | Signal-weighted, recency-decayed |
| Hunter.io integration | Built | email-finder + domain-search, Fernet-encrypted key, rate-limit tracking |
| Integration waterfall | Built | Operation-based, RLS-scoped, rate-limit-aware; provider registration via decorator |
| Human-in-the-loop | Built | `request_human_review` suspends run; `PATCH /api/reviews/{id}` resumes |
| Value hypothesis generation | Built | Claude call with structured tool output |
| Outreach draft generation | Built | 2 variants (conversational + direct), ≤200 words each |
| Email dispatch (Engage) | Stubbed | Outreach is drafted and approved; no SendGrid/Gmail integration yet |
| Deal pipeline (Manage) | Stubbed | Relationship edges exist; pipeline stages not implemented |
| Revenue analytics (Operate) | Stubbed | Scores computed; dashboard not built |
| Apollo.io / Clearbit providers | Stubbed | Waterfall supports them; providers not written |

## Documentation

- [Architecture](docs/architecture.md) — system diagram, data model, multi-tenancy, orchestration flow
- [Agents](docs/agents.md) — tool inventory, planning prompt, system prompt, failure handling, cost data
- [Integrations](docs/integrations.md) — Hunter.io auth/data flow, Record.attributes mapping, how to add new providers
- [Execution Traces](traces/) — 3 real agent runs with step-level timing and token counts

## Environment Variables

| Variable | Required | Default | Purpose |
|----------|----------|---------|---------|
| `ANTHROPIC_API_KEY` | Yes | — | Claude API access |
| `DATABASE_URL` | Yes | `postgresql+asyncpg://gtm:gtm_secret@postgres:5432/gtm` | Async DB connection |
| `SYNC_DATABASE_URL` | Yes | same (sync driver) | Alembic migrations |
| `REDIS_URL` | Yes | See `.env.example` (use `rediss://` scheme for TLS in production) | ARQ job queue |
| `SECRET_KEY` | Yes | dev default | JWT signing key |
| `FERNET_KEY` | Yes | dev default | Credential encryption |
| `HUNTER_API_KEY` | No | empty | Hunter.io enrichment (skipped if blank) |

All have safe development defaults in `compose.yml`. **Change `SECRET_KEY` and `FERNET_KEY` before any production deployment.**
