# GTM Platform — Integrations

## Hunter.io Integration

Hunter.io is the first and currently only data-enrichment provider. It is registered as provider slug `"hunter"` and supports two operations:

| Operation | Hunter.io endpoint | Use case |
|-----------|-------------------|----------|
| `find_email` | `GET /v2/email-finder` | Find one professional email for a named person at a domain |
| `search_domain` | `GET /v2/domain-search` | List all discoverable emails at a domain |

### Auth Flow

Hunter.io uses API key authentication. The key is stored as a Fernet-encrypted JSON blob in `integration_connections.credentials`:

```json
{"api_key": "<hunter-api-key>"}
```

No OAuth redirect is involved. To connect:
1. User navigates to **Settings → Integrations** in the UI.
2. UI calls `POST /api/integrations` with `provider_slug="hunter"` and `credentials={"api_key": "..."}`.
3. Backend calls `encrypt_credentials({"api_key": "..."})` (Fernet, key from `FERNET_KEY` env var) and stores the ciphertext.
4. At runtime, `BaseIntegration._credentials()` decrypts on demand.

The API key is **never logged** and **never returned** by any API endpoint. The `GET /api/integrations` response includes only metadata (id, slug, display_name, is_active, rate_limit_state).

### Data Flow

```
enrich_contact tool
    │
    └── waterfall.resolve("find_email", session, first_name=..., last_name=..., domain=...)
              │
              ├── _load_active_connections(session)  [RLS-scoped]
              │     → returns [IntegrationConnection(provider_slug="hunter", ...)]
              │
              └── HunterIntegration(conn).find_email(...)
                    │
                    ├── decrypt credentials → api_key
                    ├── GET https://api.hunter.io/v2/email-finder
                    │     ?domain=stripe.com&first_name=Sarah&last_name=Chen&api_key=...
                    │
                    ├── 200 OK → ToolResult(data={"email": "...", "score": 94, "position": "...", ...})
                    │     └── _decrement_and_persist(session)  [calls_remaining -= 1]
                    │
                    ├── 429 → _handle_rate_limit(session) → ToolError(retriable=True)
                    │     └── rate_limit_state = {"calls_remaining": 0, "reset_at": "2026-06-01..."}
                    │
                    └── 404 → ToolError(retriable=False)  [no email found — not a system error]

enrich_contact maps ToolResult.data → Record.attributes (JSONB merge):

    ToolResult.data field      Record.attributes key
    ─────────────────────────  ─────────────────────────
    "email"                 →  "email"
    "score"                 →  "email_score"
    "position"              →  "job_title"
    "linkedin_url"          →  "linkedin_url"
    provider_slug           →  "enrichment_source"
    (timestamp)             →  "enriched_at"  (ISO-8601 UTC)

Record.enrichment_status is set to "enriched" on success, "failed" on 404.
On 404 after the soft-result fix, enrichment_status="failed" but the run continues.
```

### Rate Limiting

Hunter.io uses monthly credits. The integration tracks state in `rate_limit_state` JSONB:

```json
{"calls_remaining": 22, "reset_at": "2026-06-01T00:00:00+00:00"}
```

The waterfall resolver skips connections where `calls_remaining <= 0` AND `reset_at` is in the future. On the first day of each month the reset_at passes, and the provider is attempted again — if the real API succeeds, calls_remaining is refreshed.

The free tier ships 25 credits/month. Paid plans are higher.

## Operational Concerns

| Concern | Details |
|---------|---------|
| **Key rotation** | Fernet is symmetric. Rotating the `FERNET_KEY` requires re-encrypting every `integration_connections.credentials` row. There is no automated rotation script; it must be done in a maintenance window. |
| **Credit exhaustion** | Hunter.io free tier: 25 credits/month. When `calls_remaining` reaches 0, the waterfall skips the provider until `reset_at` passes. Monitor `rate_limit_state` on `IntegrationConnection` rows to detect approaching exhaustion early. |
| **Connection validity** | Stale or revoked API keys surface as `ToolError(retriable=False)` at runtime. There is no background validity check. The recommended practice is to verify keys at connection creation time (add a lightweight `ping()` method to the provider). |
| **No email found (soft failure)** | A Hunter.io 404 no longer fails the run (as of the `enrich_contact` soft-result fix). The contact's `enrichment_status` is set to `failed` and the orchestrator continues to outreach drafting. Claude is informed via the tool result and can mention the missing email in the hypothesis. |
| **Test isolation** | Tests use `gtm_test` database. Hunter.io credentials seeded in `data/seed.py` use the `HUNTER_API_KEY` env var; if blank, the provider is still registered but returns 404 for every request (a real HTTP call with an empty key). |

## Complete New-Provider Skeleton (zero core code changes)

The following is a complete, runnable provider module. Copy it, replace the slug and API calls, and the waterfall picks it up automatically — **no changes to orchestrator, tools, or routing code**:

```python
# backbone/integrations/providers/clearbit.py
"""Clearbit enrichment provider — drop-in replacement for Hunter.io."""
import httpx
from backbone.integrations.base import BaseIntegration, ToolError, ToolResult
from backbone.integrations.waterfall import register_provider


@register_provider                          # ← one decorator, zero other wiring
class ClearbitIntegration(BaseIntegration):
    slug = "clearbit"
    display_name = "Clearbit"

    async def find_email(self, session, *, first_name, last_name, domain, **_):
        api_key = self._credentials().get("api_key", "")
        async with httpx.AsyncClient(timeout=10) as http:
            r = await http.get(
                "https://prospector.clearbit.com/v2/people/find",
                params={"email": f"{first_name}.{last_name}@{domain}"},
                headers={"Authorization": f"Bearer {api_key}"},
            )
        if r.status_code == 404:
            raise ToolError("No email found via Clearbit.", retriable=False)
        if r.status_code == 429:
            await self._persist_rate_limit_state(session, calls_remaining=0)
            raise ToolError("Clearbit rate limit hit.", retriable=True)
        r.raise_for_status()
        data = r.json()
        await self._decrement_and_persist(session)
        return ToolResult(
            provider_slug=self.slug,
            data={"email": data.get("email", ""), "score": data.get("quality", 0)},
        )

    async def search_domain(self, session, *, domain, limit=10, **_):
        # Clearbit does not support bulk domain search in the free tier.
        raise ToolError("search_domain not supported by Clearbit free tier.", retriable=False)
```

That's the entire provider. The waterfall loads it at startup via the `@register_provider` decorator scan. When `enrich_contact` calls `waterfall.resolve("find_email", ...)`:
1. It finds both Hunter and Clearbit in the active `IntegrationConnection` rows.
2. Tries Hunter first (by `created_at`); falls through to Clearbit on `ToolError(retriable=True)`.
3. Returns the first `ToolResult` that succeeds.

**No changes to**: orchestrator, tool registry, waterfall resolver, API routes, or migrations.

## How to Add the Next Integration

Adding a second provider (e.g. Apollo.io, Clearbit) requires four steps:

### 1. Create the provider module

```python
# backbone/integrations/providers/apollo.py
from backbone.integrations.base import BaseIntegration, ToolError, ToolResult
from backbone.integrations.waterfall import register_provider

@register_provider
class ApolloIntegration(BaseIntegration):
    slug = "apollo"
    display_name = "Apollo.io"

    async def find_email(self, session, *, first_name, last_name, domain):
        api_key = self._credentials().get("api_key", "")
        # ... call Apollo API ...
        return ToolResult(provider_slug=self.slug, data={"email": "..."})

    async def search_domain(self, session, *, domain, limit=10):
        # ... Apollo /people/search endpoint ...
        return ToolResult(provider_slug=self.slug, data={"emails": [...]})
```

### 2. Import the module so the decorator fires

```python
# backbone/agents/tools/enrich_contact.py
from backbone.integrations.providers import hunter as _hunter  # noqa: F401
from backbone.integrations.providers import apollo as _apollo   # noqa: F401  ← add this
```

### 3. Create the IntegrationConnection (UI or seed)

```python
# Via the API:
POST /api/integrations
{
  "provider_slug": "apollo",
  "display_name": "Apollo (prod)",
  "credentials": {"api_key": "your-apollo-key"}
}

# Or in data/seed.py alongside the Hunter seeding:
await _seed_integration_connection(engine, tenant_id, "apollo", {"api_key": os.getenv("APOLLO_API_KEY", "")})
```

### 4. The waterfall picks it up automatically

When `enrich_contact` calls `waterfall.resolve("find_email", ...)`, it loads all active connections, finds both Hunter and Apollo, and tries them in `created_at` order. No further changes are needed.

### Provider contract

A valid provider must:
- Set `slug` (string, unique, matches `IntegrationConnection.provider_slug`)
- Set `display_name` (human-readable)
- Implement the operations it supports (`find_email`, `search_domain`)
- Return `ToolResult` on success
- Raise `ToolError(retriable=False)` for terminal errors (bad key, no result)
- Raise `ToolError(retriable=True)` for transient errors (network timeout, rate limit)
- Call `self._persist_rate_limit_state(session, calls_remaining=..., reset_at=...)` when quota-limited

Operations the provider does not support can be omitted — the waterfall's `getattr(provider, operation, None)` check skips providers that don't implement the requested operation.
