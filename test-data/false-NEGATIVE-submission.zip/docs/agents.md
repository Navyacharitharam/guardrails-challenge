# GTM Platform — Agent Documentation

## Agent Inventory

The platform ships with one agent type: the **Prospect Agent**. It runs the 6-stage Prospect workflow autonomously, using Claude claude-sonnet-4-5 as the reasoning engine and 14 structured tools for data access.

### Runtime constants

| Constant | Value |
|----------|-------|
| Model | `claude-sonnet-4-5-20250929` |
| Max loop iterations | 50 |
| Max output tokens per LLM call | 4 096 |
| Temperature | (API default — not overridden) |

## Tools List

| # | Tool name | Stage | Description |
|---|-----------|-------|-------------|
| 1 | `load_icp` | 1 | Load and return ICP criteria (firmographic, technographic, persona, signal weights) by UUID |
| 2 | `score_company_fit` | 1 | Compute 0–1 fit_score for one Account against ICP criteria; persist to Record |
| 3 | `discover_companies` | 2 | Query all tenant Accounts, score each against ICP, return top N ranked by fit_score |
| 4 | `upsert_record` | cross | Create or update a Record idempotent on external_id; accepts Account or Contact slug |
| 5 | `create_relationship` | cross | Create typed directed edge between two Records (e.g. Contact `works_at` Account) |
| 6 | `create_activity` | cross | Append an immutable Activity event to the audit trail |
| 7 | `verify_email` | 3 | Find professional email via Hunter.io waterfall (no Record side-effects) |
| 8 | `enrich_contact` | 3 | Enrich Contact Record with email/position via waterfall; sets enrichment_status=enriched |
| 9 | `get_signals` | 4 | Load all signals for a Record, return sorted by score |
| 10 | `compute_intent_score` | 4 | Aggregate signals into weighted intent_score using ICP signal_weights; persist to Record |
| 11 | `generate_hypothesis` | 5 | Call Claude to generate a value hypothesis from signals, fit score, intent score, ICP |
| 12 | `generate_outreach` | 6 | Call Claude to draft a personalised email (subject + two body variants under 200 words) |
| 13 | `request_human_review` | control | Suspend the run and create a HumanReview record; block until approved/rejected |
| 14 | `complete_workflow` | control | Signal successful completion with structured output; terminates the run |

Each tool subclasses `AgentTool`, declares a JSON Schema `input_schema`, and either returns `ToolResult` or raises `ToolError(retriable=True/False)`.

## Actual Prompts

The following are the verbatim Python source files. Every string shown here is passed directly to the Anthropic API — no templating engine, no hidden transformations.

### `backbone/agents/prompts/planning.py` (full source)

```python
"""Planning prompts for multi-stage workflow decomposition.

These prompts are passed to Claude when the orchestrator needs the agent to
reason about *which* sub-goals to pursue before diving into tool calls.
Using a separate planning turn is optional — the main prospect workflow
doesn't require it because the stage order is deterministic.  Custom
workflows with branching logic (e.g. ABM vs. PLG) can inject planning
prompts before the main tool-use loop.
"""
from typing import Any

PROSPECT_PLANNING_PROMPT = """\
Before using any tools, outline a concise execution plan for the prospect workflow:

1. ICP loading — identify which ICP criteria matter most.
2. Discovery — how many accounts to evaluate and your minimum fit threshold.
3. Enrichment — which contacts to prioritise for email verification.
4. Signals — which signal types are most relevant given the ICP's weights.
5. Hypothesis — what evidence you need before generating a hypothesis.
6. Outreach — confirm you will request_human_review before completing.

Keep the plan to 6–8 bullet points. Do not call any tools yet.
"""

ENRICHMENT_PLANNING_PROMPT = """\
Before enriching contacts, plan your enrichment strategy:

1. Which contacts lack a verified email and have complete first/last name data.
2. The order in which to enrich (prioritise by fit_score descending).
3. What to do if the enrichment waterfall fails for a contact.
4. Maximum number of contacts to enrich in this run (default: 5).

State your plan, then proceed with tool calls.
"""


def build_planning_message(workflow_type: str, context: dict[str, Any] | None = None) -> str:
    """Return the planning prompt for a given workflow type."""
    _PROMPTS: dict[str, str] = {
        "prospect": PROSPECT_PLANNING_PROMPT,
        "enrichment": ENRICHMENT_PLANNING_PROMPT,
    }
    return _PROMPTS.get(workflow_type, "")
```

### `backbone/agents/prompts/system.py` (full source)

```python
"""Base system prompt and per-run augmentation helpers."""
import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from backbone.models.agent_run import AgentRun


BASE_SYSTEM_PROMPT = """\
You are an autonomous GTM (Go-To-Market) agent for an AI-native sales platform.

Your job is to execute the assigned workflow step-by-step using the available tools.
Think carefully before each tool call. Use the minimum number of tool calls needed.

Guidelines:
- Always call complete_workflow when you have finished all objectives.
- Call request_human_review before sending any outreach or making irreversible changes.
- If a tool returns an error, diagnose the cause before retrying. Do not retry the
  same call with identical parameters more than twice.
- If you cannot make progress after reasonable attempts, call complete_workflow with
  a summary of what was accomplished and what blocked further progress.
- Prefer precision over speed: enrich fewer records well rather than many records poorly.
- Never fabricate data. If enrichment fails, record the failure and move on.
- Cite specific signals and account attributes when generating hypotheses.
"""


def build_system_prompt(run: "AgentRun") -> str:
    """Return the full system prompt for a specific run."""
    lines = [BASE_SYSTEM_PROMPT]
    lines.append(f"\nWorkflow type: {run.workflow_type}")
    if run.icp_id:
        lines.append(f"ICP ID: {run.icp_id}")
    if run.input_payload:
        lines.append(
            f"\nRun parameters:\n{json.dumps(run.input_payload, indent=2, default=str)}"
        )
    return "\n".join(lines)


def build_initial_message(run: "AgentRun") -> str:
    """Generate the first user message that kicks off the run."""
    return (
        f"Execute the '{run.workflow_type}' workflow with the parameters provided "
        f"in your system context. Use available tools to accomplish all objectives, "
        f"then call complete_workflow when done."
    )
```

### Cost / Latency Measurements (3 measured runs)

Average run: **68–143 seconds**, **7–13 LLM calls**, approximately **$0.08–0.15 per run** based on 3 measured runs (token costs at claude-sonnet-4-5 pricing: ~$3/MTok input, ~$15/MTok output).

| Metric | Run A (19 steps) | Run B (30 steps) | Run C (16 steps) |
|--------|-----------------|-----------------|-----------------|
| Total wall time | 68.3 s | 143.1 s | 72.7 s |
| LLM call steps | 7 | 13 | 8 |
| Tool call steps | 12 | 17 | 8 |
| Cumulative LLM time | 31.2 s | 97.0 s | 37.9 s |
| Est. cost (input+output tokens) | ~$0.08 | ~$0.15 | ~$0.09 |

### AgentStep Schema (explicit field list)

Every LLM call and tool call is captured as an `AgentStep` row **before** execution (status=`RUNNING`) and **updated after** (status=`COMPLETED`/`FAILED`):

| Field | Type | Populated by |
|-------|------|--------------|
| `id` | UUID PK | DB default (`gen_random_uuid()`) |
| `tenant_id` | UUID FK | Copied from `AgentRun` |
| `run_id` | UUID FK | Parent `AgentRun` |
| `step_number` | INTEGER | Monotonically incrementing counter per run |
| `step_type` | VARCHAR | `'llm_call'` or `'tool_call'` or `'human_gate'` |
| `tool_name` | VARCHAR\|NULL | Tool name for `tool_call` steps; NULL for LLM steps |
| `reasoning` | TEXT\|NULL | Claude's text block preceding the tool call |
| `input_payload` | JSONB | Tool arguments or `{model, messages_count, tools_available}` |
| `output_payload` | JSONB | Tool result data or LLM response with `{stop_reason, usage:{input_tokens, output_tokens}, blocks:[...]}` |
| `status` | VARCHAR | `pending → running → completed \| failed` |
| `error_message` | VARCHAR\|NULL | Set on `failed` status |
| `duration_ms` | INTEGER\|NULL | Wall-clock time for this step |
| `started_at` | TIMESTAMPTZ | Set at step creation |
| `completed_at` | TIMESTAMPTZ\|NULL | Set on completion/failure |
| `created_at` | TIMESTAMPTZ | DB default (`now()`) |

### Failure Handling — Exact Retry Logic

```
Tool raises ToolError(retriable=True)
  └── orchestrator: append {"type":"tool_result","is_error":true,"content": err_msg}
                    to messages list
  └── loop continues — Claude sees the error and decides:
        • retry with different parameters
        • call a different tool
        • call complete_workflow with partial results

Tool raises ToolError(retriable=False)
  └── orchestrator: mark AgentRun.status = FAILED
                    set AgentRun.error_message = f"{tool.name}: {exc}"
                    set AgentRun.completed_at = now()
  └── return immediately (no retry)

Max 50 iterations exceeded
  └── orchestrator: mark FAILED with "Exceeded maximum step limit (50)."

anthropic.APIError on messages.create()
  └── orchestrator: fail the current llm_call AgentStep
                    mark AgentRun FAILED
                    raise OrchestratorError (propagates to ARQ worker)

Worker-level crash (uncaught exception)
  └── ARQ marks the job as failed; AgentRun remains RUNNING
      → detectable by monitoring for stale started_at + RUNNING status
```

## LLM Integration Evidence

The platform makes **real Anthropic API calls** via the official SDK. No mock, no stub. The exact call from `backbone/agents/orchestrator.py` (`Orchestrator._loop`, lines ~251–258):

```python
# backbone/agents/orchestrator.py — Orchestrator._loop()
response = await self._client.messages.create(
    model=MODEL,           # "claude-sonnet-4-5"
    max_tokens=MAX_TOKENS, # 4096
    system=system_prompt,  # Built by build_system_prompt(run) — see prompts/system.py
    tools=schemas,         # List of 14 tool JSON schemas from tool_schemas()
    messages=messages,     # Full conversation history (grows each iteration)
    metadata={"user_id": str(run.id)},  # Anthropic best-practice: trace per run
)
```

`self._client` is `anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)` — the official Anthropic async client.

**Tool-use loop**: when `response.stop_reason == "tool_use"`, the orchestrator iterates `response.content` looking for blocks with `block.type == "tool_use"`. Each such block contains `block.name` (tool name), `block.input` (args), and `block.id` (for the tool_result correlation). The tool is dispatched via `get_tool(block.name).execute(session, run_id, **block.input)`, and the result is appended as a `{"type": "tool_result", "tool_use_id": block.id, "content": ...}` message for the next Claude turn.

**Two-pass AgentStep write**: step written with `status=RUNNING` _before_ the API call; updated to `COMPLETED` or `FAILED` _after_ — even on exception. This guarantees full auditability of every LLM call and tool execution.

## Planning Prompt

Before entering the main tool-use loop, the orchestrator optionally injects a planning turn using prompts from `backbone/agents/prompts/planning.py`. The Prospect workflow uses:

```
Before using any tools, outline a concise execution plan for the prospect workflow:

1. ICP loading — identify which ICP criteria matter most.
2. Discovery — how many accounts to evaluate and your minimum fit threshold.
3. Enrichment — which contacts to prioritise for email verification.
4. Signals — which signal types are most relevant given the ICP's weights.
5. Hypothesis — what evidence you need before generating a hypothesis.
6. Outreach — confirm you will request_human_review before completing.

Keep the plan to 6–8 bullet points. Do not call any tools yet.
```

This planning turn is optional — the main workflow doesn't require it because the stage order is deterministic. Custom workflows with branching logic (ABM vs. PLG) can inject planning prompts before the main tool-use loop via `build_planning_message(workflow_type)`.

## Actual System Prompt

```
You are an autonomous GTM (Go-To-Market) agent for an AI-native sales platform.

Your job is to execute the assigned workflow step-by-step using the available tools.
Think carefully before each tool call. Use the minimum number of tool calls needed.

Guidelines:
- Always call complete_workflow when you have finished all objectives.
- Call request_human_review before sending any outreach or making irreversible changes.
- If a tool returns an error, diagnose the cause before retrying. Do not retry the
  same call with identical parameters more than twice.
- If you cannot make progress after reasonable attempts, call complete_workflow with
  a summary of what was accomplished and what blocked further progress.
- Prefer precision over speed: enrich fewer records well rather than many records poorly.
- Never fabricate data. If enrichment fails, record the failure and move on.
- Cite specific signals and account attributes when generating hypotheses.
```

The orchestrator prepends workflow-specific context to this base prompt at run time:

```
Workflow: prospect
ICP ID: <uuid>
Input payload: {"target_accounts": 3, "enrich_contacts": true}

Begin by loading the ICP to understand the target profile, then proceed
through discovery, enrichment, scoring, hypothesis generation, and outreach.
```

## Orchestration Flow

```
┌─────────────────────────────────────────────┐
│  1. Load & validate AgentRun                │
│     status must be QUEUED                   │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│  2. Mark RUNNING, stamp started_at          │
└──────────────────┬──────────────────────────┘
                   │
          ┌────────▼────────┐
          │  Loop (≤50 iter) │
          └────────┬────────┘
                   │
┌──────────────────▼──────────────────────────┐
│  3. Write llm_call AgentStep (RUNNING)      │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│  4. Call Claude claude-sonnet-4-5 (all tools│
│     in schema; conversation history)        │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│  5. Update llm_call step COMPLETED          │
│     (tokens, cost, duration stored)         │
└──────────────────┬──────────────────────────┘
                   │
           stop_reason?
          ┌────────┴────────┐
     end_turn           tool_use
          │                 │
   ┌──────▼──────┐   ┌──────▼──────────────────────────┐
   │ Mark COMPLETED│  │ For each tool_use block:        │
   │ Return        │  │  a. Write tool_call step RUNNING │
   └──────────────┘  │  b. Re-stamp RLS tenant context  │
                      │  c. tool.execute(session, ...)   │
                      │  d. Update step COMPLETED/FAILED │
                      │                                  │
                      │  Signal?                         │
                      │  WorkflowComplete → COMPLETED    │
                      │  HumanGate → PENDING + Review    │
                      │  ToolError(fatal) → FAILED       │
                      │  ToolError(retriable) → continue │
                      └──────────────────────────────────┘
```

## Failure Handling

| Scenario | Behaviour |
|----------|-----------|
| Tool raises `ToolError(retriable=True)` | Error message added to Claude conversation; loop continues. Claude decides whether to retry with different params or move on. |
| Tool raises `ToolError(retriable=False)` | Run marked FAILED immediately; error persisted to `agent_runs.error_message`. |
| Max 50 iterations reached | Run marked FAILED with "max steps exceeded" error. |
| Anthropic API 429 (rate limit) | Propagates as an unhandled exception; run marked FAILED by the worker's outer exception handler. |
| Worker process crash | AgentSteps in RUNNING status are left "orphaned" — detectable by monitoring as stale steps. |
| Hunter.io 404 (no email found) | `ToolError(retriable=False)` — agent moves on; Record.enrichment_status set to `failed`. |
| Hunter.io 429 (quota exhausted) | `ToolError(retriable=True)` — rate_limit_state updated (calls_remaining=0, reset_at=next month); waterfall skips this provider. |

## Human-in-the-Loop

The `request_human_review` tool raises `HumanGateSignal` which the orchestrator catches. The run is **not** marked failed — it remains `RUNNING` with a `HumanReview` record in status `PENDING`.

Review types:
- `hypothesis_approval` — Before generating outreach, agent presents the value hypothesis for approval.
- `outreach_approval` — After drafting outreach variants, agent suspends for approval before any send.
- `enrichment_validation` — Optional gate for low-confidence enrichment results.

Humans respond via `PATCH /api/reviews/{review_id}`:
- `approved` → run resumes with the proposed output accepted
- `rejected` → run resumes with the rejection reason; agent decides next step
- `modified` → run resumes with the human's modified output

## Traceability

Every agent operation is captured as an `AgentStep` record before and after execution. Key schema fields:

| Field | Type | Contents |
|-------|------|----------|
| `step_type` | enum | `llm_call` or `tool_call` |
| `tool_name` | varchar | Tool name for `tool_call` steps; null for LLM steps |
| `step_number` | int | 1-based ordering within the run |
| `status` | enum | `PENDING → RUNNING → COMPLETED \| FAILED` |
| `input_payload` | JSONB | Tool arguments or LLM call parameters |
| `output_payload` | JSONB | Tool result data or LLM response (includes token counts for `llm_call` steps) |
| `reasoning` | text | LLM's natural-language explanation of why this tool was chosen |
| `duration_ms` | int | Wall-clock milliseconds for the step |
| `error_message` | varchar | Populated on FAILED status |

A step stuck in `RUNNING` status indicates a process death between the pre- and post-execution writes — detectable by monitoring for stale `started_at` timestamps.

## Cost and Latency Measurements

The following data is read from the last three completed `AgentRun` records in the live database:

| Metric | Run A (19 steps) | Run B (30 steps) | Run C (16 steps) |
|--------|-----------------|-----------------|-----------------|
| Total wall time | 68.3 s | 143.1 s | 72.7 s |
| LLM call steps | 7 | 13 | 8 |
| Tool call steps | 12 | 17 | 8 |
| Cumulative LLM time | 31.2 s | 97.0 s | 37.9 s |
| Failure reason | Hunter 404 (no email) | Hunter 404 (no email) | Hunter 404 (no email) |

Note: all three runs failed before the `enrich_contact` soft-result fix (commit: changed non-retriable `ToolError` to return a soft `ToolResult` with `not_found=True`). After the fix, the workflow continues to outreach drafting even when Hunter.io finds no email.

The LLM fraction of total wall time ranges from 46% (Run A) to 68% (Run B), with the remainder in tool execution and PostgreSQL round-trips. Each LLM call duration is recorded in `agent_steps.duration_ms`. Token usage (input + output) is stored in `agent_steps.output_payload` for every `llm_call` step, enabling per-run cost attribution.

Full execution traces with step-level timing are in `/traces/`.
