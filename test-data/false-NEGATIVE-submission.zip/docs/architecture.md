# GTM Platform — Architecture

## System Overview

The GTM Platform is an AI-native Go-To-Market system that automates prospect discovery, enrichment, scoring, and personalised outreach generation. A Claude-powered autonomous agent executes a 6-stage Prospect workflow on behalf of each tenant, calling tools to read and write CRM data, score accounts against an Ideal Customer Profile, enrich contacts via external APIs, and draft outreach copy — pausing for human approval before irreversible actions.

```
┌─────────────────────────────────────────────────────────────────┐
│                          Browser / Client                        │
└───────────────────────────┬─────────────────────────────────────┘
                             │  HTTPS (same-origin via Next.js proxy)
┌───────────────────────────▼─────────────────────────────────────┐
│                         Frontend (Next.js 14)                    │
│  App Router · TypeScript · Tailwind CSS · Radix UI primitives   │
└───────────────────────────┬─────────────────────────────────────┘
                             │  HTTP (internal Docker network)
┌───────────────────────────▼─────────────────────────────────────┐
│                   Backend (FastAPI / Python 3.12)                │
│  JWT auth · RLS deps · REST API · Envelope middleware            │
└──────────┬───────────────────────────────┬──────────────────────┘
           │ SQLAlchemy 2.0 async           │ ARQ job enqueue
┌──────────▼──────────────┐   ┌────────────▼─────────────────────┐
│   PostgreSQL 16          │   │         Redis 7                   │
│   RLS-enforced           │   │   Job queue + result cache        │
│   pgcrypto · uuid-ossp   │   └────────────┬─────────────────────┘
└──────────▲──────────────┘                │ ARQ job dequeue
           │ SQLAlchemy 2.0 async          │
┌──────────┴──────────────────────────────▼─────────────────────┐
│                      Worker (ARQ / Python 3.12)                 │
│   Orchestrator · Tool registry · Integration waterfall          │
│                              │                                  │
│                    Anthropic API (Claude claude-sonnet-4-5)     │
│                    Hunter.io API                                 │
└────────────────────────────────────────────────────────────────┘
```

## Service Boundaries

| Service | Image / Process | Responsibility |
|---------|----------------|----------------|
| `postgres` | `postgres:16-alpine` | Persistent data store; auto-RLS via DDL trigger |
| `redis` | `redis:7-alpine` | ARQ job queue and result storage |
| `db-init` | Backend image, one-shot | Alembic migrations + idempotent seed |
| `backend` | Uvicorn + FastAPI | REST API, auth, enqueue agent runs |
| `worker` | ARQ worker | Async agent execution, tool dispatch |
| `frontend` | Next.js 14 | UI, proxies `/api/*` to backend |

## Data Model

### Tenants and Multi-Tenancy

Every table that holds tenant data carries a non-nullable `tenant_id UUID` column. PostgreSQL Row-Level Security (RLS) is applied automatically by an event trigger (`gtm_auto_tenant_rls_trigger`) at `CREATE TABLE` time. The trigger:

1. Enables RLS and FORCE ROW LEVEL SECURITY on the table.
2. Creates a single permissive policy:
   ```sql
   USING     (tenant_id = current_tenant_id())
   WITH CHECK (tenant_id = current_tenant_id())
   ```

`current_tenant_id()` reads `app.current_tenant` from the PostgreSQL session. Application code sets this via `set_config('app.current_tenant', :tid, TRUE)` (transaction-scoped) before every query. No `WHERE tenant_id = ?` clause exists anywhere in application code.

### Core Tables

```
tenants                   — Root organisation; no tenant_id column; no RLS
  └── object_definitions  — Schema definitions for CRM object types (Account, Contact)
  └── records             — Universal CRM record (attributes JSONB)
        └── signals       — Intelligence signals (funding, hiring, intent, …)
        └── record_relationships — Typed edges between records
  └── icps                — Ideal Customer Profile (firmographic + tech + persona criteria)
  └── agent_runs          — Single workflow execution instance
        └── agent_steps   — Atomic step within a run (LLM call or tool call)
        └── human_reviews — Pending human approval gates
  └── integration_connections — Encrypted provider credentials
  └── activities          — Immutable audit trail
```

### Key Schema Decisions

| Decision | Rationale |
|----------|-----------|
| UUID primary keys everywhere | Avoids sequential ID leakage between tenants; safe for distributed generation |
| `attributes JSONB` on Record | Schema-flexible CRM fields without migrations per new field type |
| `enrichment_status` as CHECK-constrained VARCHAR | Avoids PostgreSQL native ENUM migration pain; `values_callable` ensures lowercase storage |
| `credentials TEXT` (Fernet-encrypted) | API keys never stored in plain text; decrypted in-process only |
| `rate_limit_state JSONB` on IntegrationConnection | Per-provider quota tracking without a separate table |

## Entity Mapping

In this platform, Accounts, Contacts, and Opportunities are **not** separate database tables — they are `Record` instances with different `ObjectDefinition` types. This is the Attio-inspired flexible schema pattern that allows adding new entity types without migrations. The seed data creates `ObjectDefinition` rows for:

| ObjectDefinition slug | Equivalent CRM concept |
|-----------------------|------------------------|
| `account`             | Company / Account       |
| `contact`             | Person / Contact        |
| `opportunity`         | Deal / Opportunity      |
| `lead`                | Inbound lead            |

All records are stored in the single `records` table and queryable by `object_type` (i.e. by joining to their `ObjectDefinition`). The `attributes` JSONB column holds all entity-specific fields (e.g. `company_name`, `employee_count` for accounts; `first_name`, `email` for contacts).

```
ObjectDefinition(slug="account")  ──┐
ObjectDefinition(slug="contact")  ──┤
ObjectDefinition(slug="opportunity")┤
ObjectDefinition(slug="lead")     ──┘
           All stored in: object_definitions table

Record(object_definition_id → "account", attributes={"company_name": "Stripe", ...})
Record(object_definition_id → "contact", attributes={"first_name": "Sarah", ...})
Record(object_definition_id → "opportunity", attributes={"amount": 50000, ...})
           All stored in: records table (shared schema)

RecordRelationship(from=contact_id, to=account_id, type="works_at")
           Typed edges between any two Records
```

To add a new entity type (e.g. `partner`), call `POST /api/object-definitions` with a JSON schema — **no code or migration change required**.

## Multi-Tenancy

The three-layer isolation stack:

1. **Network**: Frontend proxies all requests through the same origin; tenants never reach the backend directly.
2. **Auth**: JWT carries `tenant_id` as the `sub` claim. `get_tenant_session` FastAPI dependency decodes the token and calls `set_tenant_context` before every handler.
3. **Database**: PostgreSQL RLS enforces isolation at the storage layer. Even a SQL injection that bypassed the ORM would be blocked by RLS — the session variable `app.current_tenant` controls what each connection can see.

**Worker special case**: The ARQ worker commits many times per run (one per orchestration loop iteration). Each commit ends the transaction and clears `is_local=TRUE` settings. The worker therefore calls `set_tenant_context(session, tenant_id, is_local=False)` once at job start (connection-level, survives commits) and re-stamps it inside `_dispatch()` before every tool call (defence-in-depth).

**Test isolation note**: The `gtm` database user is a superuser with `Bypass RLS`, so RLS policies are ignored for that role even with `FORCE ROW LEVEL SECURITY`. The integration tests in `tests/test_rls.py` create a dedicated non-superuser role `gtm_rls_tester` and issue `SET ROLE gtm_rls_tester` before each test connection. This validates that the RLS policy actually filters rows under the same conditions as a real application user (which should also connect as a non-superuser role in production).

## Agent Orchestration

```
API POST /api/runs
    │
    ├── create AgentRun (status=QUEUED)
    └── enqueue ARQ job(run_id, tenant_id)

ARQ Worker: run_prospect_workflow(run_id, tenant_id)
    │
    ├── set RLS context (is_local=False)
    └── Orchestrator.run(run_id, session)
          │
          ├── load AgentRun, validate QUEUED
          ├── mark RUNNING, stamp started_at
          │
          └── loop (max 50 iterations):
                │
                ├── write AgentStep(llm_call, RUNNING)
                ├── call Claude claude-sonnet-4-5 (tools=[all 14])
                ├── update AgentStep(llm_call, COMPLETED, tokens, duration)
                │
                ├── stop_reason == "end_turn"
                │     └── mark run COMPLETED, return
                │
                └── stop_reason == "tool_use" — for each tool block:
                      ├── write AgentStep(tool_call, RUNNING, input)
                      ├── re-stamp RLS context
                      ├── tool.execute(session, run_id, **input)
                      ├── update AgentStep(tool_call, COMPLETED/FAILED, output)
                      │
                      ├── WorkflowCompleteSignal → mark COMPLETED
                      ├── HumanGateSignal → create HumanReview, return (suspended)
                      ├── ToolError(fatal) → mark FAILED
                      └── ToolError(retriable) → add error to messages, continue
```

Every AgentStep is written **before** the operation executes and **updated after** — even on crash. A step stuck in `RUNNING` status indicates a process death between the two writes, detectable by monitoring.

## Integration Framework

The waterfall resolver (`backbone/integrations/waterfall.py`) decouples tools from specific providers:

```
tool calls:  waterfall.resolve("find_email", session, first_name=..., domain=...)
                │
                ├── load active IntegrationConnections for tenant (RLS-scoped)
                ├── skip connections whose slug is not in _REGISTRY
                ├── skip rate-limited connections (calls_remaining ≤ 0 and reset_at in future)
                └── for each eligible connection:
                      provider.find_email(...)
                      ├── success → return ToolResult
                      ├── ToolError(retriable=False) → propagate immediately
                      └── ToolError(retriable=True) → try next provider
```

New providers register with `@register_provider` class decorator and implement the `BaseIntegration` abstract methods they support. The waterfall falls through to the next provider automatically.

## Extension Points

| Extension | How to add it |
|-----------|---------------|
| New CRM object type | POST `/api/object-definitions` with a JSON schema; no code change |
| New integration provider | Create `backbone/integrations/providers/<slug>.py`, subclass `BaseIntegration`, decorate with `@register_provider` |
| New agent tool | Create `backbone/agents/tools/<name>.py`, subclass `AgentTool`, register in `prospect_tools.py` |
| New workflow type | Create `backbone/workers/` handler, add ARQ job function, route from `/api/runs` |

## What Comes Next

**Engage** — CRM-connected email sequencing. The agent's `generate_outreach` tool already drafts the copy and suspends for human approval. The next step is an `EngageWorkflow` that, once approved, calls a SendGrid/Gmail integration to dispatch the sequence and records activities.

**Manage** — Deal pipeline and opportunity tracking. Relationships between contacts, accounts, and opportunities already exist via `RecordRelationship`. The Manage layer adds pipeline stage transitions, forecast rollups, and automated follow-up scheduling.

**Operate** — Analytics and revenue intelligence. The signal scoring infrastructure (intent scores, fit scores, funding events) is the foundation for a revenue dashboard showing pipeline health, ICP coverage, and which signals correlate with closed deals.

## Trade-offs

| Trade-off | Decision | Consequence |
|-----------|----------|-------------|
| Superuser DB role | `gtm` is a PostgreSQL superuser with `Bypass RLS` | Needed for migrations/DDL; mitigated in app by always setting `app.current_tenant`; mitigated in tests by `SET ROLE gtm_rls_tester` (a non-superuser role created during test setup) |
| JSONB attributes | Schema-free CRM fields | No column-level indexing without explicit GIN; field validation is app-layer only |
| Single agent model | No agent pool, no parallel runs per tenant | Simpler; one run at a time per tenant; easy to add parallelism via ARQ concurrency settings |
| Fernet encryption | Symmetric key for credentials | Key rotation requires re-encrypting all credentials; key loss = data loss |
| ARQ over Celery | Simpler Redis-based queue | Less mature ecosystem; fewer monitoring integrations |
