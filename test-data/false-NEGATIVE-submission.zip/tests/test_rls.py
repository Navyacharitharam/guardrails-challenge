"""Multi-tenancy RLS isolation — asyncpg direct, no ORM, no FastAPI client.

Each test runs its asyncpg logic in a dedicated thread via run_async().
This isolates the asyncpg event loop from pytest-asyncio's session loop,
which avoids the "event loop already running" conflict on Windows.

Skipped automatically when PostgreSQL is not reachable.
"""
import asyncio
import concurrent.futures
import os
import socket
import sys
import uuid

import asyncpg
import pytest

# ── DB URL ────────────────────────────────────────────────────────────────────
_DB_URL: str = (
    os.environ.get("DATABASE_URL", "postgresql://gtm:gtm_secret@localhost:5432/gtm")
    .replace("postgresql+asyncpg://", "postgresql://")
    .rsplit("/", 1)[0]
    + "/gtm_test"
)

_HOST: str = _DB_URL.split("@")[-1].split(":")[0]
_PORT: int = int(_DB_URL.split("@")[-1].split(":")[1].split("/")[0])


def _db_reachable() -> bool:
    """TCP-level check — no event loop needed at import time."""
    try:
        socket.create_connection((_HOST, _PORT), timeout=1).close()
        return True
    except OSError:
        return False


_DB_AVAILABLE: bool = _db_reachable()
pytestmark = pytest.mark.skipif(not _DB_AVAILABLE, reason="PostgreSQL unavailable")


# ── Thread-based async runner ─────────────────────────────────────────────────


def _run(coro) -> None:
    """Execute a coroutine on a fresh SelectorEventLoop in a background thread.

    Each thread on Windows inherits ProactorEventLoop by default, which
    asyncpg does not support. Setting the policy per-thread before creating
    the loop ensures asyncpg's TCP connections work correctly.
    """
    def _thread_main():
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        return asyncio.run(coro)

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(_thread_main)
        future.result(timeout=30)


# ── Async helpers (called via _run) ───────────────────────────────────────────


async def _connect(tenant_id: str) -> asyncpg.Connection:
    """Connect as a non-superuser role so RLS policies are enforced."""
    conn = await asyncpg.connect(_DB_URL)
    # Switch to non-superuser role so RLS applies (gtm is a superuser/bypassrls)
    await conn.execute("SET ROLE gtm_rls_tester")
    await conn.execute(
        "SELECT set_config('app.current_tenant', $1, FALSE)", tenant_id
    )
    return conn


async def _setup() -> None:
    conn = await asyncpg.connect(_DB_URL, timeout=5)
    # Create a non-superuser role for RLS testing if it doesn't exist
    await conn.execute("""
        DO $$ BEGIN
            IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'gtm_rls_tester') THEN
                CREATE ROLE gtm_rls_tester LOGIN PASSWORD 'gtm_rls_tester';
            END IF;
        END $$
    """)
    await conn.execute("""
        CREATE OR REPLACE FUNCTION current_tenant_id()
        RETURNS UUID LANGUAGE plpgsql STABLE AS $fn$
        BEGIN
            RETURN NULLIF(current_setting('app.current_tenant', TRUE), '')::UUID;
        EXCEPTION WHEN invalid_text_representation THEN
            RETURN NULL;
        END;
        $fn$
    """)
    await conn.execute("DROP TABLE IF EXISTS _rls_test CASCADE")
    await conn.execute("""
        CREATE TABLE _rls_test (
            id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            tenant_id UUID NOT NULL,
            data      TEXT
        )
    """)
    await conn.execute("ALTER TABLE _rls_test ENABLE ROW LEVEL SECURITY")
    await conn.execute("ALTER TABLE _rls_test FORCE ROW LEVEL SECURITY")
    await conn.execute("""
        CREATE POLICY tenant_isolation ON _rls_test
        USING     (tenant_id = current_tenant_id())
        WITH CHECK (tenant_id = current_tenant_id())
    """)
    # Grant the tester role access to the table
    await conn.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON _rls_test TO gtm_rls_tester")
    await conn.close()


async def _teardown() -> None:
    conn = await asyncpg.connect(_DB_URL)
    await conn.execute("DROP TABLE IF EXISTS _rls_test CASCADE")
    await conn.close()


# ── Session-scoped table setup ────────────────────────────────────────────────


@pytest.fixture(scope="session", autouse=True)
def _rls_table():
    """Create the test table with RLS once; drop it after the session."""
    if not _DB_AVAILABLE:
        yield
        return
    try:
        _run(_setup())
    except Exception as exc:
        pytest.skip(f"Cannot set up test DB: {exc}")
        return
    yield
    try:
        _run(_teardown())
    except Exception:
        pass


# ── Tests ─────────────────────────────────────────────────────────────────────


def test_tenant_b_cannot_see_tenant_a_record():
    """Row inserted as tenant A is invisible when queried as tenant B."""
    async def _body() -> None:
        tid_a = str(uuid.uuid4())
        tid_b = str(uuid.uuid4())
        rec_id = str(uuid.uuid4())

        conn_a = await _connect(tid_a)
        await conn_a.execute(
            "INSERT INTO _rls_test (id, tenant_id, data)"
            " VALUES ($1::uuid, $2::uuid, $3)",
            rec_id, tid_a, "tenant A secret",
        )
        await conn_a.close()

        conn_b = await _connect(tid_b)
        rows = await conn_b.fetch(
            "SELECT * FROM _rls_test WHERE id = $1::uuid", rec_id
        )
        await conn_b.close()

        assert len(rows) == 0, "Tenant B must not see Tenant A's record"

    _run(_body())


def test_tenant_a_sees_own_record():
    """Row inserted as tenant A is visible when queried as tenant A."""
    async def _body() -> None:
        tid_a = str(uuid.uuid4())
        rec_id = str(uuid.uuid4())

        conn = await _connect(tid_a)
        await conn.execute(
            "INSERT INTO _rls_test (id, tenant_id, data)"
            " VALUES ($1::uuid, $2::uuid, $3)",
            rec_id, tid_a, "my own data",
        )
        await conn.close()

        conn2 = await _connect(tid_a)
        rows = await conn2.fetch(
            "SELECT * FROM _rls_test WHERE id = $1::uuid", rec_id
        )
        await conn2.close()

        assert len(rows) == 1, "Tenant A must see its own record"
        assert rows[0]["data"] == "my own data"

    _run(_body())


def test_select_all_returns_only_own_rows():
    """SELECT * returns only the querying tenant's rows, never the other's."""
    async def _body() -> None:
        tid_a = str(uuid.uuid4())
        tid_b = str(uuid.uuid4())
        marker = str(uuid.uuid4())  # unique per run to avoid cross-test pollution

        for tid, label in [(tid_a, f"A-{marker}"), (tid_b, f"B-{marker}")]:
            conn = await _connect(tid)
            await conn.execute(
                "INSERT INTO _rls_test (tenant_id, data) VALUES ($1::uuid, $2)",
                tid, label,
            )
            await conn.close()

        conn_a = await _connect(tid_a)
        rows_a = await conn_a.fetch(
            "SELECT * FROM _rls_test WHERE data LIKE $1", f"%-{marker}"
        )
        await conn_a.close()

        conn_b = await _connect(tid_b)
        rows_b = await conn_b.fetch(
            "SELECT * FROM _rls_test WHERE data LIKE $1", f"%-{marker}"
        )
        await conn_b.close()

        assert len(rows_a) == 1 and rows_a[0]["data"] == f"A-{marker}", (
            "Tenant A must see exactly its own row"
        )
        assert len(rows_b) == 1 and rows_b[0]["data"] == f"B-{marker}", (
            "Tenant B must see exactly its own row"
        )

    _run(_body())
