"""Smoke test for the /health endpoint.

Uses FastAPI's synchronous TestClient — no Docker, no database required.
"""
from fastapi.testclient import TestClient

from backbone.api.app import app

client = TestClient(app)


def test_health_returns_200():
    response = client.get("/health")
    assert response.status_code == 200


def test_health_body_contains_status_ok():
    response = client.get("/health")
    # EnvelopeMiddleware wraps the response: {"data": {...}, "meta": {...}}
    body = response.json()
    assert body["data"]["status"] == "ok"


def test_health_body_contains_version():
    response = client.get("/health")
    assert "version" in response.json()["data"]
