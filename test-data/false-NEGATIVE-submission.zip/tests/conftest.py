"""Minimal pytest configuration.

Forces SelectorEventLoop on Windows so asyncpg (used in test_rls.py)
can open TCP connections. ProactorEventLoop (the Windows default for
Python 3.8+) is incompatible with asyncpg's socket handling.
"""
import asyncio
import sys

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
