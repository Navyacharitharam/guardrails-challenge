"""Unit tests for agent tool primitives and the tool registry.

No database, no async, no Docker required.
"""
import pytest

from backbone.integrations.base import ToolError, ToolResult


# ── ToolResult ────────────────────────────────────────────────────────────────


def test_tool_result_stores_data_and_provider():
    result = ToolResult(data={"email": "alice@example.com", "score": 94}, provider_slug="hunter")
    assert result.data["email"] == "alice@example.com"
    assert result.data["score"] == 94
    assert result.provider_slug == "hunter"


def test_tool_result_meta_defaults_to_empty_dict():
    result = ToolResult(data={}, provider_slug="none")
    assert result.meta == {}


def test_tool_result_accepts_explicit_meta():
    result = ToolResult(data={}, provider_slug="hunter", meta={"calls_remaining": 22})
    assert result.meta["calls_remaining"] == 22


# ── ToolError ─────────────────────────────────────────────────────────────────


def test_tool_error_retriable_true_by_default():
    err = ToolError("network timeout")
    assert err.retriable is True
    assert str(err) == "network timeout"


def test_tool_error_retriable_false_for_fatal():
    err = ToolError("email not found", retriable=False)
    assert err.retriable is False


def test_tool_error_is_an_exception():
    with pytest.raises(ToolError, match="boom"):
        raise ToolError("boom", retriable=True)


def test_tool_error_retriable_flag_distinguishes_cases():
    transient = ToolError("rate limited", retriable=True)
    fatal = ToolError("invalid api key", retriable=False)
    assert transient.retriable is not fatal.retriable


# ── Tool registry ─────────────────────────────────────────────────────────────

# Import triggers registration of all 14 tools.
import backbone.agents.tools  # noqa: E402
from backbone.agents.tools import all_tools, get_tool  # noqa: E402

_EXPECTED_TOOLS = {
    "complete_workflow",
    "request_human_review",
    "load_icp",
    "score_company_fit",
    "discover_companies",
    "upsert_record",
    "create_relationship",
    "create_activity",
    "verify_email",
    "enrich_contact",
    "get_signals",
    "compute_intent_score",
    "generate_hypothesis",
    "generate_outreach",
}


def test_registry_contains_all_expected_tools():
    registered = {t.name for t in all_tools()}
    missing = _EXPECTED_TOOLS - registered
    assert not missing, f"Tools missing from registry: {missing}"


def test_get_tool_returns_correct_instance():
    tool = get_tool("enrich_contact")
    assert tool is not None
    assert tool.name == "enrich_contact"


def test_get_tool_returns_none_for_unknown():
    assert get_tool("no_such_tool") is None


def test_every_tool_has_input_schema():
    for tool in all_tools():
        schema = tool.input_schema
        assert isinstance(schema, dict), f"{tool.name}.input_schema must be a dict"
        assert schema.get("type") == "object", (
            f"{tool.name}.input_schema must have type=object"
        )
