"""Prospect workflow — programmatic 6-stage pipeline.

``ProspectWorkflow.execute`` chains all six stages in order and returns a
summary dict.  This is the deterministic, non-LLM entry point used for
integration testing and direct worker invocation.

The LLM-driven path (Orchestrator) uses the same underlying agent tools
but lets Claude decide the call sequence.  Both paths write AgentStep records
and honour CLAUDE.md rule #4.

Stage ordering
--------------
  1. ICP Loading         — load ICP from DB
  2. Account Discovery   — score all accounts, return top N by fit_score
  3. Contact Enrichment  — Hunter.io waterfall for top 3 accounts
  4. Signal Analysis     — load signals, compute intent_score per account
  5. Hypothesis Gen      — Claude tool_use → structured pain_point hypothesis
  6. Outreach Drafting   — 2 variants via Claude + HumanReview (pending)
"""
import uuid
from typing import Any

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.models.agent_run import AgentRun
from backbone.models.relationship import RecordRelationship
from prospect.workflows.stages import StageError
from prospect.workflows.stages import (
    stage_1_icp,
    stage_2_discovery,
    stage_3_enrichment,
    stage_4_signals,
    stage_5_hypothesis,
    stage_6_outreach,
)

log = structlog.get_logger(__name__)

WORKFLOW_TYPE = "prospect"

SYSTEM_PROMPT_STAGES = """
Execute the prospect workflow in 6 stages:

STAGE 1 — ICP: Call load_icp to retrieve the ICP criteria.
STAGE 2 — Discovery: Call discover_companies to find the top accounts ranked by ICP fit.
STAGE 3 — Enrichment: For each top account (up to 3), call verify_email for the primary contact.
STAGE 4 — Signals: Call get_signals then compute_intent_score for each account.
STAGE 5 — Hypothesis: Call generate_hypothesis for the top account, then request_human_review.
STAGE 6 — Outreach: Call generate_outreach for the primary contact, then request_human_review.

Complete with complete_workflow after all stages are done.
""".strip()


async def _get_primary_contact(session: AsyncSession, account_id: uuid.UUID) -> uuid.UUID | None:
    """Return the UUID of the first contact linked to an account, or None."""
    rel_res = await session.execute(
        select(RecordRelationship).where(
            RecordRelationship.to_record_id == account_id,
            RecordRelationship.relationship_type == "works_at",
        ).limit(1)
    )
    rel = rel_res.scalar_one_or_none()
    return rel.from_record_id if rel else None


class ProspectWorkflow:
    """Deterministic 6-stage prospect pipeline.

    Runs all stages in sequence, passing typed result objects between them.
    External calls (Hunter.io, Claude) are isolated to Stage 3 and Stages 5-6
    respectively, making each stage independently mockable in tests.
    """

    async def execute(self, session: AsyncSession, run: AgentRun) -> dict[str, Any]:
        """Execute all 6 stages and return a workflow summary.

        The run must be in RUNNING status before calling this method.  Status
        transitions (RUNNING → COMPLETED/FAILED) are the caller's responsibility.

        Args:
            session: Async session with tenant RLS context set.
            run: The AgentRun to execute.

        Returns:
            A summary dict with top-account info, intent scores, and review IDs.

        Raises:
            StageError: Propagated from any stage on unrecoverable failure.
        """
        log.info("prospect_workflow.start", run_id=str(run.id))

        # Stage 1 — ICP
        r1 = await stage_1_icp.run(session, run)

        # Stage 2 — Discovery
        r2 = await stage_2_discovery.run(session, run, icp=r1.icp)

        if not r2.accounts:
            log.warning("prospect_workflow.no_accounts", run_id=str(run.id))
            return {
                "status": "no_accounts_found",
                "icp_id": str(run.icp_id),
                "total_evaluated": r2.total_evaluated,
            }

        # Stage 3 — Enrichment
        r3 = await stage_3_enrichment.run(session, run, accounts=r2.accounts)

        # Stage 4 — Signals
        r4 = await stage_4_signals.run(session, run, accounts=r2.accounts, icp=r1.icp)

        # Stage 5 — Hypothesis (top account only)
        top = r2.accounts[0]
        top_signals = r4.signal_map.get(top.record_id, [])
        r5 = await stage_5_hypothesis.run(
            session, run, account=top, icp=r1.icp, signals=top_signals
        )

        # Stage 6 — Outreach (primary contact of top account)
        contact_id = await _get_primary_contact(session, top.record_id)
        if contact_id is None:
            log.warning(
                "prospect_workflow.no_contact",
                run_id=str(run.id),
                account_id=str(top.record_id),
            )
            return {
                "status": "no_contact_for_outreach",
                "top_account_id": str(top.record_id),
                "hypothesis": r5.hypothesis,
            }

        r6 = await stage_6_outreach.run(
            session,
            run,
            account=top,
            contact_record_id=contact_id,
            hypothesis=r5.hypothesis,
        )

        log.info(
            "prospect_workflow.complete",
            run_id=str(run.id),
            top_account=str(top.record_id),
            review_id=str(r6.review_id),
        )

        return {
            "status": "pending_human_review",
            "top_account_id": str(top.record_id),
            "top_account_name": top.company_name,
            "fit_score": top.fit_score,
            "intent_score": r4.intent_scores.get(top.record_id, 0.0),
            "enriched_contacts": r3.enriched_count,
            "hypothesis": r5.hypothesis,
            "outreach_variants": len(r6.variants),
            "review_id": str(r6.review_id),
        }
