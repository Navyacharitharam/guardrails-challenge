"""Stage 1 — ICP Loading.

Loads the ICP entity referenced by the AgentRun and returns it for use by
downstream stages.  Writes a single TOOL_CALL AgentStep with before/after
tracing per CLAUDE.md rule #4.
"""
import time
import uuid
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

import structlog
from backbone.agents.tracing import complete_step, fail_step, next_step_number, write_step
from backbone.models.agent_run import AgentRun
from backbone.models.enums import AgentStepType
from backbone.models.icp import ICP
from prospect.workflows.stages import StageError

log = structlog.get_logger(__name__)


@dataclass
class Stage1Result:
    """Result returned by Stage 1."""

    icp: ICP


async def run(session: AsyncSession, run: AgentRun) -> Stage1Result:
    """Load the ICP for the run.

    Args:
        session: Async session with tenant RLS context set.
        run: The AgentRun being executed; must have ``icp_id`` set.

    Returns:
        :class:`Stage1Result` containing the loaded ICP.

    Raises:
        StageError: If ``run.icp_id`` is None or the ICP does not exist.
    """
    if run.icp_id is None:
        raise StageError("AgentRun has no icp_id — cannot execute prospect workflow.")

    step_number = await next_step_number(session, run.id)
    t0 = time.monotonic()

    step = await write_step(
        session,
        run=run,
        step_number=step_number,
        step_type=AgentStepType.TOOL_CALL,
        tool_name="load_icp",
        input_payload={"icp_id": str(run.icp_id)},
    )
    await session.commit()

    result = await session.execute(select(ICP).where(ICP.id == run.icp_id))
    icp = result.scalar_one_or_none()
    duration_ms = int((time.monotonic() - t0) * 1000)

    if icp is None:
        await fail_step(session, step, f"ICP {run.icp_id} not found.", duration_ms)
        await session.commit()
        raise StageError(f"ICP {run.icp_id} not found.")

    await complete_step(
        session,
        step,
        output_payload={
            "icp_id": str(icp.id),
            "name": icp.name,
            "is_active": icp.is_active,  # nosemgrep: python.lang.maintainability.is-function-without-parentheses.is-function-without-parentheses
        },
        duration_ms=duration_ms,
    )
    await session.commit()

    log.info("stage_1.complete", run_id=str(run.id), icp_id=str(icp.id))
    return Stage1Result(icp=icp)
