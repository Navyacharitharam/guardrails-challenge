"""Stage 2 — Account Discovery and ICP Fit Scoring.

Loads all Account records for the tenant, scores each against the ICP using
the prospect scoring module (firmographic + technographic + persona), and
returns the top accounts sorted by fit_score descending.

Fit scores are persisted back to ``Record.fit_score`` so downstream stages
and the UI can display them without re-computing.
"""
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import structlog
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tracing import complete_step, next_step_number, write_step
from backbone.models.agent_run import AgentRun
from backbone.models.enums import AgentStepType
from backbone.models.icp import ICP
from backbone.models.object_definition import ObjectDefinition
from backbone.models.record import Record
from backbone.models.relationship import RecordRelationship
from prospect.scoring.icp_scorer import compute_fit_score

log = structlog.get_logger(__name__)

_DEFAULT_MIN_FIT_SCORE = 0.4
_DEFAULT_LIMIT = 5


@dataclass
class ScoredAccount:
    """An account record with its computed ICP fit score."""

    record_id: uuid.UUID
    fit_score: float
    company_name: str
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass
class Stage2Result:
    """Result returned by Stage 2."""

    accounts: list[ScoredAccount]
    total_evaluated: int


async def run(
    session: AsyncSession,
    run: AgentRun,
    icp: ICP,
    min_fit_score: float = _DEFAULT_MIN_FIT_SCORE,
    limit: int = _DEFAULT_LIMIT,
) -> Stage2Result:
    """Discover and score account records against the ICP.

    Args:
        session: Async session with tenant RLS context set.
        run: The AgentRun being executed.
        icp: The loaded ICP from Stage 1.
        min_fit_score: Minimum fit score threshold; accounts below this are excluded.
        limit: Maximum number of accounts to return.

    Returns:
        :class:`Stage2Result` with scored accounts sorted by fit_score descending.
    """
    step_number = await next_step_number(session, run.id)
    t0 = time.monotonic()

    step = await write_step(
        session,
        run=run,
        step_number=step_number,
        step_type=AgentStepType.TOOL_CALL,
        tool_name="discover_companies",
        input_payload={
            "icp_id": str(icp.id),
            "min_fit_score": min_fit_score,
            "limit": limit,
        },
    )
    await session.commit()

    od_res = await session.execute(
        select(ObjectDefinition).where(ObjectDefinition.slug == "account")
    )
    od = od_res.scalar_one_or_none()

    accounts_res = await session.execute(
        select(Record).where(Record.object_definition_id == od.id) if od else select(Record).where(False)
    )
    all_accounts = list(accounts_res.scalars())

    scored: list[ScoredAccount] = []
    for rec in all_accounts:
        attrs = rec.attributes or {}

        rel_res = await session.execute(
            select(RecordRelationship).where(
                RecordRelationship.to_record_id == rec.id,
                RecordRelationship.relationship_type == "works_at",
            )
        )
        contact_ids = [r.from_record_id for r in rel_res.scalars()]

        contact_attrs: list[dict[str, Any]] = []
        if contact_ids:
            c_res = await session.execute(
                select(Record).where(Record.id.in_(contact_ids))
            )
            contact_attrs = [c.attributes or {} for c in c_res.scalars()]

        fit = compute_fit_score(
            account_attributes=attrs,
            icp_firmographic=icp.firmographic_criteria or {},
            icp_technographic=icp.technographic_criteria or {},
            icp_persona=icp.persona_criteria or {},
            contact_attributes_list=contact_attrs,
        )

        await session.execute(
            update(Record).where(Record.id == rec.id).values(fit_score=fit)
        )

        if fit >= min_fit_score:
            scored.append(ScoredAccount(
                record_id=rec.id,
                fit_score=fit,
                company_name=attrs.get("company_name", "Unknown"),
                attributes=attrs,
            ))

    scored.sort(key=lambda a: a.fit_score, reverse=True)
    top = scored[:limit]

    duration_ms = int((time.monotonic() - t0) * 1000)
    await complete_step(
        session,
        step,
        output_payload={
            "total_evaluated": len(all_accounts),
            "returned": len(top),
            "accounts": [
                {"record_id": str(a.record_id), "company_name": a.company_name, "fit_score": a.fit_score}
                for a in top
            ],
        },
        duration_ms=duration_ms,
    )
    await session.commit()

    log.info(
        "stage_2.complete",
        run_id=str(run.id),
        evaluated=len(all_accounts),
        returned=len(top),
    )
    return Stage2Result(accounts=top, total_evaluated=len(all_accounts))
