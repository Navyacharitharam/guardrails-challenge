"""Prospect workflow stage definitions.

Each stage module exposes a single ``run(session, run, **kwargs)`` coroutine
that executes one phase of the prospect pipeline, writes AgentStep tracing
records, and returns a typed dataclass result.
"""


class StageError(Exception):
    """Raised when a workflow stage cannot complete and the run should be failed."""
