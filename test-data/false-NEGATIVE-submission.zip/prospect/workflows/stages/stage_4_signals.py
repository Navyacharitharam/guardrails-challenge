"""Stage 4 — Signal Loading and Intent Scoring.

For each account in the pipeline, loads all associated Signal records and
computes an intent_score using the ICP's signal_weights and the prospect
intent_scorer module (recency-decayed, weighted average).

Intent scores are persisted to ``Record.intent_score``.
"""
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import structlog
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tracing import complete_step, next_step_number, write_step
from backbone.models.agent_run import AgentRun
from backbone.models.enums import AgentStepType
from backbone.models.icp import ICP
from backbone.models.record import Record
from backbone.models.signal import Signal
from prospect.scoring.intent_scorer import compute_intent_score
from prospect.workflows.stages.stage_2_discovery import ScoredAccount

log = structlog.get_logger(__name__)


@dataclass
class Stage4Result:
    """Result returned by Stage 4."""

    signal_map: dict[uuid.UUID, list[dict[str, Any]]]
    intent_scores: dict[uuid.UUID, float]


def _signal_to_dict(sig: Signal) -> dict[str, Any]:
    """Serialise a Signal ORM object to a plain dict for the scorer."""
    return {
        "signal_id": str(sig.id),
        "signal_type": sig.signal_type.value if hasattr(sig.signal_type, "value") else str(sig.signal_type),
        "source": sig.source,
        "score": sig.score,
        "occurred_at": sig.occurred_at.isoformat() if sig.occurred_at else None,
        "payload": sig.payload or {},
    }


async def run(
    session: AsyncSession,
    run: AgentRun,
    accounts: list[ScoredAccount],
    icp: ICP,
) -> Stage4Result:
    """Load signals and compute intent scores for each account.

    Args:
        session: Async session with tenant RLS context set.
        run: The AgentRun being executed.
        accounts: Scored accounts from Stage 2.
        icp: The loaded ICP (for signal_weights).

    Returns:
        :class:`Stage4Result` mapping account IDs to signal lists and intent scores.
    """
    step_number = await next_step_number(session, run.id)
    t0 = time.monotonic()

    step = await write_step(
        session,
        run=run,
        step_number=step_number,
        step_type=AgentStepType.TOOL_CALL,
        tool_name="compute_intent_score",
        input_payload={
            "account_ids": [str(a.record_id) for a in accounts],
            "icp_id": str(icp.id),
        },
    )
    await session.commit()

    signal_weights: dict[str, float] = icp.signal_weights or {}
    now = datetime.now(timezone.utc)

    signal_map: dict[uuid.UUID, list[dict[str, Any]]] = {}
    intent_scores: dict[uuid.UUID, float] = {}

    for account in accounts:
        sigs_res = await session.execute(
            select(Signal).where(Signal.record_id == account.record_id)
        )
        sig_dicts = [_signal_to_dict(s) for s in sigs_res.scalars()]
        signal_map[account.record_id] = sig_dicts

        intent = compute_intent_score(sig_dicts, signal_weights, now=now)
        intent_scores[account.record_id] = intent

        await session.execute(
            update(Record)
            .where(Record.id == account.record_id)
            .values(intent_score=intent)
        )

        log.debug(
            "stage_4.scored",
            account_id=str(account.record_id),
            signal_count=len(sig_dicts),
            intent_score=intent,
        )

    duration_ms = int((time.monotonic() - t0) * 1000)
    await complete_step(
        session,
        step,
        output_payload={
            "accounts_scored": len(accounts),
            "scores": {str(k): v for k, v in intent_scores.items()},
        },
        duration_ms=duration_ms,
    )
    await session.commit()

    log.info("stage_4.complete", run_id=str(run.id), accounts=len(accounts))
    return Stage4Result(signal_map=signal_map, intent_scores=intent_scores)
