"""Stage 5 — Value Hypothesis Generation.

Calls Claude claude-sonnet-4-5 via the Anthropic SDK tool_use interface to
produce a structured value hypothesis for the top account.  The hypothesis
schema is distinct from the agent tool's GenerateHypothesis — it produces
the four fields required by the Phase 4 spec:

  pain_point_hypothesis : str   — the primary pain point
  relevance_explanation : str   — why our solution is relevant now
  signal_references     : list  — Signal UUIDs that support the hypothesis
  confidence            : float — [0, 1] evidence-based confidence score

A TOOL_CALL AgentStep is written before and after the Claude call per
CLAUDE.md rule #4.
"""
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import anthropic
import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tracing import complete_step, fail_step, next_step_number, write_step
from backbone.core.config import settings
from backbone.integrations.base import ToolError
from backbone.models.agent_run import AgentRun
from backbone.models.enums import AgentStepType
from backbone.models.icp import ICP
from prospect.workflows.stages import StageError
from prospect.workflows.stages.stage_2_discovery import ScoredAccount

log = structlog.get_logger(__name__)

_MODEL = "claude-sonnet-4-5"

_HYPOTHESIS_TOOL: dict[str, Any] = {
    "name": "submit_hypothesis",
    "description": "Submit the structured value hypothesis for this account.",
    "input_schema": {
        "type": "object",
        "properties": {
            "pain_point_hypothesis": {
                "type": "string",
                "description": (
                    "The primary, specific pain point this company is experiencing "
                    "right now, grounded in their signals and attributes."
                ),
            },
            "relevance_explanation": {
                "type": "string",
                "description": (
                    "A concise explanation of why our solution is uniquely relevant "
                    "to this company at this moment, citing specific evidence."
                ),
            },
            "signal_references": {
                "type": "array",
                "items": {"type": "string"},
                "description": "UUIDs of the Signal records that most strongly support this hypothesis.",
            },
            "confidence": {
                "type": "number",
                "description": "Confidence score from 0.0 (low) to 1.0 (high) based on evidence quality.",
            },
        },
        "required": [
            "pain_point_hypothesis",
            "relevance_explanation",
            "signal_references",
            "confidence",
        ],
    },
}


@dataclass
class Stage5Result:
    """Result returned by Stage 5."""

    hypothesis: dict[str, Any]
    account_record_id: uuid.UUID


async def run(
    session: AsyncSession,
    run: AgentRun,
    account: ScoredAccount,
    icp: ICP,
    signals: list[dict[str, Any]],
) -> Stage5Result:
    """Generate a structured value hypothesis for the top account.

    Args:
        session: Async session with tenant RLS context set.
        run: The AgentRun being executed.
        account: The top-ranked account from Stage 2.
        icp: The loaded ICP for context.
        signals: Signal dicts from Stage 4 for this account.

    Returns:
        :class:`Stage5Result` containing the structured hypothesis.

    Raises:
        StageError: If Claude cannot be reached or returns no tool_use block.
    """
    step_number = await next_step_number(session, run.id)
    t0 = time.monotonic()

    step = await write_step(
        session,
        run=run,
        step_number=step_number,
        step_type=AgentStepType.TOOL_CALL,
        tool_name="generate_hypothesis",
        input_payload={
            "account_record_id": str(account.record_id),
            "icp_id": str(icp.id),
            "signal_count": len(signals),
        },
    )
    await session.commit()

    attrs = account.attributes
    prompt = (
        f"You are a B2B sales strategist. Analyse this target account and generate a "
        f"precise, evidence-based value hypothesis.\n\n"
        f"Company attributes:\n{json.dumps(attrs, default=str, indent=2)}\n\n"
        f"ICP: {icp.name}\n{icp.description}\n\n"
        f"Fit score: {account.fit_score:.2f}/1.0\n\n"
        f"Recent signals ({len(signals)}):\n"
        f"{json.dumps(signals[:10], default=str, indent=2)}\n\n"
        f"Generate a hypothesis using the submit_hypothesis tool. "
        f"Reference specific signal UUIDs from the list above in signal_references. "
        f"Ground every claim in the data provided."
    )

    client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
    try:
        response = await client.messages.create(
            model=_MODEL,
            max_tokens=1024,
            system=(
                "You are a B2B sales strategy assistant. Generate structured value "
                "hypotheses based on account data, ICP criteria, and market signals."
            ),
            tools=[_HYPOTHESIS_TOOL],
            tool_choice={"type": "any"},
            messages=[{"role": "user", "content": prompt}],
            metadata={"user_id": str(run.id)},
        )
    except anthropic.APIError as exc:
        duration_ms = int((time.monotonic() - t0) * 1000)
        await fail_step(session, step, f"Claude API error: {exc}", duration_ms)
        await session.commit()
        raise StageError(f"Claude API error generating hypothesis: {exc}") from exc

    hypothesis: dict[str, Any] | None = None
    for block in response.content:
        if hasattr(block, "type") and block.type == "tool_use":
            hypothesis = dict(block.input)
            break

    duration_ms = int((time.monotonic() - t0) * 1000)

    if hypothesis is None:
        await fail_step(session, step, "Claude returned no tool_use block.", duration_ms)
        await session.commit()
        raise StageError("Claude did not return a structured hypothesis.")

    hypothesis["account_record_id"] = str(account.record_id)
    hypothesis["model"] = _MODEL

    await complete_step(
        session,
        step,
        output_payload=hypothesis,
        duration_ms=duration_ms,
    )
    await session.commit()

    log.info(
        "stage_5.complete",
        run_id=str(run.id),
        account_id=str(account.record_id),
        confidence=hypothesis.get("confidence"),
    )
    return Stage5Result(hypothesis=hypothesis, account_record_id=account.record_id)
