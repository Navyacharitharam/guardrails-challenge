"""Stage 6 — Outreach Drafting (2 Variants + Human Review).

Generates two stylistically distinct outreach email variants for the primary
contact using Claude claude-sonnet-4-5.  After both variants are produced,
a HumanReview record is created requiring approval before any email is sent.

Variant 1: conversational tone — relationship-building opener.
Variant 2: direct tone — problem-first, tight CTA.

A single TOOL_CALL AgentStep spans the entire stage (both Claude calls +
HumanReview creation) with the final output captured in output_payload.
"""
import time
import uuid
from dataclasses import dataclass
from typing import Any

import anthropic
import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tracing import fail_step, next_step_number, write_step
from backbone.core.config import settings
from backbone.models.agent_run import AgentRun
from backbone.models.enums import AgentStepStatus, AgentStepType, HumanReviewStatus, HumanReviewType
from backbone.models.human_review import HumanReview
from backbone.models.record import Record
from prospect.workflows.stages import StageError
from prospect.workflows.stages.stage_2_discovery import ScoredAccount

log = structlog.get_logger(__name__)

_MODEL = "claude-sonnet-4-5"

_OUTREACH_TOOL: dict[str, Any] = {
    "name": "submit_outreach",
    "description": "Submit the completed outreach email variant.",
    "input_schema": {
        "type": "object",
        "properties": {
            "subject": {
                "type": "string",
                "description": "Email subject line (max 60 characters, no clickbait).",
            },
            "body": {
                "type": "string",
                "description": "Email body in plain text. Under 200 words. One clear CTA.",
            },
            "tone": {
                "type": "string",
                "enum": ["formal", "conversational", "direct"],
            },
            "personalization_elements": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Specific facts from signals or account data used to personalise.",
            },
        },
        "required": ["subject", "body", "tone", "personalization_elements"],
    },
}


@dataclass
class OutreachVariant:
    """A single outreach email variant."""

    subject: str
    body: str
    tone: str
    personalization_elements: list[str]


@dataclass
class Stage6Result:
    """Result returned by Stage 6."""

    variants: list[OutreachVariant]
    review_id: uuid.UUID
    contact_record_id: uuid.UUID


async def _generate_variant(
    client: anthropic.AsyncAnthropic,
    contact_attrs: dict[str, Any],
    account_attrs: dict[str, Any],
    hypothesis: dict[str, Any],
    tone: str,
    run_id: uuid.UUID,
) -> OutreachVariant:
    """Call Claude once to produce one outreach variant.

    Args:
        client: Authenticated Anthropic async client.
        contact_attrs: Contact record attributes.
        account_attrs: Account record attributes.
        hypothesis: Stage 5 hypothesis dict.
        tone: Desired email tone ('conversational' or 'direct').

    Returns:
        :class:`OutreachVariant` populated from Claude's tool_use response.

    Raises:
        StageError: If Claude returns no tool_use block.
    """
    tone_instruction = (
        "Write in a conversational, human tone — start with an observation about their company."
        if tone == "conversational"
        else "Write in a direct, time-respecting tone — lead with the problem, end with a crisp CTA."
    )

    prompt = (
        f"Write a personalised B2B outreach email ({tone} tone).\n\n"
        f"{tone_instruction}\n\n"
        f"Recipient:\n"
        f"  Name: {contact_attrs.get('first_name', '')} {contact_attrs.get('last_name', '')}\n"
        f"  Title: {contact_attrs.get('job_title', 'Unknown')}\n"
        f"  Department: {contact_attrs.get('department', 'Unknown')}\n\n"
        f"Their company:\n"
        f"  Name: {account_attrs.get('company_name', 'Unknown')}\n"
        f"  Industry: {account_attrs.get('industry', 'Unknown')}\n"
        f"  Size: {account_attrs.get('employee_count', 'Unknown')} employees\n"
        f"  Stage: {account_attrs.get('funding_stage', 'Unknown')}\n\n"
        f"Value hypothesis:\n"
        f"  Pain point: {hypothesis.get('pain_point_hypothesis', '')}\n"
        f"  Why relevant: {hypothesis.get('relevance_explanation', '')}\n\n"
        f"Constraints:\n"
        f"- Under 200 words\n"
        f"- No generic openers ('I hope this finds you well')\n"
        f"- Reference one concrete fact about the company\n"
        f"- One clear call to action\n\n"
        f"Use the submit_outreach tool."
    )

    try:
        response = await client.messages.create(
            model=_MODEL,
            max_tokens=1024,
            system=(
                "You are a B2B sales copywriter. Write concise, personalised outreach "
                "emails grounded in the account data and value hypothesis provided."
            ),
            tools=[_OUTREACH_TOOL],
            tool_choice={"type": "any"},
            messages=[{"role": "user", "content": prompt}],
            metadata={"user_id": str(run_id)},
        )
    except anthropic.APIError as exc:
        raise StageError(f"Claude API error generating {tone} outreach variant: {exc}") from exc

    for block in response.content:
        if hasattr(block, "type") and block.type == "tool_use":
            data = dict(block.input)
            return OutreachVariant(
                subject=data.get("subject", ""),
                body=data.get("body", ""),
                tone=data.get("tone", tone),
                personalization_elements=data.get("personalization_elements", []),
            )

    raise StageError(f"Claude returned no tool_use block for {tone} outreach variant.")


async def run(
    session: AsyncSession,
    run: AgentRun,
    account: ScoredAccount,
    contact_record_id: uuid.UUID,
    hypothesis: dict[str, Any],
) -> Stage6Result:
    """Generate 2 outreach variants and create a HumanReview pending approval.

    Args:
        session: Async session with tenant RLS context set.
        run: The AgentRun being executed.
        account: The top-ranked account from Stage 2.
        contact_record_id: UUID of the primary contact to write to.
        hypothesis: Stage 5 hypothesis dict.

    Returns:
        :class:`Stage6Result` with both variants and the HumanReview ID.

    Raises:
        StageError: If the contact record is not found or Claude fails.
    """
    step_number = await next_step_number(session, run.id)
    t0 = time.monotonic()

    step = await write_step(
        session,
        run=run,
        step_number=step_number,
        step_type=AgentStepType.TOOL_CALL,
        tool_name="generate_outreach",
        input_payload={
            "contact_record_id": str(contact_record_id),
            "account_record_id": str(account.record_id),
        },
    )
    await session.commit()

    contact_res = await session.execute(select(Record).where(Record.id == contact_record_id))
    contact = contact_res.scalar_one_or_none()
    if contact is None:
        duration_ms = int((time.monotonic() - t0) * 1000)
        await fail_step(session, step, f"Contact record {contact_record_id} not found.", duration_ms)
        await session.commit()
        raise StageError(f"Contact record {contact_record_id} not found.")

    contact_attrs = contact.attributes or {}
    account_attrs = account.attributes

    client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
    variants: list[OutreachVariant] = []
    try:
        for tone in ("conversational", "direct"):
            variant = await _generate_variant(
                client=client,
                contact_attrs=contact_attrs,
                account_attrs=account_attrs,
                hypothesis=hypothesis,
                tone=tone,
                run_id=run.id,
            )
            variants.append(variant)
    except (anthropic.APIError, StageError) as exc:
        duration_ms = int((time.monotonic() - t0) * 1000)
        await fail_step(session, step, f"Outreach generation error: {exc}", duration_ms)
        await session.commit()
        raise StageError(f"Outreach generation failed: {exc}") from exc

    review = HumanReview(
        tenant_id=run.tenant_id,
        run_id=run.id,
        step_id=step.id,
        review_type=HumanReviewType.OUTREACH_APPROVAL,
        proposed_output={
            "variants": [
                {
                    "subject": v.subject,
                    "body": v.body,
                    "tone": v.tone,
                    "personalization_elements": v.personalization_elements,
                }
                for v in variants
            ],
            "contact_record_id": str(contact_record_id),
            "account_record_id": str(account.record_id),
        },
        context={
            "hypothesis": hypothesis,
            "contact_name": f"{contact_attrs.get('first_name', '')} {contact_attrs.get('last_name', '')}".strip(),
            "company_name": account_attrs.get("company_name", ""),
            "fit_score": account.fit_score,
        },
        status=HumanReviewStatus.PENDING,
    )
    session.add(review)
    await session.flush()

    duration_ms = int((time.monotonic() - t0) * 1000)
    step.status = AgentStepStatus.PENDING
    step.output_payload = {
        "variants_generated": len(variants),
        "review_id": str(review.id),
        "variants": [{"subject": v.subject, "tone": v.tone} for v in variants],
    }
    step.duration_ms = duration_ms
    session.add(step)
    await session.flush()
    await session.commit()

    log.info(
        "stage_6.complete",
        run_id=str(run.id),
        contact_id=str(contact_record_id),
        review_id=str(review.id),
    )
    return Stage6Result(
        variants=variants,
        review_id=review.id,
        contact_record_id=contact_record_id,
    )
