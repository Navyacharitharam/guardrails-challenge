"""Stage 3 — Contact Enrichment via Hunter.io Waterfall.

For each top account (up to ``MAX_ACCOUNTS``), loads its contacts via the
``works_at`` relationship, then calls the integration waterfall's
``find_email`` operation to resolve a verified professional email address.

Successful enrichments are persisted to the contact's ``attributes`` and
``enrichment_status`` fields.  Failed enrichments are logged and skipped —
the stage never raises on partial failure so the workflow can continue.
"""
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backbone.agents.tracing import complete_step, next_step_number, write_step
from backbone.integrations.base import ToolError
from backbone.integrations.waterfall import resolve
from backbone.models.agent_run import AgentRun
from backbone.models.enums import AgentStepType, EnrichmentStatus
from backbone.models.record import Record
from backbone.models.relationship import RecordRelationship
from prospect.workflows.stages.stage_2_discovery import ScoredAccount

# Trigger provider registration.
import backbone.integrations.providers.hunter  # noqa: F401

log = structlog.get_logger(__name__)

_MAX_ACCOUNTS = 3


@dataclass
class EnrichmentRecord:
    """Result of enriching one contact."""

    contact_id: uuid.UUID
    account_id: uuid.UUID
    email: str | None
    enriched_fields: list[str]
    success: bool


@dataclass
class Stage3Result:
    """Result returned by Stage 3."""

    enrichments: list[EnrichmentRecord]
    enriched_count: int
    failed_count: int


async def run(
    session: AsyncSession,
    run: AgentRun,
    accounts: list[ScoredAccount],
    max_accounts: int = _MAX_ACCOUNTS,
) -> Stage3Result:
    """Enrich contacts for the top accounts via the Hunter.io waterfall.

    Args:
        session: Async session with tenant RLS context set.
        run: The AgentRun being executed.
        accounts: Scored accounts from Stage 2 (taken in fit_score order).
        max_accounts: Maximum number of accounts to enrich contacts for.

    Returns:
        :class:`Stage3Result` summarising enrichment outcomes.
    """
    step_number = await next_step_number(session, run.id)
    t0 = time.monotonic()

    top_accounts = accounts[:max_accounts]
    step = await write_step(
        session,
        run=run,
        step_number=step_number,
        step_type=AgentStepType.TOOL_CALL,
        tool_name="enrich_contact",
        input_payload={
            "account_ids": [str(a.record_id) for a in top_accounts],
            "max_accounts": max_accounts,
        },
    )
    await session.commit()

    enrichments: list[EnrichmentRecord] = []

    for account in top_accounts:
        rel_res = await session.execute(
            select(RecordRelationship).where(
                RecordRelationship.to_record_id == account.record_id,
                RecordRelationship.relationship_type == "works_at",
            )
        )
        contact_ids = [r.from_record_id for r in rel_res.scalars()]
        if not contact_ids:
            continue

        contacts_res = await session.execute(
            select(Record).where(Record.id.in_(contact_ids[:1]))
        )
        contacts = list(contacts_res.scalars())

        for contact in contacts:
            attrs = contact.attributes or {}
            first_name = attrs.get("first_name", "")
            last_name = attrs.get("last_name", "")
            domain = account.attributes.get("website", "")

            if domain.startswith(("http://", "https://")):
                domain = domain.split("//", 1)[1].lstrip("www.").split("/")[0]

            try:
                result = await resolve(
                    "find_email",
                    session,
                    first_name=first_name,
                    last_name=last_name,
                    domain=domain,
                )
                enriched_fields: list[str] = []
                data = result.data

                if data.get("email"):
                    attrs["email"] = data["email"]
                    enriched_fields.append("email")
                if data.get("linkedin_url"):
                    attrs["linkedin_url"] = data["linkedin_url"]
                    enriched_fields.append("linkedin_url")
                if data.get("position") and not attrs.get("job_title"):
                    attrs["job_title"] = data["position"]
                    enriched_fields.append("job_title")

                contact.attributes = attrs
                contact.enrichment_status = EnrichmentStatus.ENRICHED
                session.add(contact)

                enrichments.append(EnrichmentRecord(
                    contact_id=contact.id,
                    account_id=account.record_id,
                    email=data.get("email"),
                    enriched_fields=enriched_fields,
                    success=True,
                ))
                log.info(
                    "stage_3.enriched",
                    contact_id=str(contact.id),
                    fields=enriched_fields,
                )

            except ToolError as exc:
                contact.enrichment_status = EnrichmentStatus.FAILED
                session.add(contact)
                enrichments.append(EnrichmentRecord(
                    contact_id=contact.id,
                    account_id=account.record_id,
                    email=None,
                    enriched_fields=[],
                    success=False,
                ))
                log.warning(
                    "stage_3.enrich_failed",
                    contact_id=str(contact.id),
                    error=str(exc),
                )

    await session.flush()

    enriched_count = sum(1 for e in enrichments if e.success)
    failed_count = len(enrichments) - enriched_count
    duration_ms = int((time.monotonic() - t0) * 1000)

    await complete_step(
        session,
        step,
        output_payload={
            "contacts_processed": len(enrichments),
            "enriched": enriched_count,
            "failed": failed_count,
            "results": [
                {
                    "contact_id": str(e.contact_id),
                    "account_id": str(e.account_id),
                    "success": e.success,
                    "enriched_fields": e.enriched_fields,
                }
                for e in enrichments
            ],
        },
        duration_ms=duration_ms,
    )
    await session.commit()

    log.info(
        "stage_3.complete",
        run_id=str(run.id),
        enriched=enriched_count,
        failed=failed_count,
    )
    return Stage3Result(
        enrichments=enrichments,
        enriched_count=enriched_count,
        failed_count=failed_count,
    )
