"""ICP fit scoring — computes a 0.0–1.0 score for how well an Account matches an ICP.

Scoring dimensions and weights
-------------------------------
  firmographic  : 0.50  — industry, headcount, ARR, funding stage, geography
  technographic : 0.20  — technology stack overlap with ICP requirements
  persona       : 0.30  — whether the account has contacts matching target personas

Each dimension yields a sub-score in [0, 1].  The final fit_score is a
weighted average of the three sub-scores.
"""
from typing import Any


def _score_firmographic(attrs: dict[str, Any], criteria: dict[str, Any]) -> float:
    """Return a [0,1] score for how well account firmographics match ICP criteria."""
    if not criteria:
        return 1.0  # No constraints means any company qualifies.
    signals: list[float] = []

    # Industry match
    target_industries: list[str] = criteria.get("industries", [])
    if target_industries:
        account_industry = attrs.get("industry", "")
        match = any(
            ind.lower() in account_industry.lower() or account_industry.lower() in ind.lower()
            for ind in target_industries
        )
        signals.append(1.0 if match else 0.0)

    # Employee count range
    ec_range: dict = criteria.get("employee_count", {})
    if ec_range:
        ec = attrs.get("employee_count")
        if ec is not None:
            min_ec = ec_range.get("min", 0)
            max_ec = ec_range.get("max", float("inf"))
            if min_ec <= ec <= max_ec:
                signals.append(1.0)
            elif ec < min_ec:
                signals.append(max(0.0, 1.0 - (min_ec - ec) / min_ec))
            else:
                signals.append(max(0.0, 1.0 - (ec - max_ec) / max_ec))

    # ARR range
    arr_range: dict = criteria.get("arr_usd", {})
    if arr_range:
        arr = attrs.get("arr_usd")
        if arr is not None:
            min_arr = arr_range.get("min", 0)
            max_arr = arr_range.get("max", float("inf"))
            signals.append(1.0 if min_arr <= arr <= max_arr else 0.5)

    # Funding stage
    funding_stages: list[str] = criteria.get("funding_stages", [])
    if funding_stages:
        account_stage = attrs.get("funding_stage", "")
        signals.append(1.0 if account_stage in funding_stages else 0.0)

    # Geography
    geographies: list[str] = criteria.get("geographies", [])
    if geographies:
        account_country = attrs.get("hq_country", "")
        signals.append(1.0 if account_country in geographies else 0.3)

    return sum(signals) / len(signals) if signals else 0.5


def _score_technographic(attrs: dict[str, Any], criteria: dict[str, Any]) -> float:
    """Return a [0,1] score based on technology stack overlap."""
    if not criteria:
        return 1.0  # No constraints means any tech stack qualifies.
    account_techs = {t.lower() for t in attrs.get("technologies_used", [])}

    must_have = [t.lower() for t in criteria.get("must_use_one_of", [])]
    nice_have = [t.lower() for t in criteria.get("nice_to_have", [])]
    disqualifiers = [t.lower() for t in criteria.get("disqualifiers", [])]

    if disqualifiers and any(d in account_techs for d in disqualifiers):
        return 0.0

    must_score = 0.0
    if must_have:
        must_score = 1.0 if any(t in account_techs for t in must_have) else 0.2

    nice_score = 0.5
    if nice_have:
        overlap = sum(1 for t in nice_have if t in account_techs)
        nice_score = overlap / len(nice_have)

    if must_have:
        return 0.7 * must_score + 0.3 * nice_score
    return nice_score


def _score_persona(
    contact_attributes_list: list[dict[str, Any]], criteria: dict[str, Any]
) -> float:
    """Return a [0,1] score based on whether target personas are reachable.

    Uses a list of contact attribute dicts (pre-fetched) rather than querying DB.
    """
    if not criteria:
        return 1.0  # No persona constraints means any contact profile qualifies.

    if not contact_attributes_list:
        return 0.3  # Criteria exist but contacts are unknown — penalise, don't disqualify.

    target_titles = [t.lower() for t in criteria.get("target_titles", [])]
    target_seniorities = [s.lower() for s in criteria.get("seniority_levels", [])]
    target_depts = [d.lower() for d in criteria.get("departments", [])]

    best_match = 0.0
    for contact_attrs in contact_attributes_list:
        title = contact_attrs.get("job_title", "").lower()
        seniority = contact_attrs.get("seniority", "").lower()
        dept = contact_attrs.get("department", "").lower()

        match_score = 0.0
        if target_titles and any(t in title or title in t for t in target_titles):
            match_score += 0.5
        if target_seniorities and seniority in target_seniorities:
            match_score += 0.3
        if target_depts and any(d in dept or dept in d for d in target_depts):
            match_score += 0.2
        best_match = max(best_match, match_score)

    # Non-matching contacts still confirm that someone is reachable — floor at the
    # same level as "no contacts", ensuring they never score below unknown.
    return max(min(best_match, 1.0), 0.3)


def compute_fit_score(
    account_attributes: dict[str, Any],
    icp_firmographic: dict[str, Any],
    icp_technographic: dict[str, Any],
    icp_persona: dict[str, Any],
    contact_attributes_list: list[dict[str, Any]],
) -> float:
    """Compute and return the ICP fit score for one account.

    Args:
        account_attributes: The account's ``attributes`` JSONB dict.
        icp_firmographic: ICP ``firmographic_criteria`` dict.
        icp_technographic: ICP ``technographic_criteria`` dict.
        icp_persona: ICP ``persona_criteria`` dict.
        contact_attributes_list: List of ``attributes`` dicts for the account's contacts.

    Returns:
        A float in [0.0, 1.0] where 1.0 is a perfect ICP match.
    """
    # Disqualifying technology is an immediate knock-out regardless of other dimensions.
    account_techs = {t.lower() for t in account_attributes.get("technologies_used", [])}
    disqualifiers = [t.lower() for t in icp_technographic.get("disqualifiers", [])]
    if disqualifiers and any(d in account_techs for d in disqualifiers):
        return 0.0

    firmographic = _score_firmographic(account_attributes, icp_firmographic)
    technographic = _score_technographic(account_attributes, icp_technographic)
    persona = _score_persona(contact_attributes_list, icp_persona)

    return round(0.50 * firmographic + 0.20 * technographic + 0.30 * persona, 4)
