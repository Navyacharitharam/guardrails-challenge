"""Intent scoring — aggregates signals into a 0.0–1.0 intent_score.

Algorithm
---------
For each signal associated with an account:
  1. Retrieve the weight for the signal's type from the ICP's ``signal_weights``.
  2. Multiply the ICP weight by the signal's own ``score`` (normalised importance).
  3. Apply a recency decay: signals older than 90 days are downweighted.

Final intent_score = weighted average of all signal contributions, capped at 1.0.
"""
from datetime import datetime, timezone
from typing import Any


_RECENCY_HALF_LIFE_DAYS = 45  # Signals lose half their value every 45 days.
_DEFAULT_SIGNAL_WEIGHT = 0.5  # Used when the ICP has no weight for this type.


def _recency_factor(occurred_at: datetime, now: datetime | None = None) -> float:
    """Return a [0, 1] decay factor based on signal age."""
    if now is None:
        now = datetime.now(timezone.utc)
    age_days = (now - occurred_at.replace(tzinfo=timezone.utc)).days
    if age_days <= 0:
        return 1.0
    return 0.5 ** (age_days / _RECENCY_HALF_LIFE_DAYS)


def compute_intent_score(
    signals: list[dict[str, Any]],
    icp_signal_weights: dict[str, float],
    now: datetime | None = None,
) -> float:
    """Compute intent score from a list of signal dicts.

    Args:
        signals: List of dicts with keys ``signal_type``, ``score``,
            ``occurred_at`` (ISO string or datetime).
        icp_signal_weights: Mapping from signal type value to [0,1] ICP weight.
        now: Reference time for recency decay (defaults to UTC now).

    Returns:
        A float in [0.0, 1.0].
    """
    if not signals:
        return 0.0

    if now is None:
        now = datetime.now(timezone.utc)

    total_weight = 0.0
    weighted_sum = 0.0

    for sig in signals:
        signal_type = sig.get("signal_type") or sig.get("signal_type_value", "")
        raw_score = float(sig.get("score", 0.5))

        occurred_at = sig.get("occurred_at")
        if isinstance(occurred_at, str):
            occurred_at = datetime.fromisoformat(occurred_at.replace("Z", "+00:00"))
        elif occurred_at is None:
            occurred_at = now

        icp_weight = icp_signal_weights.get(signal_type, _DEFAULT_SIGNAL_WEIGHT)
        recency = _recency_factor(occurred_at, now)

        contribution = icp_weight * raw_score * recency
        total_weight += icp_weight
        weighted_sum += contribution

    if total_weight == 0:
        return 0.0

    return round(min(weighted_sum / total_weight, 1.0), 4)
