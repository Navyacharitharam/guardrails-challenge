/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",

  // Proxy /auth/* and /api/* to the backbone service so the browser never
  // needs to reach the backend directly (avoids CORS entirely in production).
  async rewrites() {
    const backendUrl =
      process.env.BACKEND_URL ?? "http://localhost:8000";
    return [
      {
        source: "/auth/:path*",
        destination: `${backendUrl}/auth/:path*`,
      },
      {
        source: "/api/:path*",
        destination: `${backendUrl}/api/:path*`,
      },
      {
        source: "/health",
        destination: `${backendUrl}/health`,
      },
    ];
  },
};

module.exports = nextConfig;
