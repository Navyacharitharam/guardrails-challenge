/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // GTM Platform dark enterprise design tokens
        background: "#0A0A0F",
        surface: "#111118",
        border: "rgba(255,255,255,0.08)",
        accent: "#6366F1",
        success: "#10B981",
        warning: "#F59E0B",
        danger: "#EF4444",
        "text-primary": "#F8F8FF",
        "text-secondary": "#9CA3AF",
      },
    },
  },
  plugins: [],
};
