import { ScoreBar } from "./ScoreBar";
import { SignalChip } from "./SignalChip";
import type { Record as GTMRecord, Signal } from "@/lib/types";

interface AccountCardProps {
  record: GTMRecord;
  signals?: Signal[];
  highlight?: boolean;
}

export function AccountCard({
  record,
  signals = [],
  highlight = false,
}: AccountCardProps) {
  const attrs = record.attributes as Record<string, unknown>;
  const topSignal = signals[0];

  const meta = [
    attrs.industry,
    attrs.employee_count ? `${attrs.employee_count} emp` : null,
    attrs.funding_stage,
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <div
      className={`rounded-xl border p-4 transition-colors${
        highlight ? " border-[#6366F1]/40" : " hover:border-[rgba(99,102,241,0.25)]"
      }`}
      style={{
        background: "#111118",
        borderColor: highlight ? "rgba(99,102,241,0.4)" : "rgba(255,255,255,0.08)",
      }}
    >
      <div className="flex items-start justify-between mb-3 gap-2">
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-medium text-[#F8F8FF] truncate">
            {String(attrs.company_name ?? "Unknown")}
          </h3>
          {meta && (
            <p className="text-xs text-[#9CA3AF] mt-0.5 truncate">{meta}</p>
          )}
        </div>
        {topSignal && (
          <div className="flex-shrink-0">
            <SignalChip type={topSignal.signal_type} />
          </div>
        )}
      </div>

      <div className="space-y-2">
        {record.fit_score != null && (
          <ScoreBar label="ICP Fit" score={record.fit_score} color="#6366F1" />
        )}
        {record.intent_score != null && (
          <ScoreBar label="Intent" score={record.intent_score} color="#10B981" />
        )}
      </div>

      {(attrs.hq_city || attrs.hq_country) && (
        <div className="mt-3 text-xs text-[#6B7280]">
          {[attrs.hq_city, attrs.hq_country].filter(Boolean).join(", ")}
        </div>
      )}
    </div>
  );
}
