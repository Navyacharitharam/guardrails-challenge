import type { AgentRunStatus } from "@/lib/types";

const STATUS_CFG: Record<AgentRunStatus, { label: string; color: string; bg: string; pulse: boolean }> = {
  queued: { label: "Queued", color: "#9CA3AF", bg: "rgba(156,163,175,0.1)", pulse: false },
  running: { label: "Running", color: "#6366F1", bg: "rgba(99,102,241,0.1)", pulse: true },
  completed: { label: "Completed", color: "#10B981", bg: "rgba(16,185,129,0.1)", pulse: false },
  failed: { label: "Failed", color: "#EF4444", bg: "rgba(239,68,68,0.1)", pulse: false },
  cancelled: { label: "Cancelled", color: "#9CA3AF", bg: "rgba(156,163,175,0.1)", pulse: false },
};

interface RunStatusProps {
  status: AgentRunStatus | string;
}

export function RunStatus({ status }: RunStatusProps) {
  const cfg = STATUS_CFG[status as AgentRunStatus] ?? STATUS_CFG.queued; // nosemgrep: javascript.lang.security.detect-object-injection
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium"
      style={{ background: cfg.bg, color: cfg.color }}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full flex-shrink-0${cfg.pulse ? " animate-pulse" : ""}`}
        style={{ background: cfg.color }}
      />
      {cfg.label}
    </span>
  );
}
