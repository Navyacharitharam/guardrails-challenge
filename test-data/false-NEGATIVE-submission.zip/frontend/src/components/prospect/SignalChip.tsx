import type { SignalType } from "@/lib/types";

const SIGNAL_CFG: Record<string, { label: string; bg: string; color: string }> = {
  funding: { label: "Funding", bg: "rgba(16,185,129,0.12)", color: "#10B981" },
  hiring: { label: "Hiring", bg: "rgba(99,102,241,0.12)", color: "#6366F1" },
  job_change: { label: "Job Change", bg: "rgba(99,102,241,0.12)", color: "#6366F1" },
  intent: { label: "Intent", bg: "rgba(245,158,11,0.12)", color: "#F59E0B" },
  technographic: { label: "Tech", bg: "rgba(156,163,175,0.12)", color: "#9CA3AF" },
  news: { label: "News", bg: "rgba(245,158,11,0.12)", color: "#F59E0B" },
  web_activity: { label: "Web", bg: "rgba(156,163,175,0.12)", color: "#9CA3AF" },
};

interface SignalChipProps {
  type: SignalType | string;
}

export function SignalChip({ type }: SignalChipProps) {
  const cfg = SIGNAL_CFG[type] ?? { // nosemgrep: javascript.lang.security.detect-object-injection
    label: type,
    bg: "rgba(156,163,175,0.12)",
    color: "#9CA3AF",
  };
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
      style={{ background: cfg.bg, color: cfg.color }}
    >
      {cfg.label}
    </span>
  );
}
