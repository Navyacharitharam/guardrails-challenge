interface OutreachVariant {
  subject: string;
  body: string;
  tone: string;
  personalization_elements?: string[];
}

interface OutreachReviewProps {
  proposed_output: Record<string, unknown>;
}

const TONE_CFG: Record<string, { color: string; bg: string }> = {
  conversational: { color: "#6366F1", bg: "rgba(99,102,241,0.1)" },
  direct: { color: "#10B981", bg: "rgba(16,185,129,0.1)" },
  formal: { color: "#9CA3AF", bg: "rgba(156,163,175,0.1)" },
};

export function OutreachReview({ proposed_output }: OutreachReviewProps) {
  const variants = (proposed_output.variants as OutreachVariant[]) ?? [];

  if (variants.length === 0) {
    return (
      <div className="text-sm text-[#9CA3AF]">No outreach variants generated.</div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {variants.map((v, i) => {
        const toneCfg = TONE_CFG[v.tone] ?? TONE_CFG.formal; // nosemgrep: javascript.lang.security.detect-object-injection
        return (
          <div
            key={i}
            className="rounded-lg border p-4 flex flex-col gap-3"
            style={{ borderColor: "rgba(255,255,255,0.08)" }}
          >
            {/* Header */}
            <div className="flex items-center justify-between">
              <span
                className="text-xs px-2 py-0.5 rounded-full font-medium capitalize"
                style={{ background: toneCfg.bg, color: toneCfg.color }}
              >
                {v.tone}
              </span>
              <span className="text-xs text-[#6B7280]">Variant {i + 1}</span>
            </div>

            {/* Subject */}
            <div>
              <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1">
                Subject
              </div>
              <p className="text-sm font-medium text-[#F8F8FF] leading-snug">
                {v.subject}
              </p>
            </div>

            {/* Body */}
            <div className="flex-1">
              <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1">
                Body
              </div>
              <p className="text-xs text-[#9CA3AF] whitespace-pre-wrap leading-relaxed">
                {v.body}
              </p>
            </div>

            {/* Personalization elements */}
            {v.personalization_elements && v.personalization_elements.length > 0 && (
              <div>
                <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1.5">
                  Personalization
                </div>
                <div className="flex flex-wrap gap-1">
                  {v.personalization_elements.map((el, j) => (
                    <span
                      key={j}
                      className="text-xs px-2 py-0.5 rounded-full"
                      style={{
                        background: "rgba(255,255,255,0.05)",
                        color: "#9CA3AF",
                      }}
                    >
                      {el}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
