import type { HumanReview } from "@/lib/types";

interface Hypothesis {
  pain_point_hypothesis?: string;
  relevance_explanation?: string;
  signal_references?: string[];
  confidence?: number;
}

interface HypothesisReviewProps {
  review: HumanReview;
}

export function HypothesisReview({ review }: HypothesisReviewProps) {
  const h = review.proposed_output as Hypothesis;

  return (
    <div className="space-y-4">
      {h.pain_point_hypothesis && (
        <div
          className="rounded-lg p-4"
          style={{ background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.2)" }}
        >
          <div className="text-xs font-medium text-[#6366F1] mb-2">Pain Point Hypothesis</div>
          <p className="text-sm text-[#F8F8FF] leading-relaxed">
            {h.pain_point_hypothesis}
          </p>
        </div>
      )}

      {h.relevance_explanation && (
        <div>
          <div className="text-xs font-medium text-[#9CA3AF] mb-1.5">Why This Matters</div>
          <p className="text-sm text-[#9CA3AF] leading-relaxed">
            {h.relevance_explanation}
          </p>
        </div>
      )}

      {h.confidence !== undefined && (
        <div className="flex items-center gap-3">
          <div className="text-xs text-[#9CA3AF] w-20 flex-shrink-0">Confidence</div>
          <div className="flex-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
            <div
              className="h-full rounded-full"
              style={{
                width: `${Math.round(h.confidence * 100)}%`,
                background: "#6366F1",
              }}
            />
          </div>
          <span className="text-xs font-medium text-[#6366F1] w-8 text-right">
            {Math.round(h.confidence * 100)}%
          </span>
        </div>
      )}

      {h.signal_references && h.signal_references.length > 0 && (
        <div>
          <div className="text-xs font-medium text-[#9CA3AF] mb-1.5">
            Signal References ({h.signal_references.length})
          </div>
          <div className="flex flex-col gap-1">
            {h.signal_references.map((ref, i) => (
              <span
                key={i}
                className="text-xs font-mono text-[#6B7280] px-2 py-1 rounded"
                style={{ background: "rgba(255,255,255,0.04)" }}
              >
                {ref}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
