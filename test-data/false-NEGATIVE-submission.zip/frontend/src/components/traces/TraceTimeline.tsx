import type { AgentStep } from "@/lib/types";
import { StepCard } from "./StepCard";

interface TraceTimelineProps {
  steps: AgentStep[];
}

export function TraceTimeline({ steps }: TraceTimelineProps) {
  if (steps.length === 0) {
    return (
      <div className="text-sm text-[#9CA3AF] py-4">
        No steps recorded yet.
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {steps.map((step) => (
        <StepCard key={step.id} step={step} />
      ))}
    </div>
  );
}
