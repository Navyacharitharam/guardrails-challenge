"use client";
import { useState } from "react";
import type { AgentStep } from "@/lib/types";
import { JsonViewer } from "@/components/ui/JsonViewer";

const STEP_ICONS: Record<string, React.ReactNode> = {
  tool_call: (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 11-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 004.486-6.336l-3.276 3.277a3.004 3.004 0 01-2.25-2.25l3.276-3.276a4.5 4.5 0 00-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437l1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008z" />
    </svg>
  ),
  llm_call: (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
    </svg>
  ),
  human_gate: (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
    </svg>
  ),
  error: (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
};

const STATUS_COLORS: Record<string, string> = {
  pending: "#F59E0B",
  running: "#6366F1",
  completed: "#10B981",
  failed: "#EF4444",
  retried: "#F59E0B",
};

interface StepCardProps {
  step: AgentStep;
}

export function StepCard({ step }: StepCardProps) {
  const [open, setOpen] = useState(false);
  const statusColor = STATUS_COLORS[step.status] ?? "#9CA3AF"; // nosemgrep: javascript.lang.security.detect-object-injection
  const hasDetails =
    step.reasoning ||
    (step.input_payload && Object.keys(step.input_payload).length > 0) ||
    step.output_payload ||
    step.error_message;

  return (
    <div
      className="rounded-lg border overflow-hidden"
      style={{ borderColor: "rgba(255,255,255,0.08)" }}
    >
      <button
        className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors${hasDetails ? " hover:bg-white/[0.02] cursor-pointer" : " cursor-default"}`}
        onClick={() => hasDetails && setOpen(!open)}
      >
        {/* Step number */}
        <span className="text-[#6B7280] text-xs w-5 text-right flex-shrink-0 font-mono">
          {step.step_number}
        </span>

        {/* Step type icon */}
        <span
          className="w-5 h-5 rounded flex items-center justify-center flex-shrink-0"
          style={{
            background: `${statusColor}18`,
            color: statusColor,
          }}
        >
          {STEP_ICONS[step.step_type] ?? ( // nosemgrep: javascript.lang.security.detect-object-injection
            <span className="text-[9px]">·</span>
          )}
        </span>

        {/* Tool name / type */}
        <span className="flex-1 text-sm text-[#F8F8FF] text-left truncate">
          {step.tool_name ?? step.step_type}
        </span>

        {/* Duration */}
        {step.duration_ms != null && (
          <span className="text-xs text-[#6B7280] flex-shrink-0 tabular-nums">
            {step.duration_ms < 1000
              ? `${step.duration_ms}ms`
              : `${(step.duration_ms / 1000).toFixed(1)}s`}
          </span>
        )}

        {/* Status badge */}
        <span
          className="text-[10px] px-1.5 py-0.5 rounded-full flex-shrink-0 font-medium"
          style={{ background: `${statusColor}18`, color: statusColor }}
        >
          {step.status}
        </span>

        {/* Chevron */}
        {hasDetails && (
          <svg
            className={`w-3 h-3 text-[#6B7280] flex-shrink-0 transition-transform${open ? " rotate-180" : ""}`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        )}
      </button>

      {open && hasDetails && (
        <div
          className="px-4 pb-4 pt-3 border-t space-y-3"
          style={{ background: "#0D0D14", borderColor: "rgba(255,255,255,0.06)" }}
        >
          {step.reasoning && (
            <blockquote className="border-l-2 border-[#6366F1]/40 pl-3 text-sm text-[#9CA3AF] italic leading-relaxed">
              {step.reasoning}
            </blockquote>
          )}
          {step.input_payload && Object.keys(step.input_payload).length > 0 && (
            <JsonViewer data={step.input_payload} title="Input" />
          )}
          {step.output_payload && (
            <JsonViewer data={step.output_payload} title="Output" maxHeight="16rem" />
          )}
          {step.error_message && (
            <div
              className="text-xs text-[#EF4444] rounded-lg px-3 py-2"
              style={{ background: "rgba(239,68,68,0.08)" }}
            >
              {step.error_message}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
