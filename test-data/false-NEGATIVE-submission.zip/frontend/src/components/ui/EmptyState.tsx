interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div
      className="rounded-xl border p-12 text-center"
      style={{ background: "#111118", borderColor: "rgba(255,255,255,0.08)" }}
    >
      <div className="text-3xl mb-3 flex justify-center">{icon}</div>
      <div className="text-sm font-medium text-[#F8F8FF] mb-1">{title}</div>
      {description && (
        <div className="text-xs text-[#9CA3AF] max-w-xs mx-auto">{description}</div>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
