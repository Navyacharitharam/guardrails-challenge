"use client";
import { useState } from "react";

interface JsonViewerProps {
  data: unknown;
  title?: string;
  defaultOpen?: boolean;
  maxHeight?: string;
}

export function JsonViewer({
  data,
  title,
  defaultOpen = false,
  maxHeight = "12rem",
}: JsonViewerProps) {
  const [open, setOpen] = useState(defaultOpen);
  const json = JSON.stringify(data, null, 2);

  if (!title) {
    return (
      <pre
        className="text-xs text-[#9CA3AF] bg-[#0A0A0F] rounded-lg p-3 overflow-auto font-mono leading-relaxed"
        style={{ maxHeight }}
      >
        {json}
      </pre>
    );
  }

  return (
    <div>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 text-xs font-medium text-[#9CA3AF] mb-1.5 hover:text-[#F8F8FF] transition-colors"
      >
        <svg
          className={`w-3 h-3 transition-transform ${open ? "rotate-90" : ""}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 5l7 7-7 7"
          />
        </svg>
        {title}
        <span className="text-[#6B7280] font-normal">
          ({Array.isArray(data) ? `${(data as unknown[]).length} items` : typeof data === "object" && data !== null ? `${Object.keys(data as object).length} keys` : typeof data})
        </span>
      </button>
      {open && (
        <pre
          className="text-xs text-[#9CA3AF] bg-[#0A0A0F] rounded-lg p-3 overflow-auto font-mono leading-relaxed"
          style={{ maxHeight }}
        >
          {json}
        </pre>
      )}
    </div>
  );
}
