interface CardProps {
  children: React.ReactNode;
  className?: string;
  padding?: "sm" | "md" | "lg";
}

const PADDING = { sm: "p-3", md: "p-5", lg: "p-6" };

export function Card({ children, className, padding = "md" }: CardProps) {
  return (
    <div
      className={`rounded-xl border ${PADDING[padding]}${className ? ` ${className}` : ""}`} // nosemgrep: javascript.lang.security.detect-object-injection
      style={{ background: "#111118", borderColor: "rgba(255,255,255,0.08)" }}
    >
      {children}
    </div>
  );
}
