interface SpinnerProps {
  size?: "sm" | "md" | "lg";
}

const SIZES = { sm: "w-4 h-4 border-[1.5px]", md: "w-5 h-5 border-2", lg: "w-8 h-8 border-2" };

export function Spinner({ size = "md" }: SpinnerProps) {
  return (
    <div
      className={`${SIZES[size]} border-[#6366F1]/25 border-t-[#6366F1] rounded-full animate-spin flex-shrink-0`} // nosemgrep: javascript.lang.security.detect-object-injection
    />
  );
}
