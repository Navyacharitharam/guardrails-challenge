type Variant =
  | "default"
  | "success"
  | "warning"
  | "danger"
  | "accent"
  | "muted";

const VARIANTS: Record<Variant, { bg: string; color: string }> = {
  default: { bg: "rgba(156,163,175,0.12)", color: "#9CA3AF" },
  success: { bg: "rgba(16,185,129,0.12)", color: "#10B981" },
  warning: { bg: "rgba(245,158,11,0.12)", color: "#F59E0B" },
  danger: { bg: "rgba(239,68,68,0.12)", color: "#EF4444" },
  accent: { bg: "rgba(99,102,241,0.12)", color: "#6366F1" },
  muted: { bg: "rgba(255,255,255,0.05)", color: "#6B7280" },
};

interface BadgeProps {
  variant?: Variant;
  children: React.ReactNode;
  className?: string;
}

export function Badge({ variant = "default", children, className }: BadgeProps) {
  const { bg, color } = VARIANTS[variant]; // nosemgrep: javascript.lang.security.detect-object-injection
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium${className ? ` ${className}` : ""}`}
      style={{ background: bg, color }}
    >
      {children}
    </span>
  );
}
