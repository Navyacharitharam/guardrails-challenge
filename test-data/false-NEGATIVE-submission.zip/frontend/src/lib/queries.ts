// TanStack Query hooks for all API resources.
// Components that need custom refetchInterval should use useQuery directly
// with the same queryKey so the cache stays consistent.
import { useQuery } from "@tanstack/react-query";
import { api } from "./api";

export function useAgentRuns() {
  return useQuery({
    queryKey: ["runs"],
    queryFn: api.listRuns,
  });
}

export function useAgentRun(id: string) {
  return useQuery({
    queryKey: ["runs", id],
    queryFn: () => api.getRun(id),
    enabled: Boolean(id),
  });
}

export function useAgentSteps(runId: string) {
  return useQuery({
    queryKey: ["runs", runId, "steps"],
    queryFn: () => api.getRunSteps(runId),
    enabled: Boolean(runId),
  });
}

export function usePendingReviews() {
  return useQuery({
    queryKey: ["reviews", "pending"],
    queryFn: api.listPendingReviews,
    refetchInterval: 60_000,
  });
}

export function useReview(id: string) {
  return useQuery({
    queryKey: ["reviews", id],
    queryFn: () => api.getReview(id),
    enabled: Boolean(id),
  });
}

export function useRecords(limit = 50) {
  return useQuery({
    queryKey: ["records", limit],
    queryFn: () => api.listRecords(undefined, limit),
  });
}

export function useICPs() {
  return useQuery({
    queryKey: ["icps"],
    queryFn: api.listICPs,
  });
}

export function useIntegrations() {
  return useQuery({
    queryKey: ["integrations"],
    queryFn: api.listIntegrations,
  });
}
