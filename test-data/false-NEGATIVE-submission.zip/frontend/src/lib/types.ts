// Shared TypeScript types matching the backend Pydantic schemas

export type AgentRunStatus = "queued" | "running" | "completed" | "failed" | "cancelled";
export type AgentStepType = "tool_call" | "llm_call" | "human_gate" | "error";
export type AgentStepStatus = "pending" | "running" | "completed" | "failed" | "retried";
export type HumanReviewStatus = "pending" | "approved" | "rejected" | "modified";
export type HumanReviewType = "hypothesis_approval" | "outreach_approval" | "enrichment_validation";
export type SignalType = "funding" | "hiring" | "job_change" | "intent" | "technographic" | "news" | "web_activity";
export type EnrichmentStatus = "unenriched" | "enriched" | "failed";

export interface TokenResponse {
  access_token: string;
  token_type: string;
  tenant_id: string;
}

export interface ICP {
  id: string;
  tenant_id: string;
  name: string;
  description: string;
  firmographic_criteria: Record<string, unknown>;
  technographic_criteria: Record<string, unknown>;
  persona_criteria: Record<string, unknown>;
  signal_weights: Record<string, number>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Record {
  id: string;
  tenant_id: string;
  object_definition_id: string;
  external_id: string | null;
  attributes: Record<string, unknown>;
  fit_score: number | null;
  intent_score: number | null;
  enrichment_status: EnrichmentStatus;
  created_at: string;
  updated_at: string;
}

export interface Signal {
  id: string;
  tenant_id: string;
  record_id: string;
  signal_type: SignalType;
  source: string;
  payload: Record<string, unknown>;
  score: number;
  occurred_at: string;
  created_at: string;
}

export interface AgentRun {
  id: string;
  tenant_id: string;
  workflow_type: string;
  status: AgentRunStatus;
  icp_id: string | null;
  input_payload: Record<string, unknown>;
  output_payload: Record<string, unknown> | null;
  error_message: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
}

export interface AgentStep {
  id: string;
  run_id: string;
  step_number: number;
  step_type: AgentStepType;
  tool_name: string | null;
  reasoning: string | null;
  input_payload: Record<string, unknown>;
  output_payload: Record<string, unknown> | null;
  status: AgentStepStatus;
  error_message: string | null;
  duration_ms: number | null;
  started_at: string;
  completed_at: string | null;
}

export interface HumanReview {
  id: string;
  tenant_id: string;
  run_id: string;
  step_id: string;
  review_type: HumanReviewType;
  proposed_output: Record<string, unknown>;
  context: Record<string, unknown>;
  status: HumanReviewStatus;
  reviewer_notes: string | null;
  modified_output: Record<string, unknown> | null;
  created_at: string;
  resolved_at: string | null;
}

export interface IntegrationConnection {
  id: string;
  tenant_id: string;
  provider_slug: string;
  display_name: string;
  is_active: boolean;
  rate_limit_state: Record<string, unknown>;
  last_used_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  admin_email: string;
  created_at: string;
}
