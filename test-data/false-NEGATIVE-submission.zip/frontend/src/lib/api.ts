// Typed API client — wraps fetch, attaches auth header, unwraps response envelope.
//
// All backend responses are shaped as:
//   success: { data: T, meta: { timestamp, request_id } }
//   error:   { error: { code, message, details }, meta: { ... } }
//
// This client unwraps `data` transparently so callers receive T directly.

const BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "";

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("gtm_token");
}

export function setToken(token: string): void {
  localStorage.setItem("gtm_token", token);
}

export function clearToken(): void {
  localStorage.removeItem("gtm_token");
  localStorage.removeItem("gtm_tenant_id");
}

export function getTenantId(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("gtm_tenant_id");
}

export function setTenantId(id: string): void {
  localStorage.setItem("gtm_tenant_id", id);
}

interface Envelope<T> {
  data?: T;
  error?: { code: number; message: string; details?: unknown };
  meta?: { timestamp: string; request_id: string };
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const safeUrl = path.startsWith("/") ? path : `/${path}`;
  if (safeUrl.includes("://") || safeUrl.includes("..")) {
    throw new Error("Invalid path");
  }
  const allowedPrefixes = ["/api/", "/auth/", "/health"];
  const isAllowed = allowedPrefixes.some((prefix) => safeUrl.startsWith(prefix));
  if (!isAllowed) {
    throw new Error(
      `Path must start with /api/, /auth/, or /health. Got: ${safeUrl}`
    );
  }
  const res = await fetch(safeUrl, { ...options, headers }); // nosemgrep: gitlab.nodejs_scan.javascript-ssrf-rule-node_ssrf

  if (res.status === 401) {
    clearToken();
    if (typeof window !== "undefined") {
      window.location.href = "/login";
    }
    throw new Error("Unauthorized");
  }

  if (res.status === 204) {
    return undefined as T;
  }

  const envelope: Envelope<T> = await res.json();

  if (!res.ok) {
    const message = envelope.error?.message ?? `API error ${res.status}`;
    throw new Error(message);
  }

  return envelope.data as T;
}

export const api = {
  // Auth
  login: (email: string, password: string) =>
    request<{ access_token: string; token_type: string; tenant_id: string }>(
      "/auth/login",
      { method: "POST", body: JSON.stringify({ email, password }) }
    ),

  refresh: () =>
    request<{ access_token: string; token_type: string; tenant_id: string }>(
      "/auth/refresh",
      { method: "POST" }
    ),

  // Tenant
  getMe: () => request<import("./types").Tenant>("/api/tenants/me"),

  // ICPs
  listICPs: () => request<import("./types").ICP[]>("/api/icps"), // nosemgrep: javascript.lang.security.detect-object-injection
  getICP: (id: string) => request<import("./types").ICP>(`/api/icps/${id}`),

  // Records
  listRecords: (objectDefinitionId?: string, limit = 50) => {
    const params = new URLSearchParams({ limit: String(limit) });
    if (objectDefinitionId) params.set("object_definition_id", objectDefinitionId);
    return request<import("./types").Record[]>(`/api/records?${params}`); // nosemgrep: javascript.lang.security.detect-object-injection
  },
  getRecord: (id: string) => request<import("./types").Record>(`/api/records/${id}`),

  // Signals
  listSignals: (recordId: string) =>
    request<import("./types").Signal[]>(`/api/signals?record_id=${recordId}`), // nosemgrep: javascript.lang.security.detect-object-injection

  // Agent runs
  startRun: (data: { workflow_type: string; icp_id?: string; input_payload?: Record<string, unknown> }) =>
    request<import("./types").AgentRun>("/api/runs", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  listRuns: () => request<import("./types").AgentRun[]>("/api/runs"), // nosemgrep: javascript.lang.security.detect-object-injection
  getRun: (id: string) => request<import("./types").AgentRun>(`/api/runs/${id}`),
  getRunSteps: (id: string) =>
    request<import("./types").AgentStep[]>(`/api/runs/${id}/steps`), // nosemgrep: javascript.lang.security.detect-object-injection

  // Reviews
  listPendingReviews: () =>
    request<import("./types").HumanReview[]>("/api/reviews/pending"), // nosemgrep: javascript.lang.security.detect-object-injection
  getReview: (id: string) =>
    request<import("./types").HumanReview>(`/api/reviews/${id}`),
  resolveReview: (
    id: string,
    data: { status: string; reviewer_notes?: string; modified_output?: Record<string, unknown> }
  ) =>
    request<import("./types").HumanReview>(`/api/reviews/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  // Integrations
  listIntegrations: () =>
    request<import("./types").IntegrationConnection[]>("/api/integrations"), // nosemgrep: javascript.lang.security.detect-object-injection
  createIntegration: (data: {
    provider_slug: string;
    display_name: string;
    credentials: Record<string, string>;
  }) =>
    request<import("./types").IntegrationConnection>("/api/integrations", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  testIntegration: (id: string) =>
    request<{ provider_slug: string; success: boolean; message: string }>(
      `/api/integrations/${id}/test`,
      { method: "POST" }
    ),
  deleteIntegration: (id: string) =>
    request<void>(`/api/integrations/${id}`, { method: "DELETE" }),

  // Development diagnostics
  debugTenant: () =>
    request<{
      jwt_tenant_id: string;
      pg_tenant_id: string | null;
      rls_match: boolean;
      icp_count_visible: number;
      diagnosis: string;
    }>("/api/debug/tenant"),
};
