"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, setToken, setTenantId } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("admin@acme-gtm.com");
  const [password, setPassword] = useState("demo1234");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.login(email, password);
      setToken(res.access_token);
      setTenantId(res.tenant_id);
      router.push("/prospect");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Logo / brand */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-[#6366F1] flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="white">
                <path d="M8 2L14 5v6L8 14 2 11V5L8 2z" />
              </svg>
            </div>
            <span className="text-xl font-semibold tracking-tight text-[#F8F8FF]">GTM Platform</span>
          </div>
          <p className="text-[#9CA3AF] text-sm">AI-native sales intelligence</p>
        </div>

        {/* Card */}
        <div
          className="rounded-xl border p-8"
          style={{ background: "#111118", borderColor: "rgba(255,255,255,0.08)" }}
        >
          <h2 className="text-lg font-medium text-[#F8F8FF] mb-6">Sign in to your workspace</h2>

          {error && (
            <div className="mb-4 px-3 py-2 rounded-md bg-[#EF444415] border border-[#EF4444] text-[#EF4444] text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#9CA3AF] mb-1.5" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-3 py-2.5 rounded-lg border text-sm text-[#F8F8FF] bg-[#0A0A0F] focus:outline-none focus:border-[#6366F1] transition-colors"
                style={{ borderColor: "rgba(255,255,255,0.12)" }}
                placeholder="admin@acme-gtm.com"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#9CA3AF] mb-1.5" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-3 py-2.5 rounded-lg border text-sm text-[#F8F8FF] bg-[#0A0A0F] focus:outline-none focus:border-[#6366F1] transition-colors"
                style={{ borderColor: "rgba(255,255,255,0.12)" }}
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-lg bg-[#6366F1] text-white text-sm font-medium hover:bg-[#5557E0] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? "Signing in..." : "Sign in"}
            </button>
          </form>

          <div className="mt-4 pt-4 border-t text-xs text-[#9CA3AF]" style={{ borderColor: "rgba(255,255,255,0.08)" }}>
            <p className="font-medium text-[#6366F1] mb-1">Demo credentials</p>
            <p>Tenant 1: admin@acme-gtm.com / demo1234</p>
            <p>Tenant 2: admin@velocity-sales.com / demo1234</p>
          </div>
        </div>
      </div>
    </div>
  );
}
