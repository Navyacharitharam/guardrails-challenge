import type { Metadata } from "next";
import "@/styles/globals.css";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "GTM Platform — AI-native Sales Intelligence",
  description: "AI-native Go-To-Market platform with custom agent orchestration",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-[#0A0A0F] text-[#F8F8FF] antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
