"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function Home() {
  const router = useRouter();
  useEffect(() => {
    const token = localStorage.getItem("gtm_token");
    router.replace(token ? "/prospect" : "/login");
  }, [router]);
  return (
    <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
      <div className="text-[#9CA3AF] text-sm">Redirecting...</div>
    </div>
  );
}
