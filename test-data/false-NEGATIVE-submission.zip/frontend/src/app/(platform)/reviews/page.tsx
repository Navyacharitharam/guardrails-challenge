"use client";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import { usePendingReviews } from "@/lib/queries";
import { Badge } from "@/components/ui/Badge";
import { Spinner } from "@/components/ui/Spinner";
import { EmptyState } from "@/components/ui/EmptyState";

const TYPE_VARIANT: Record<string, "accent" | "success" | "warning"> = {
  hypothesis_approval: "accent",
  outreach_approval: "success",
  enrichment_validation: "warning",
};

const TYPE_LABEL: Record<string, string> = {
  hypothesis_approval: "Hypothesis",
  outreach_approval: "Outreach",
  enrichment_validation: "Enrichment",
};

export default function ReviewsPage() {
  const { data: reviews = [], isLoading } = usePendingReviews();

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-[#F8F8FF] mb-1">
          Reviews
          {reviews.length > 0 && (
            <span
              className="ml-2 text-sm px-2 py-0.5 rounded-full align-middle"
              style={{ background: "#6366F115", color: "#6366F1" }} // nosemgrep: javascript.lang.security.detect-object-injection
            >
              {reviews.length} pending
            </span>
          )}
        </h1>
        <p className="text-sm text-[#9CA3AF]">
          Approve, modify, or reject agent-generated hypotheses and outreach before they proceed.
        </p>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-sm text-[#9CA3AF]">
          <Spinner size="sm" /> Loading reviews…
        </div>
      ) : reviews.length === 0 ? (
        <EmptyState
          icon={
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 11l3 3L22 4" />
              <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" />
            </svg>
          }
          title="No pending reviews"
          description="Run a Prospect workflow to generate hypotheses and outreach for review."
        />
      ) : (
        <div className="space-y-2">
          {reviews.map((review) => {
            const ctx = review.context as Record<string, unknown> | null;
            const accountName =
              ctx?.company_name ?? ctx?.account_name ?? null;

            return (
              <Link
                key={review.id}
                href={`/reviews/${review.id}`}
                className="flex items-center gap-4 rounded-lg border px-4 py-3.5 hover:border-[#6366F1]/30 transition-colors group"
                style={{ borderColor: "rgba(255,255,255,0.08)", background: "#111118" }}
              >
                <Badge variant={TYPE_VARIANT[review.review_type] ?? "accent"}>
                  {TYPE_LABEL[review.review_type] ?? review.review_type}
                </Badge>

                <div className="flex-1 min-w-0">
                  {accountName && (
                    <div className="text-sm text-[#F8F8FF] truncate">
                      {String(accountName)}
                    </div>
                  )}
                  <div className="text-xs text-[#6B7280] mt-0.5">
                    {formatDistanceToNow(new Date(review.created_at), { addSuffix: true })}
                  </div>
                </div>

                <span
                  className="text-xs px-2 py-0.5 rounded-full flex-shrink-0"
                  style={{ background: "rgba(245,158,11,0.1)", color: "#F59E0B" }}
                >
                  Pending
                </span>

                <svg
                  width="14" height="14" viewBox="0 0 24 24" fill="none"
                  stroke="#6B7280" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
                  className="flex-shrink-0 group-hover:stroke-[#9CA3AF] transition-colors"
                >
                  <polyline points="9 18 15 12 9 6" />
                </svg>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
