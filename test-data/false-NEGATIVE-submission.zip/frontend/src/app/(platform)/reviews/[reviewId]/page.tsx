"use client";
import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { Spinner } from "@/components/ui/Spinner";
import { HypothesisReview } from "@/components/reviews/HypothesisReview";
import { OutreachReview } from "@/components/reviews/OutreachReview";

const TYPE_VARIANT: Record<string, "accent" | "success" | "warning"> = {
  hypothesis_approval: "accent",
  outreach_approval: "success",
  enrichment_validation: "warning",
};

const TYPE_LABEL: Record<string, string> = {
  hypothesis_approval: "Hypothesis Approval",
  outreach_approval: "Outreach Approval",
  enrichment_validation: "Enrichment Validation",
};

const STATUS_VARIANT: Record<string, "success" | "danger" | "accent" | "muted"> = {
  approved: "success",
  rejected: "danger",
  modified: "accent",
  pending: "muted",
};

export default function ReviewDetailPage() {
  const { reviewId } = useParams<{ reviewId: string }>();
  const router = useRouter();
  const qc = useQueryClient();

  const [resolving, setResolving] = useState(false);
  const [notes, setNotes] = useState("");
  const [showModify, setShowModify] = useState(false);
  const [modifiedJson, setModifiedJson] = useState("");
  const [error, setError] = useState<string | null>(null);

  const { data: review, isLoading } = useQuery({
    queryKey: ["reviews", reviewId],
    queryFn: () => api.getReview(reviewId),
  });

  async function handleResolve(
    status: "approved" | "rejected" | "modified"
  ) {
    if (!review) return;
    setError(null);
    setResolving(true);
    try {
      let modified_output: Record<string, unknown> | undefined;
      if (status === "modified" && modifiedJson.trim()) {
        modified_output = JSON.parse(modifiedJson);
      }
      await api.resolveReview(reviewId, {
        status,
        reviewer_notes: notes.trim() || undefined,
        modified_output,
      });
      await qc.invalidateQueries({ queryKey: ["reviews"] });
      router.push("/reviews");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to resolve review");
    } finally {
      setResolving(false);
    }
  }

  if (isLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-sm text-[#9CA3AF]">
        <Spinner size="sm" /> Loading review…
      </div>
    );
  }

  if (!review) {
    return (
      <div className="p-6 text-sm text-[#EF4444]">Review not found.</div>
    );
  }

  const isPending = review.status === "pending";
  const typeVariant = TYPE_VARIANT[review.review_type] ?? "accent";
  const typeLabel = TYPE_LABEL[review.review_type] ?? review.review_type;
  const ctx = review.context as Record<string, unknown>;

  return (
    <div className="p-6 max-w-4xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-6 text-sm">
        <Link
          href="/reviews"
          className="text-[#9CA3AF] hover:text-[#F8F8FF] transition-colors"
        >
          ← Reviews
        </Link>
        <span className="text-[#6B7280]">/</span>
        <Badge variant={typeVariant}>{typeLabel}</Badge>
        {!isPending && (
          <Badge variant={STATUS_VARIANT[review.status] ?? "muted"}>
            {review.status}
          </Badge>
        )}
      </div>

      {/* Context card */}
      {ctx && Object.keys(ctx).length > 0 && (
        <Card className="mb-4">
          <div className="text-xs font-medium text-[#9CA3AF] mb-3">Context</div>
          <div className="grid grid-cols-2 gap-x-6 gap-y-2 mb-3">
            {Object.entries(ctx).map(([k, v]) => (
              <div key={k} className="text-xs">
                <span className="text-[#6B7280] capitalize">
                  {k.replace(/_/g, " ")}:{" "}
                </span>
                <span className="text-[#F8F8FF]">
                  {typeof v === "number"
                    ? v > 0 && v <= 1
                      ? `${Math.round(v * 100)}%`
                      : String(v)
                    : String(v)}
                </span>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-4 text-xs text-[#6B7280]">
            <span>
              Created{" "}
              {formatDistanceToNow(new Date(review.created_at), {
                addSuffix: true,
              })}
            </span>
            <Link
              href={`/traces/${review.run_id}`}
              className="text-[#6366F1] hover:text-[#818CF8] transition-colors"
            >
              View trace →
            </Link>
          </div>
        </Card>
      )}

      {/* Proposed output */}
      <Card className="mb-4">
        <div className="text-xs font-medium text-[#9CA3AF] mb-4">
          Proposed Output
        </div>
        {review.review_type === "outreach_approval" ? (
          <OutreachReview proposed_output={review.proposed_output} />
        ) : (
          <HypothesisReview review={review} />
        )}
      </Card>

      {/* Action area */}
      {isPending ? (
        <div className="space-y-3">
          {error && (
            <div
              className="text-xs text-[#EF4444] rounded-lg px-3 py-2"
              style={{ background: "rgba(239,68,68,0.08)" }}
            >
              {error}
            </div>
          )}

          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Reviewer notes (optional)…"
            className="w-full rounded-lg px-3 py-2.5 text-sm text-[#F8F8FF] bg-[#111118] border resize-none focus:outline-none focus:border-[#6366F1] transition-colors"
            style={{ borderColor: "rgba(255,255,255,0.12)" }}
            rows={2}
          />

          {showModify && (
            <div>
              <div className="text-xs text-[#9CA3AF] mb-1.5">
                Modified output (JSON) — leave blank to keep original
              </div>
              <textarea
                value={modifiedJson}
                onChange={(e) => setModifiedJson(e.target.value)}
                placeholder={JSON.stringify(review.proposed_output, null, 2)}
                className="w-full rounded-lg px-3 py-2 text-xs font-mono text-[#F8F8FF] bg-[#0A0A0F] border resize-none focus:outline-none focus:border-[#6366F1] transition-colors"
                style={{ borderColor: "rgba(255,255,255,0.12)" }}
                rows={10}
              />
            </div>
          )}

          <div className="flex gap-2">
            <button
              onClick={() => handleResolve("approved")}
              disabled={resolving}
              className="flex-1 py-2.5 rounded-lg bg-[#10B981] text-white text-sm font-medium hover:bg-[#059669] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {resolving ? (
                <span className="flex items-center justify-center gap-2">
                  <Spinner size="sm" /> Processing…
                </span>
              ) : (
                "Approve"
              )}
            </button>

            <button
              onClick={() => setShowModify(!showModify)}
              disabled={resolving}
              className="px-4 py-2.5 rounded-lg border text-sm font-medium text-[#F59E0B] border-[#F59E0B]/25 hover:bg-[#F59E0B0D] disabled:opacity-50 transition-colors"
            >
              {showModify ? "Cancel modify" : "Modify"}
            </button>

            {showModify && (
              <button
                onClick={() => handleResolve("modified")}
                disabled={resolving || !modifiedJson.trim()}
                className="px-4 py-2.5 rounded-lg border text-sm font-medium text-[#6366F1] border-[#6366F1]/25 hover:bg-[#6366F10D] disabled:opacity-50 transition-colors"
              >
                Submit modified
              </button>
            )}

            <button
              onClick={() => handleResolve("rejected")}
              disabled={resolving}
              className="px-4 py-2.5 rounded-lg border text-sm font-medium text-[#EF4444] border-[#EF4444]/25 hover:bg-[#EF44440D] disabled:opacity-50 transition-colors"
            >
              Reject
            </button>
          </div>
        </div>
      ) : (
        <Card>
          <div className="text-sm text-[#9CA3AF]">
            This review was{" "}
            <span
              style={{
                color:
                  review.status === "approved"
                    ? "#10B981"
                    : review.status === "rejected"
                    ? "#EF4444"
                    : "#6366F1",
              }}
            >
              {review.status}
            </span>
            {review.reviewer_notes && (
              <span className="text-[#6B7280]">
                {" "}
                — &ldquo;{review.reviewer_notes}&rdquo;
              </span>
            )}
          </div>
          {review.resolved_at && (
            <div className="text-xs text-[#6B7280] mt-1">
              {formatDistanceToNow(new Date(review.resolved_at), {
                addSuffix: true,
              })}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
