"use client";
import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { clearToken } from "@/lib/api";
import { usePendingReviews } from "@/lib/queries";

function IconProspect() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="4" />
      <line x1="12" y1="2" x2="12" y2="6" />
      <line x1="12" y1="18" x2="12" y2="22" />
      <line x1="2" y1="12" x2="6" y2="12" />
      <line x1="18" y1="12" x2="22" y2="12" />
    </svg>
  );
}

function IconTraces() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
      <line x1="8" y1="6" x2="21" y2="6" />
      <line x1="8" y1="12" x2="21" y2="12" />
      <line x1="8" y1="18" x2="21" y2="18" />
      <line x1="3" y1="6" x2="3.01" y2="6" />
      <line x1="3" y1="12" x2="3.01" y2="12" />
      <line x1="3" y1="18" x2="3.01" y2="18" />
    </svg>
  );
}

function IconReviews() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 11l3 3L22 4" />
      <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" />
    </svg>
  );
}

function IconSettings() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
    </svg>
  );
}

const NAV = [
  { href: "/prospect", label: "Prospect", Icon: IconProspect },
  { href: "/traces", label: "Traces", Icon: IconTraces },
  { href: "/reviews", label: "Reviews", Icon: IconReviews },
  { href: "/settings/icp", label: "Settings", Icon: IconSettings },
];

function ReviewsBadge() {
  const { data: pending = [] } = usePendingReviews();
  if (pending.length === 0) return null;
  return (
    <span
      className="ml-auto text-[10px] font-semibold px-1.5 py-0.5 rounded-full leading-none"
      style={{ background: "#6366F1", color: "#fff" }}
    >
      {pending.length > 9 ? "9+" : pending.length}
    </span>
  );
}

export default function PlatformLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const token = localStorage.getItem("gtm_token");
    if (!token) router.replace("/login");
  }, [router]);

  function handleLogout() {
    clearToken();
    router.replace("/login");
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside
        className="w-56 flex-shrink-0 flex flex-col border-r"
        style={{ background: "#111118", borderColor: "rgba(255,255,255,0.08)" }}
      >
        {/* Brand */}
        <div className="h-14 flex items-center gap-2 px-4 border-b" style={{ borderColor: "rgba(255,255,255,0.08)" }}>
          <div className="w-7 h-7 rounded bg-[#6366F1] flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="white">
              <path d="M7 1L13 4v6L7 13 1 10V4L7 1z" />
            </svg>
          </div>
          <span className="text-sm font-semibold text-[#F8F8FF] tracking-tight">GTM Platform</span>
        </div>

        {/* Nav items */}
        <nav className="flex-1 p-2 space-y-0.5 mt-2">
          {NAV.map(({ href, label, Icon }) => {
            const active = pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                  active
                    ? "bg-[#6366F115] text-[#6366F1]"
                    : "text-[#9CA3AF] hover:text-[#F8F8FF] hover:bg-white/5"
                }`}
              >
                <Icon />
                {label}
                {label === "Reviews" && <ReviewsBadge />}
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t" style={{ borderColor: "rgba(255,255,255,0.08)" }}>
          <button
            onClick={handleLogout}
            className="w-full text-left text-xs text-[#9CA3AF] hover:text-[#F8F8FF] px-3 py-2 rounded transition-colors hover:bg-white/5"
          >
            Sign out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}
