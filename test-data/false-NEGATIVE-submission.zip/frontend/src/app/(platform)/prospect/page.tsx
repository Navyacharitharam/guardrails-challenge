"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/lib/api";
import { useICPs, useAgentRuns } from "@/lib/queries";
import { RunStatus } from "@/components/prospect/RunStatus";
import { Spinner } from "@/components/ui/Spinner";

export default function ProspectPage() {
  const router = useRouter();
  const { data: icps = [], isLoading: icpsLoading, isError: icpsError } = useICPs();
  const { data: runs = [], isLoading: runsLoading } = useAgentRuns();

  const activeICP = icps.find((i) => i.is_active) ?? icps[0] ?? null;
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function startRun() {
    if (!activeICP) return;
    setError(null);
    setLoading(true);
    try {
      const run = await api.startRun({
        workflow_type: "prospect",
        icp_id: activeICP.id,
        input_payload: { icp_id: activeICP.id },
      });
      router.push(`/prospect/${run.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to start run");
      setLoading(false);
    }
  }

  return (
    <div className="p-6 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-[#F8F8FF] mb-1">Prospect</h1>
        <p className="text-sm text-[#9CA3AF]">
          Run the AI agent to discover, enrich, and score accounts matching your ICP.
        </p>
      </div>

      {/* ICP selector + run trigger */}
      <div
        className="rounded-xl border p-5 mb-6"
        style={{ background: "#111118", borderColor: "rgba(255,255,255,0.08)" }}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="text-xs font-medium text-[#9CA3AF] mb-2">Active ICP</div>
            {icpsLoading ? (
              <div className="flex items-center gap-2 text-sm text-[#9CA3AF]">
                <Spinner size="sm" /> Loading…
              </div>
            ) : icpsError ? (
              <div className="text-sm text-[#EF4444]">
                Failed to load ICP — your session may have expired.{" "}
                <Link href="/login" className="underline hover:text-[#F87171]">
                  Sign out and back in →
                </Link>
              </div>
            ) : activeICP ? (
              <>
                <div className="text-base font-medium text-[#F8F8FF] mb-1">
                  {activeICP.name}
                </div>
                {activeICP.description && (
                  <p className="text-sm text-[#9CA3AF] line-clamp-2">
                    {activeICP.description}
                  </p>
                )}
                {Array.isArray(
                  (activeICP.firmographic_criteria as { industries?: string[] })?.industries
                ) && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {(
                      (activeICP.firmographic_criteria as { industries?: string[] })
                        .industries ?? []
                    ).map((ind: string) => (
                      <span
                        key={ind}
                        className="text-xs px-2 py-0.5 rounded-full"
                        style={{ background: "#6366F115", color: "#6366F1" }}
                      >
                        {ind}
                      </span>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div className="text-sm text-[#9CA3AF] space-y-1">
                <div>
                  No ICP found for this account.{" "}
                  <Link href="/settings/icp" className="text-[#6366F1] hover:underline">
                    View ICP settings →
                  </Link>
                </div>
                <div className="text-xs text-[#6B7280]">
                  If seed data is present, try{" "}
                  <Link href="/login" className="text-[#6366F1] hover:underline">
                    signing out and back in
                  </Link>{" "}
                  — a stale session may be using an old tenant ID.
                </div>
              </div>
            )}
          </div>

          <button
            onClick={startRun}
            disabled={loading || !activeICP}
            className="px-5 py-2.5 rounded-lg bg-[#6366F1] text-white text-sm font-medium hover:bg-[#5557E0] disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap flex-shrink-0"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <Spinner size="sm" /> Starting…
              </span>
            ) : (
              "Run Prospect"
            )}
          </button>
        </div>

        {error && (
          <div className="mt-3 text-sm text-[#EF4444]">{error}</div>
        )}
      </div>

      {/* Recent runs */}
      <div>
        <div className="text-sm font-medium text-[#F8F8FF] mb-3">
          Recent Runs
        </div>

        {runsLoading ? (
          <div className="flex items-center gap-2 text-sm text-[#9CA3AF]">
            <Spinner size="sm" /> Loading runs…
          </div>
        ) : runs.length === 0 ? (
          <div className="text-sm text-[#6B7280]">No runs yet. Start your first prospect run above.</div>
        ) : (
          <div className="space-y-2">
            {runs.slice(0, 10).map((run) => (
              <Link
                key={run.id}
                href={`/prospect/${run.id}`}
                className="flex items-center gap-4 rounded-lg border px-4 py-3 hover:border-[#6366F1]/30 transition-colors group"
                style={{ borderColor: "rgba(255,255,255,0.08)", background: "#111118" }}
              >
                <RunStatus status={run.status} />
                <span className="text-sm font-mono text-[#9CA3AF] group-hover:text-[#F8F8FF] transition-colors">
                  {run.id.slice(0, 8)}…
                </span>
                <span className="text-xs text-[#6B7280] capitalize">{run.workflow_type}</span>
                <span className="ml-auto text-xs text-[#6B7280]">
                  {formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}
                </span>
                <svg
                  width="14" height="14" viewBox="0 0 24 24" fill="none"
                  stroke="#6B7280" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
                  className="flex-shrink-0"
                >
                  <polyline points="9 18 15 12 9 6" />
                </svg>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
