"use client";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/lib/api";
import { RunStatus } from "@/components/prospect/RunStatus";
import { AccountCard } from "@/components/prospect/AccountCard";
import { Spinner } from "@/components/ui/Spinner";

const STAGES = [
  { label: "ICP Loading", tools: ["load_icp"] },
  { label: "Account Discovery", tools: ["discover_companies", "score_accounts"] },
  { label: "Contact Enrichment", tools: ["enrich_contact"] },
  { label: "Signal Analysis", tools: ["compute_intent_score", "get_signals"] },
  { label: "Hypothesis Generation", tools: ["generate_hypothesis"] },
  { label: "Outreach Drafting", tools: ["generate_outreach"] },
];

export default function RunDetailPage() {
  const { runId } = useParams<{ runId: string }>();

  const { data: run, isLoading: runLoading } = useQuery({
    queryKey: ["runs", runId],
    queryFn: () => api.getRun(runId),
    refetchInterval: (query) => {
      const s = query.state.data?.status;
      return s === "running" || s === "queued" ? 2000 : false;
    },
  });

  const { data: steps = [] } = useQuery({
    queryKey: ["runs", runId, "steps"],
    queryFn: () => api.getRunSteps(runId),
    enabled: !!run,
    refetchInterval:
      run?.status === "running" || run?.status === "queued" ? 2000 : false,
  });

  const { data: records = [] } = useQuery({
    queryKey: ["records", 50],
    queryFn: () => api.listRecords(undefined, 50),
    enabled: run?.status === "completed" || run?.status === "failed",
  });

  const completedTools = new Set(
    steps
      .filter((s) => s.status === "completed")
      .map((s) => s.tool_name ?? "")
  );

  const currentStageIdx = STAGES.findIndex(
    (stage) => !stage.tools.some((t) => completedTools.has(t))
  );

  const sortedAccounts = [...records].sort(
    (a, b) => (b.fit_score ?? 0) - (a.fit_score ?? 0)
  );

  const output = (run?.output_payload ?? {}) as Record<string, unknown>;
  const isActive =
    run?.status === "running" || run?.status === "queued";

  if (runLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-sm text-[#9CA3AF]">
        <Spinner size="sm" /> Loading run…
      </div>
    );
  }

  if (!run) {
    return (
      <div className="p-6 text-sm text-[#EF4444]">Run not found.</div>
    );
  }

  return (
    <div className="p-6 max-w-5xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-6 text-sm">
        <Link
          href="/prospect"
          className="text-[#9CA3AF] hover:text-[#F8F8FF] transition-colors"
        >
          ← Prospect
        </Link>
        <span className="text-[#6B7280]">/</span>
        <span className="text-[#F8F8FF] font-mono"> {/* nosemgrep: javascript.lang.security.detect-object-injection */}
          {run.id.slice(0, 8)}… {/* nosemgrep: javascript.lang.security.detect-object-injection */}
        </span>
        <RunStatus status={run.status} />
      </div>

      {/* Pipeline progress */}
      <div
        className="rounded-xl border p-5 mb-5"
        style={{ background: "#111118", borderColor: "rgba(255,255,255,0.08)" }}
      >
        <div className="text-xs font-medium text-[#9CA3AF] mb-4">
          Pipeline Progress — {steps.length} step{steps.length !== 1 ? "s" : ""} recorded
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {STAGES.map((stage, i) => {
            const done = stage.tools.some((t) => completedTools.has(t));
            const active = currentStageIdx === i && isActive; // nosemgrep: javascript.lang.security.detect-object-injection
            return (
              <div
                key={i}
                className="flex items-center gap-2 rounded-lg px-3 py-2.5 border"
                style={{
                  borderColor: done
                    ? "rgba(16,185,129,0.25)"
                    : active
                    ? "rgba(99,102,241,0.25)"
                    : "rgba(255,255,255,0.05)",
                  background: done
                    ? "rgba(16,185,129,0.04)"
                    : active
                    ? "rgba(99,102,241,0.06)"
                    : "transparent",
                }}
              >
                <span
                  className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-semibold flex-shrink-0"
                  style={{
                    background: done
                      ? "rgba(16,185,129,0.15)"
                      : active
                      ? "rgba(99,102,241,0.15)"
                      : "rgba(255,255,255,0.05)",
                    color: done ? "#10B981" : active ? "#6366F1" : "#6B7280",
                  }}
                >
                  {done ? "✓" : i + 1}
                </span>
                <span
                  className="text-xs leading-tight"
                  style={{
                    color: done ? "#10B981" : active ? "#F8F8FF" : "#6B7280",
                  }}
                >
                  {stage.label}
                </span>
                {active && (
                  <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#6366F1] animate-pulse flex-shrink-0" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Completed summary card */}
      {run.status === "completed" && output.top_account_name && (
        <div
          className="rounded-xl border p-5 mb-5"
          style={{ background: "#111118", borderColor: "rgba(99,102,241,0.3)" }}
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1">
                Top Account
              </div>
              <div className="text-base font-semibold text-[#F8F8FF]">
                {String(output.top_account_name)}
              </div>
              <div className="flex flex-wrap gap-4 mt-2">
                {output.fit_score !== undefined && (
                  <div className="text-xs">
                    <span className="text-[#9CA3AF]">ICP Fit </span>
                    <span className="text-[#6366F1] font-semibold">
                      {Math.round(Number(output.fit_score) * 100)}%
                    </span>
                  </div>
                )}
                {output.intent_score !== undefined && (
                  <div className="text-xs">
                    <span className="text-[#9CA3AF]">Intent </span>
                    <span className="text-[#10B981] font-semibold">
                      {Math.round(Number(output.intent_score) * 100)}%
                    </span>
                  </div>
                )}
                {output.enriched_contacts !== undefined && (
                  <div className="text-xs">
                    <span className="text-[#9CA3AF]">Contacts enriched </span>
                    <span className="text-[#F8F8FF] font-semibold">
                      {String(output.enriched_contacts)}
                    </span>
                  </div>
                )}
                {output.outreach_variants !== undefined && (
                  <div className="text-xs">
                    <span className="text-[#9CA3AF]">Outreach variants </span>
                    <span className="text-[#F8F8FF] font-semibold">
                      {String(output.outreach_variants)}
                    </span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex flex-col gap-2 flex-shrink-0">
              <Link
                href={`/traces/${runId}`}
                className="text-xs px-3 py-1.5 rounded-lg border text-[#9CA3AF] hover:text-[#F8F8FF] transition-colors"
                style={{ borderColor: "rgba(255,255,255,0.12)" }}
              >
                View trace
              </Link>
              {output.review_id && (
                <Link
                  href={`/reviews/${output.review_id}`}
                  className="text-xs px-3 py-1.5 rounded-lg bg-[#6366F1] text-white hover:bg-[#4F46E5] transition-colors text-center"
                >
                  Review outreach →
                </Link>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Failed state */}
      {run.status === "failed" && (
        <div
          className="rounded-xl border p-4 mb-5"
          style={{
            background: "rgba(239,68,68,0.06)",
            borderColor: "rgba(239,68,68,0.3)",
          }}
        >
          <div className="text-sm font-medium text-[#EF4444] mb-1">
            Run failed
          </div>
          {run.error_message && (
            <div className="text-xs text-[#EF4444]/70">{run.error_message}</div>
          )}
          <Link
            href={`/traces/${runId}`}
            className="text-xs text-[#EF4444] hover:text-[#F87171] transition-colors mt-2 inline-block"
          >
            View trace for details →
          </Link>
        </div>
      )}

      {/* Discovered accounts grid */}
      {sortedAccounts.length > 0 && (
        <div>
          <div className="text-sm font-medium text-[#F8F8FF] mb-3">
            Discovered Accounts{" "}
            <span className="text-[#6B7280] font-normal">
              ({sortedAccounts.length})
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {sortedAccounts.slice(0, 9).map((rec, i) => (
              <AccountCard key={rec.id} record={rec} highlight={i === 0} />
            ))}
          </div>
        </div>
      )}

      {/* Active run placeholder */}
      {isActive && sortedAccounts.length === 0 && (
        <div className="flex items-center gap-3 py-6 text-sm text-[#9CA3AF]">
          <Spinner size="sm" />
          Discovering and scoring accounts…
        </div>
      )}

      {/* Run metadata footer */}
      <div className="mt-6 text-xs text-[#6B7280]">
        Started{" "}
        {run.started_at
          ? formatDistanceToNow(new Date(run.started_at), { addSuffix: true })
          : formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}
        {run.started_at && run.completed_at && (
          <>
            {" · "}
            {Math.round(
              (new Date(run.completed_at).getTime() -
                new Date(run.started_at).getTime()) /
                1000
            )}
            s total
          </>
        )}
      </div>
    </div>
  );
}
