"use client";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import { useAgentRuns } from "@/lib/queries";
import { RunStatus } from "@/components/prospect/RunStatus";
import { Spinner } from "@/components/ui/Spinner";
import { EmptyState } from "@/components/ui/EmptyState";

export default function TracesPage() {
  const { data: runs = [], isLoading } = useAgentRuns();

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-[#F8F8FF] mb-1">Traces</h1>
        <p className="text-sm text-[#9CA3AF]">
          Step-by-step execution logs for every agent run.
        </p>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-sm text-[#9CA3AF]">
          <Spinner size="sm" /> Loading traces…
        </div>
      ) : runs.length === 0 ? (
        <EmptyState
          icon={
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
              <line x1="8" y1="6" x2="21" y2="6" />
              <line x1="8" y1="12" x2="21" y2="12" />
              <line x1="8" y1="18" x2="21" y2="18" />
              <line x1="3" y1="6" x2="3.01" y2="6" />
              <line x1="3" y1="12" x2="3.01" y2="12" />
              <line x1="3" y1="18" x2="3.01" y2="18" />
            </svg>
          }
          title="No traces yet"
          description="Run a Prospect workflow to generate execution traces."
        />
      ) : (
        <div className="space-y-2">
          {runs.map((run) => {
            const durationMs =
              run.started_at && run.completed_at
                ? new Date(run.completed_at).getTime() - new Date(run.started_at).getTime()
                : null;

            return (
              <Link
                key={run.id}
                href={`/traces/${run.id}`}
                className="flex items-center gap-4 rounded-lg border px-4 py-3 hover:border-[#6366F1]/30 transition-colors group"
                style={{ borderColor: "rgba(255,255,255,0.08)", background: "#111118" }}
              >
                <RunStatus status={run.status} />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-mono text-[#F8F8FF]">
                      {run.id.slice(0, 8)}…
                    </span>
                    <span className="text-xs text-[#6B7280] capitalize">{run.workflow_type}</span>
                  </div>
                  <div className="text-xs text-[#6B7280] mt-0.5">
                    {formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}
                    {durationMs !== null && (
                      <span className="ml-3">
                        {durationMs < 1000 ? `${durationMs}ms` : `${(durationMs / 1000).toFixed(1)}s`}
                      </span>
                    )}
                  </div>
                </div>

                <svg
                  width="14" height="14" viewBox="0 0 24 24" fill="none"
                  stroke="#6B7280" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
                  className="flex-shrink-0 group-hover:stroke-[#9CA3AF] transition-colors"
                >
                  <polyline points="9 18 15 12 9 6" />
                </svg>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
