"use client";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/lib/api";
import { RunStatus } from "@/components/prospect/RunStatus";
import { TraceTimeline } from "@/components/traces/TraceTimeline";
import { Spinner } from "@/components/ui/Spinner";

export default function TraceDetailPage() {
  const { runId } = useParams<{ runId: string }>();

  const { data: run, isLoading: runLoading } = useQuery({
    queryKey: ["runs", runId],
    queryFn: () => api.getRun(runId),
  });

  const { data: steps = [], isLoading: stepsLoading } = useQuery({
    queryKey: ["runs", runId, "steps"],
    queryFn: () => api.getRunSteps(runId),
    enabled: !!run,
  });

  if (runLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-sm text-[#9CA3AF]">
        <Spinner size="sm" /> Loading trace…
      </div>
    );
  }

  if (!run) {
    return (
      <div className="p-6 text-sm text-[#EF4444]">Run not found.</div>
    );
  }

  const durationMs =
    run.started_at && run.completed_at
      ? new Date(run.completed_at).getTime() -
        new Date(run.started_at).getTime()
      : null;

  return (
    <div className="p-6 max-w-4xl">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-6 text-sm">
        <Link
          href="/traces"
          className="text-[#9CA3AF] hover:text-[#F8F8FF] transition-colors"
        >
          ← Traces
        </Link>
        <span className="text-[#6B7280]">/</span>
        <span className="text-[#F8F8FF] font-mono">{run.id.slice(0, 8)}…</span>
        <RunStatus status={run.status} />
      </div>

      {/* Run metadata row */}
      <div
        className="rounded-xl border p-4 mb-6 flex flex-wrap items-start gap-6"
        style={{ background: "#111118", borderColor: "rgba(255,255,255,0.08)" }}
      >
        <div>
          <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1">
            Run ID
          </div>
          <div className="text-xs font-mono text-[#F8F8FF]">{run.id}</div>
        </div>
        <div>
          <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1"> {/* nosemgrep: javascript.lang.security.detect-object-injection */}
            Workflow {/* nosemgrep: javascript.lang.security.detect-object-injection */}
          </div>
          <div className="text-xs text-[#F8F8FF]">{run.workflow_type}</div>
        </div>
        <div>
          <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1">
            Steps
          </div>
          <div className="text-sm font-semibold text-[#F8F8FF]">
            {steps.length}
          </div>
        </div>
        {run.started_at && (
          <div>
            <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1">
              Started
            </div>
            <div className="text-xs text-[#F8F8FF]">
              {formatDistanceToNow(new Date(run.started_at), {
                addSuffix: true,
              })}
            </div>
          </div>
        )}
        {durationMs !== null && (
          <div>
            <div className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wide mb-1">
              Duration
            </div>
            <div className="text-xs text-[#F8F8FF]">
              {durationMs < 1000
                ? `${durationMs}ms`
                : `${(durationMs / 1000).toFixed(1)}s`}
            </div>
          </div>
        )}
        {run.status === "completed" && run.output_payload && (
          <div className="ml-auto">
            <Link
              href={`/prospect/${runId}`}
              className="text-xs px-3 py-1.5 rounded-lg border text-[#6366F1] border-[#6366F1]/30 hover:bg-[#6366F110] transition-colors"
            >
              View run results →
            </Link>
          </div>
        )}
      </div>

      {/* Steps timeline */}
      {stepsLoading ? (
        <div className="flex items-center gap-2 text-sm text-[#9CA3AF]">
          <Spinner size="sm" /> Loading steps…
        </div>
      ) : (
        <TraceTimeline steps={steps} />
      )}
    </div>
  );
}
