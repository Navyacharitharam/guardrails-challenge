"use client";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useIntegrations } from "@/lib/queries";
import type { IntegrationConnection } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Spinner } from "@/components/ui/Spinner";
import { EmptyState } from "@/components/ui/EmptyState";

const PROVIDER_ICONS: Record<string, React.ReactNode> = {
  hunter: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="4" />
      <line x1="12" y1="2" x2="12" y2="6" /><line x1="12" y1="18" x2="12" y2="22" />
      <line x1="2" y1="12" x2="6" y2="12" /><line x1="18" y1="12" x2="22" y2="12" />
    </svg>
  ),
  apollo: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  ),
};

function ProviderIcon({ slug }: { slug: string }) {
  return (
    <div
      className="w-8 h-8 rounded-lg flex items-center justify-center text-[#9CA3AF]"
      style={{ background: "rgba(255,255,255,0.05)" }}
    >
      {PROVIDER_ICONS[slug] ?? (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75}>
          <path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71" />
          <path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71" />
        </svg>
      )}
    </div>
  );
}

function IntegrationCard({
  conn,
  onTest,
  onDelete,
}: {
  conn: IntegrationConnection;
  onTest: (id: string) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}) {
  const [testing, setTesting] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  async function handleTest() {
    setTesting(true);
    setResult(null);
    try {
      const r = await onTest(conn.id);
      setResult(r as unknown as { success: boolean; message: string });
    } finally {
      setTesting(false);
    }
  }

  async function handleDeleteConfirmed() {
    setConfirmingDelete(false);
    setDeleting(true);
    try {
      await onDelete(conn.id);
    } finally {
      setDeleting(false);
    }
  }

  return (
    <Card>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <ProviderIcon slug={conn.provider_slug} />
          <div>
            <div className="text-sm font-medium text-[#F8F8FF]">{conn.display_name}</div>
            <div className="text-xs text-[#6B7280] capitalize">{conn.provider_slug}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span
            className="text-xs px-2 py-0.5 rounded-full flex-shrink-0"
            style={{
              background: conn.is_active ? "rgba(16,185,129,0.1)" : "rgba(156,163,175,0.1)",
              color: conn.is_active ? "#10B981" : "#9CA3AF",
            }}
          >
            {conn.is_active ? "Active" : "Inactive"}
          </span>
          {confirmingDelete ? (
            <div className="flex items-center gap-1">
              <button
                onClick={handleDeleteConfirmed}
                disabled={deleting}
                className="text-xs text-[#EF4444] hover:underline disabled:opacity-40"
              >
                Remove
              </button>
              <span className="text-[#4B5563] text-xs">/</span>
              <button
                onClick={() => setConfirmingDelete(false)}
                className="text-xs text-[#6B7280] hover:underline"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmingDelete(true)}
              disabled={deleting}
              title="Remove integration"
              className="text-[#6B7280] hover:text-[#EF4444] disabled:opacity-40 transition-colors"
            >
              {deleting ? (
                <Spinner size="sm" />
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="3 6 5 6 21 6" />
                  <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" />
                  <path d="M10 11v6M14 11v6" />
                  <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2" />
                </svg>
              )}
            </button>
          )}
        </div>
      </div>

      {conn.last_used_at && (
        <div className="text-xs text-[#6B7280] mb-3">
          Last used{" "}
          {new Date(conn.last_used_at).toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
          })}
        </div>
      )}

      {result && (
        <div
          className="text-xs rounded px-2 py-1.5 mb-3"
          style={{
            background: result.success ? "rgba(16,185,129,0.08)" : "rgba(239,68,68,0.08)",
            color: result.success ? "#10B981" : "#EF4444",
          }}
        >
          {result.message}
        </div>
      )}

      <button
        onClick={handleTest}
        disabled={testing}
        className="text-xs text-[#6366F1] hover:text-[#818CF8] disabled:opacity-50 transition-colors flex items-center gap-1.5"
      >
        {testing && <Spinner size="sm" />}
        Test connection →
      </button>
    </Card>
  );
}

function ConnectForm({ onSuccess }: { onSuccess: () => void }) {
  const [slug, setSlug] = useState("hunter");
  const [apiKey, setApiKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await api.createIntegration({
        provider_slug: slug,
        display_name: `${slug.charAt(0).toUpperCase() + slug.slice(1)} (default)`,
        credentials: { api_key: apiKey },
      });
      setApiKey("");
      onSuccess();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to connect");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <h3 className="text-sm font-medium text-[#F8F8FF] mb-4">Add integration</h3>
      {error && (
        <div
          className="text-xs rounded px-2 py-1.5 mb-3"
          style={{ background: "rgba(239,68,68,0.08)", color: "#EF4444" }}
        >
          {error}
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="text-xs font-medium text-[#9CA3AF] mb-1.5 block">Provider</label>
          <select
            value={slug}
            onChange={(e) => setSlug(e.target.value)}
            className="w-full px-3 py-2 rounded-lg text-sm text-[#F8F8FF] border focus:outline-none focus:border-[#6366F1] transition-colors"
            style={{ background: "#0A0A0F", borderColor: "rgba(255,255,255,0.12)" }}
          >
            <option value="hunter">Hunter.io</option>
            <option value="apollo">Apollo.io</option>
            <option value="clearbit">Clearbit</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-[#9CA3AF] mb-1.5 block">API Key</label>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            required
            placeholder="sk-…"
            className="w-full px-3 py-2 rounded-lg text-sm text-[#F8F8FF] border focus:outline-none focus:border-[#6366F1] transition-colors"
            style={{ background: "#0A0A0F", borderColor: "rgba(255,255,255,0.12)" }}
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 rounded-lg bg-[#6366F1] text-white text-sm font-medium hover:bg-[#5557E0] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <Spinner size="sm" /> Connecting…
            </span>
          ) : (
            "Connect"
          )}
        </button>
      </form>
    </Card>
  );
}

export default function IntegrationsPage() {
  const qc = useQueryClient();
  const { data: integrations = [], isLoading, isError } = useIntegrations();

  async function handleTest(id: string) {
    return api.testIntegration(id);
  }

  async function handleDelete(id: string) {
    await api.deleteIntegration(id);
    qc.invalidateQueries({ queryKey: ["integrations"] });
  }

  function handleConnected() {
    qc.invalidateQueries({ queryKey: ["integrations"] });
  }

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-[#F8F8FF] mb-1">Integrations</h1>
        <p className="text-sm text-[#9CA3AF]">
          Connect enrichment providers. API credentials are encrypted at rest.
        </p>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-sm text-[#9CA3AF] mb-6">
          <Spinner size="sm" /> Loading integrations…
        </div>
      ) : isError ? (
        <div
          className="text-sm text-[#EF4444] rounded-lg px-4 py-3 mb-6"
          style={{ background: "rgba(239,68,68,0.08)" }}
        >
          Failed to load integrations. Ensure the backend is running and you are authenticated.
        </div>
      ) : integrations.length === 0 ? (
        <EmptyState
          icon={
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
              <path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71" />
              <path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71" />
            </svg>
          }
          title="No integrations connected"
          description="Add your first enrichment provider below."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {integrations.map((conn) => (
            <IntegrationCard
              key={conn.id}
              conn={conn}
              onTest={handleTest}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      <ConnectForm onSuccess={handleConnected} />
    </div>
  );
}
