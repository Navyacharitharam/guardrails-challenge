"use client";
import { useICPs } from "@/lib/queries";
import { Card } from "@/components/ui/Card";
import { Spinner } from "@/components/ui/Spinner";
import { EmptyState } from "@/components/ui/EmptyState";

function CriteriaRow({ label, value }: { label: string; value: unknown }) {
  const display = Array.isArray(value)
    ? (value as string[]).join(", ")
    : typeof value === "object" && value !== null
    ? JSON.stringify(value)
    : String(value);

  return (
    <div className="flex items-start gap-3 text-xs">
      <span className="text-[#6B7280] capitalize min-w-[150px] flex-shrink-0">
        {label.replace(/_/g, " ")}
      </span>
      <span className="text-[#F8F8FF] break-words">{display}</span>
    </div>
  );
}

function CriteriaBlock({
  title,
  data,
}: {
  title: string;
  data: Record<string, unknown>;
}) {
  const entries = Object.entries(data);
  if (entries.length === 0) return null;

  return (
    <div className="mb-5">
      <div className="text-xs font-medium text-[#9CA3AF] mb-2">{title}</div>
      <div className="rounded-lg p-4 space-y-2.5" style={{ background: "#0A0A0F" }}>
        {entries.map(([k, v]) => (
          <CriteriaRow key={k} label={k} value={v} />
        ))}
      </div>
    </div>
  );
}

export default function ICPSettingsPage() {
  const { data: icps = [], isLoading, isError, error } = useICPs();

  const activeICP = icps.find((i) => i.is_active) ?? icps[0];

  if (isLoading) {
    return (
      <div className="p-6 flex items-center gap-2 text-sm text-[#9CA3AF]">
        <Spinner size="sm" /> Loading ICP…
      </div>
    );
  }

  if (isError) {
    return (
      <div className="p-6">
        <div
          className="rounded-lg px-4 py-3 text-sm text-[#EF4444]"
          style={{ background: "rgba(239,68,68,0.08)" }}
        >
          Failed to load ICP:{" "}
          {error instanceof Error ? error.message : "API error. Ensure the backend is running and you are authenticated."}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-[#F8F8FF] mb-1">
          ICP Configuration
        </h1>
        <p className="text-sm text-[#9CA3AF]">
          Ideal Customer Profile criteria used for account discovery and scoring.
        </p>
      </div>

      {!activeICP ? (
        <EmptyState
          icon={
            <svg
              width="28"
              height="28"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#6B7280"
              strokeWidth={1.5}
            >
              <circle cx="12" cy="12" r="10" />
              <circle cx="12" cy="12" r="6" />
              <circle cx="12" cy="12" r="2" />
            </svg>
          }
          title="No ICP configured"
          description="Create an ICP via the API or run the seed script to start prospecting."
        />
      ) : (
        <div className="space-y-4">
          {/* ICP header */}
          <Card>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="text-base font-semibold text-[#F8F8FF]">
                  {activeICP.name}
                </div>
                {activeICP.description && (
                  <p className="text-sm text-[#9CA3AF] mt-1 leading-relaxed">
                    {activeICP.description}
                  </p>
                )}
              </div>
              <span
                className="text-xs px-2 py-0.5 rounded-full flex-shrink-0"
                style={{ background: "rgba(16,185,129,0.1)", color: "#10B981" }}
              >
                Active
              </span>
            </div>

            <CriteriaBlock
              title="Firmographic Criteria"
              data={activeICP.firmographic_criteria as Record<string, unknown>}
            />

            <CriteriaBlock
              title="Technographic Criteria"
              data={activeICP.technographic_criteria as Record<string, unknown>}
            />

            <CriteriaBlock
              title="Persona Criteria"
              data={activeICP.persona_criteria as Record<string, unknown>}
            />

            {/* Signal weights */}
            {Object.keys(activeICP.signal_weights).length > 0 && (
              <div>
                <div className="text-xs font-medium text-[#9CA3AF] mb-3">
                  Signal Weights
                </div>
                <div className="space-y-2.5">
                  {Object.entries(activeICP.signal_weights)
                    .sort(([, a], [, b]) => b - a)
                    .map(([type, weight]) => (
                      <div key={type} className="flex items-center gap-3">
                        <span className="text-xs text-[#9CA3AF] capitalize w-28 flex-shrink-0">
                          {type.replace(/_/g, " ")}
                        </span>
                        <div className="flex-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${Math.round(weight * 100)}%`,
                              background: "#6366F1",
                            }}
                          />
                        </div>
                        <span className="text-xs font-medium text-[#6366F1] w-8 text-right tabular-nums">
                          {Math.round(weight * 100)}%
                        </span>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </Card>

          {/* Other ICPs */}
          {icps.length > 1 && (
            <div>
              <div className="text-xs font-medium text-[#9CA3AF] mb-2">
                Other ICPs ({icps.length - 1})
              </div>
              <div className="space-y-2">
                {icps
                  .filter((i) => i.id !== activeICP.id)
                  .map((icp) => (
                    <div
                      key={icp.id}
                      className="rounded-lg border px-4 py-3 flex items-center justify-between"
                      style={{ borderColor: "rgba(255,255,255,0.08)" }}
                    >
                      <span className="text-sm text-[#9CA3AF]">{icp.name}</span>
                      <span
                        className="text-xs px-2 py-0.5 rounded-full"
                        style={{
                          background: "rgba(156,163,175,0.1)",
                          color: "#6B7280",
                        }}
                      >
                        Inactive
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
