"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const TABS = [
  { href: "/settings/integrations", label: "Integrations" },
  { href: "/settings/icp", label: "ICP" },
];

export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div>
      {/* Sub-navigation */}
      <div
        className="border-b px-6 flex items-center gap-1"
        style={{ borderColor: "rgba(255,255,255,0.08)" }}
      >
        {TABS.map(({ href, label }) => {
          const active = pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={`text-sm py-3 px-3 border-b-2 -mb-px transition-colors ${
                active
                  ? "border-[#6366F1] text-[#F8F8FF]"
                  : "border-transparent text-[#9CA3AF] hover:text-[#F8F8FF]"
              }`}
            >
              {label}
            </Link>
          );
        })}
      </div>

      {children}
    </div>
  );
}
