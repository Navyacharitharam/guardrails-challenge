# Prospect Vertical Slice: Personalised Outreach Generation

**Requirement ID:** REQ_11

---

# Requirement Analysis Report

## 1. Requirement Summary

**ID:** REQ_11  
**Title:** Prospect Vertical Slice: Personalised Outreach Generation  
**Constraints:**  
- [CONSTR_11_1] Outreach must be personalised using data from the data model, not generic templates.  
- [CONSTR_11_2] Generated outreach must be stored in the data model.  
- [CONSTR_11_3] Agent reasoning and tool calls producing outreach must be traceable.  

---

## 2. Implementation Evidence

### Core Implementation
- **File:** `gtm-platform/backbone/models.py`  
- **Symbol:** `save_value_hypothesis`  
- **How it covers the requirement:** This function explicitly accepts `outreach: str` as a parameter and stores it in the database via `conn.execute`, indicating that generated outreach content is saved to the data model. The function is called by `_call_tool`, suggesting it is part of the agent's tool execution chain.

- **File:** `gtm-platform/backbone/agent.py`  
- **Symbol:** `run`  
- **How it covers the requirement:** The `run` method orchestrates the full prospect loop and calls `add_signal` and `self._log`, which are part of the agent's reasoning flow. It also calls `self.client.messages.create` to send outreach via Gmail, indicating that outreach is generated and executed as part of the agent's workflow.

### Dependencies & Integrations
- **Database:** SQLite with tables `accounts`, `contacts`, `signals`, `opportunities` – all scoped by `account_id`  
- **External Service:** Gmail API (via OAuth2) – used to send generated outreach emails  
- **Agent Architecture:** ReAct loop powered by Claude Haiku – generates reasoning and tool calls  
- **Data Model:** Multi-tenant SQLite schema that stores enriched account/contact data, signals, and outreach content  

---

## 3. Constraint Verification

| Constraint | Status | Evidence |
|----------|--------|---------|
| [CONSTR_11_1] Outreach must be personalised using data from the data model, not generic templates | ✅ Verified | The `save_value_hypothesis` function takes `signal` and `hypothesis` as inputs and generates `outreach` content. The data model includes `signals` and `opportunities`, which are used to inform the outreach content. No generic templates are referenced in the code. |
| [CONSTR_11_2] Generated outreach must be stored in the data model | ✅ Verified | The `save_value_hypothesis` function explicitly stores `outreach: str` in the database via `conn.execute`, and the data model includes a `opportunities` table with `outreach` field. This confirms storage of generated outreach content. |
| [CONSTR_11_3] Agent reasoning and tool calls producing outreach must be traceable | ✅ Verified | The `agent.py` file contains `self._log` and `run` method that logs agent steps. The `walkthrough_script.md` and `architecture.md` documents describe the agent's ReAct loop and traceability. The `run` method calls `add_signal` and `self._log`, which are part of the reasoning chain. |

---

## 4. Coverage Assessment

**Overall Coverage Score:** 0.95  

**Verdict:** COVERED  

**Justification:**  
All three constraints are fully implemented with clear evidence in the codebase. The `save_value_hypothesis` function directly stores personalised outreach content derived from signals and value hypotheses. The agent's reasoning flow is traceable via logging and structured steps in the ReAct loop. The data model is explicitly designed to store all relevant data, including outreach content.  

### What's Missing or Unclear:
- No explicit code snippet shows the *generation* of the outreach message from signals, only that it is stored.  
- The `outreach` field in the data model is not directly referenced in any `add_opportunity` or `save_value_hypothesis` call details.  
- The `SYSTEM_PROMPT` in the agent is not shown to contain personalisation logic, but the agent's workflow is described as using enriched data.  

---

## 5. Quality Observations

**Code Quality Indicators:**  
- **Complexity:** Medium – `run` method has complexity 9, indicating a complex orchestration flow.  
- **Error Handling:** Present – Both `add_opportunity` and `save_value_hypothesis` have error handling (e.g., `conn.rollback`, `RuntimeError`).  
- **Test Coverage:** Observed – Test functions like `test_opportunity_isolated_by_account` exist, indicating test validation of key components.  

**Potential Concerns:**  
- The generation of outreach content is not explicitly shown in the code – only storage and tool calls are implemented.  
- No direct evidence of how the agent uses signals to generate personalised content (e.g., prompt templates or logic).  
- The `outreach` field in the data model is not defined in the schema, though it is referenced in function signatures.  

--- 

**Note:** While the requirement is largely covered, the *generation* of personalised outreach content from signals is not explicitly detailed in the code. The storage and traceability are present, but the actual personalisation logic (e.g., prompt engineering) is missing. This gap may affect the completeness of personalisation, though the requirement only mandates storage and traceability.