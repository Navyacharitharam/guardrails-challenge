# Validation Guide

Step-by-step validation for each of the 4 major requirements, using the
provided false-positive and false-negative test data.

## Setup

```bash
# 1. False-positive test data (provided)
unzip test-data/false-POSITIVE-artifact.zip -d workspace/submission
cp test-data/challenge-context.json workspace/

# 2. False-negative test data (reuse the same pattern)
unzip test-data/false-NEGATIVE-artifact.zip -d workspace/submission
cp test-data/<false-negative-context>.json workspace/challenge-context.json

pnpm install && pnpm dev
```

Open `http://localhost:3000/studio`.

---

## Requirement 1: False-Negative Minimization

**Test case**: false-negative artifact, REQ_15 (the requirement that the
baseline AI Reviewer incorrectly marked MISSING despite implementation existing).

1. Navigate to `Requirement Analyzer` agent chat
   (`/studio/agents/requirement-analyzer-agent/chat/new`).
2. Paste REQ_15's JSON (from `challenge-context.json`) as input.
3. **Expected with guardrail**: if the agent's first draft concludes MISSING
   without ≥3 distinct `submission_search` queries, ≥1 successful
   `submission_read`, and without trying domain-synonym variants of the
   requirement's key terms, the run log shows:
   ```
   [false-negative-guardrail] MISSING verdict rejected - insufficient search effort, requesting retry
   ```
   followed by a retry message naming specific missing searches/reads.
4. **Pass criteria**: final verdict for REQ_15 is `COVERED` or `PARTIAL`
   (matching human review), OR if still `MISSING`, the report's evidence
   log shows ≥3 distinct queries + ≥1 read + synonym searches were performed
   before concluding so.

**Empty/junk codebase check**:
1. Point `WORKSPACE_PATH` at an empty `submission/` directory.
2. Run any requirement.
3. **Pass criteria**: agent reaches a MISSING verdict within `maxRetries + 1`
   total attempts (no infinite loop), log shows:
   ```
   [false-negative-guardrail] Empty/junk submission detected - accepting MISSING verdict without further retries
   ```

---

## Requirement 2: False-Positive Prevention

**Test case**: false-positive artifact, the requirement that the baseline AI
Reviewer marked COVERED but failed human review.

1. Run the same requirement against the false-positive artifact.
2. **Expected with guardrail**: if the agent's draft report cites a file/symbol
   in "Implementation Evidence" that it never called `submission_read` on,
   the log shows:
   ```
   [false-positive-guardrail] Unverified evidence in COVERED report - requesting retry
   ```
   with the specific unverified path(s) named in the abort reason.
3. **Pass criteria**: final report either (a) downgrades the verdict/score
   to match what's actually verifiable (matching human review), or (b) the
   agent performs the missing `submission_read` calls and the cited evidence
   is now traceable.
4. Cross-check: every `**File:** \`path\`` in the final "Implementation
   Evidence" section should correspond to a `submission_read` call visible
   in the trace (check the `.db` trace artifact or studio run history).

---

## Requirement 3: Output Quality Verification

1. Run `requirementsAnalyzerWorkflow` end-to-end against either test artifact.
2. For each requirement's final report, verify presence and non-empty content of:
   - `## 1. Requirement Summary` (with `**ID:**` and `**Title:**`)
   - `## 2. Implementation Evidence`
   - `## 3. Constraint Verification` (one table row per constraint in
     `challenge-context.json`)
   - `## 4. Coverage Assessment` (`**Verdict:**` ∈ {COVERED, PARTIAL, MISSING},
     `**Overall Coverage Score:**` ∈ [0,1], consistent with verdict ranges:
     COVERED ≥0.7, PARTIAL 0.3-0.7, MISSING <0.3)
   - `## 5. Quality Observations`
3. To force a failure for testing: temporarily comment out a section in the
   prompt template, or truncate `maxSteps`, and confirm the log shows:
   ```
   [output-quality-guardrail] Report failed quality validation - requesting retry
   ```
   with an itemized list of the missing/invalid fields.
4. **Pass criteria**: every requirement's final stored report (in the
   workflow's `result` array) passes `OutputQualityGuardrail.parseReportFields`
   (returns non-null) - i.e. the report is schema-valid.

---

## Requirement 4: Result Consistency

The included `public/requirement-analyzer-consistency.db` ships with the
`requirement_consistency_results` schema pre-created but EMPTY (no synthetic
rows) - it is populated by real runs via `CREATE TABLE IF NOT EXISTS` +
`UPSERT` in `LibSQLConsistencyStore`. Run the steps below to populate it with
real data.

1. Run the SAME requirement against the SAME codebase TWICE (two separate
   agent sessions/threads, e.g. via two runs of the chat UI with the same
   requirement JSON).
2. After run 1, inspect `requirement-analyzer-consistency.db`:
   ```bash
   sqlite3 src/mastra/public/requirement-analyzer-consistency.db \
     "SELECT * FROM requirement_consistency_results;"
   ```
   - Expect one row with the requirement's fingerprint, verdict, and score.
3. Run 2 (same requirement, same files read):
   - If the new score is within `0.15` of the stored score and the verdict
     matches, the run completes normally and the stored row's `sample_count`
     increments (rolling-average update).
   - If verdict differs OR score diverges by >0.15, log shows:
     ```
     [result-consistency-guardrail] Inconsistent result vs prior run - requesting re-verification
     ```
     and the abort reason lists which constraint(s) changed status between
     runs.
4. **Pass criteria**: across 3 runs of the same requirement against the same
   codebase, verdicts agree on ≥2/3 runs and the max pairwise score
   difference among AGREEING runs is ≤0.15. Disagreements should trigger the
   re-verification message at least once before being accepted.

---

## Unit tests (all 4 guardrails)

```bash
pnpm test guardrails
```

Expected: 58 tests pass, covering:
- FalseNegativeGuardrail: insufficient search → retry; sufficient search →
  accept; empty codebase → accept immediately; non-MISSING verdicts untouched.
- FalsePositiveGuardrail: unread file cited → retry; read file cited → accept;
  zero reads + COVERED → retry; MISSING untouched; retry-limit → accept.
- OutputQualityGuardrail: valid report → accept; missing section → retry;
  verdict/score mismatch → retry; missing verdict → retry; missing constraint
  row → retry; retry-limit → accept; `parseReportFields` correctness.
- ResultConsistencyGuardrail: baseline storage; within-tolerance accept;
  diverging verdict → retry; retry-limit → accept; different read-set →
  treated as new baseline (no false comparison).

## Latency check

Each guardrail's `processInputStep`/`processOutputStep` is pure
string/regex/hash work with no additional LLM calls (the consistency
guardrail's store read/write is a single local LibSQL query). Overhead per
guardrail is sub-millisecond; the only added latency comes from triggered
*retries*, each of which is one additional agent step (bounded by
`maxProcessorRetries: 2`). Worst case: 2 extra steps × per-step latency,
which should remain comfortably under the 90s/requirement budget for
qwen3:4b-instruct at MAX_CONTEXT_SIZE=43960.
