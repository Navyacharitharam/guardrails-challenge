# Requirement Analyzer Guardrails

Implementation of the four required guardrails (False-Negative Minimization,
False-Positive Prevention, Output Quality Verification, Result Consistency)
plus two new "smart" tools (`submission_search_terms`, `verify_constraint`)
for the `requirement-analyzer-agent`.

## Files

```
src/mastra/agents/requirement-analyzer/
├── agent.ts                          # updated wiring (guardrails + tools)
├── instructions.ts                   # full instructions, incl. dynamic
│                                      # domain-concepts synonym table and
│                                      # new-tool descriptions
├── options.ts                        # default agent options
├── guardrails/
│   ├── domain-concepts.ts
│   ├── false-negative-guardrail.ts
│   ├── false-positive-guardrail.ts
│   ├── output-quality-guardrail.ts
│   ├── result-consistency-guardrail.ts
│   ├── libsql-consistency-store.ts
│   ├── run-state.ts
│   └── index.ts
├── public/
│   └── requirement-analyzer-consistency.db   # empty LibSQL artifact;
│                                              # schema created on first run
└── tools/
    ├── submission-search-terms-tool.ts
    └── verify-constraint-tool.ts

tests/
├── cross-requirement-isolation.test.ts
├── false-negative-guardrail.test.ts
├── false-negative-file-reference.test.ts
├── false-positive-guardrail.test.ts
├── output-quality-guardrail.test.ts
└── result-consistency-guardrail.test.ts
```

## Deployment

1. Copy `guardrails/`, `tools/`, `instructions.ts`, and `options.ts` into
   `src/mastra/agents/requirement-analyzer/` in the provided codebase
   (overwriting the existing `instructions.ts`/`options.ts` - they are
   additive/compatible with the original, adding the two new tool
   descriptions and the dynamically-generated domain-concepts synonym table).
2. Apply `agent.ts` (or merge the `inputProcessors`/`outputProcessors`/tools
   wiring into the existing `agent.ts`).
3. Copy `public/requirement-analyzer-consistency.db` into
   `src/mastra/public/` (or let it be created automatically on first run via
   `CREATE TABLE IF NOT EXISTS`).
4. Install deps (already present in the provided codebase): `zod`,
   `@mastra/core`, `@mastra/libsql`, `@mastra/loggers`.
5. Set environment variables in `.env`:
   ```
   WORKSPACE_PATH=/absolute/path/to/workspace
   LLM_MODEL_NAME=qwen3:4b-instruct
   LLM_PROVIDER_NAME=TC-Ollama
   MAX_CONTEXT_SIZE=43960
   CONSISTENCY_DB_URL=file:./src/mastra/public/requirement-analyzer-consistency.db
   ```
6. `pnpm install && pnpm dev`, then open `http://localhost:3000/studio`.

## Running tests

```bash
pnpm test                      # all existing + new tests
pnpm test guardrails           # just the new guardrail unit tests
```

Tests are written with `node:test` + `node:assert` and exercise each
guardrail's `processInputStep`/`processOutputStep` against fake message lists
- no live Ollama instance required.

## Guardrail summary

| Guardrail | Stage | Trigger | Action |
|---|---|---|---|
| FalseNegativeGuardrail | input + output | Final report verdict = MISSING | Validates `minSearchAttempts` distinct queries, `minReadAttempts` successful reads, and domain-synonym coverage based on requirement text. Aborts with retry + specific search suggestions if insufficient. Accepts MISSING immediately if the codebase inventory is empty/near-empty and searches already returned zero results (`maxRetries` worth of attempts) - prevents infinite loops on junk submissions. |
| FalsePositiveGuardrail | input + output | Final report verdict = COVERED/PARTIAL | Tracks every path/symbol actually returned by `submission_read` (`verifiedPaths`). Extracts every file path cited as evidence in the report and checks it against `verifiedPaths`. Aborts with retry naming unverified paths if any citation wasn't actually read, or if COVERED with zero reads at all. |
| OutputQualityGuardrail | output | Any final-report-shaped text | Validates the 5 required sections are present and non-placeholder, verdict/score are valid and mutually consistent (COVERED ≥0.7, PARTIAL 0.3-0.7, MISSING <0.3), justification is non-trivial, constraint table has a row per constraint, and ID/Title fields are present. Aborts with itemized fix list on failure. |
| ResultConsistencyGuardrail | input + output | Final report, same requirement+codebase fingerprint seen before | Computes a fingerprint from `requirementId + sorted inventory + sorted hashes of files actually read`. First run for a fingerprint stores a baseline (verdict, score, constraint statuses) in a LibSQL-backed store. Subsequent runs with the SAME fingerprint are compared: if verdict differs or score differs by more than `scoreTolerance` (default 0.15), the agent is asked to re-verify the specific constraints that changed before finalizing. |

## Smart tools

- **`submission_search_terms`**: run 2-6 related search queries in one call,
  merged/deduped, with a `zeroResultQueries` field - lets the agent cheaply
  satisfy the "search common naming conventions" requirement in a single tool
  call (helps both false-negative coverage AND the 90s latency budget).
- **`verify_constraint`**: cheap existence + relevance check (AST metadata,
  call graph, keyword-overlap score) for a candidate path/symbol before the
  agent commits a `submission_read` call or cites it in the report. Catches
  hallucinated paths early and flags low keyword-overlap matches.

## Processor ordering rationale

```
inputProcessors:  [ToolResultManager, FalseNegativeGuardrail, FalsePositiveGuardrail, ResultConsistencyGuardrail]
outputProcessors: [OutputQualityProcessor, OutputQualityGuardrail, FalseNegativeGuardrail, FalsePositiveGuardrail, ResultConsistencyGuardrail]
```

- `ToolResultManager` runs first on input to dedupe/compress tool results
  before the guardrails inspect tool-call history (keeps context window
  in check, satisfying the context-management constraint).
- `OutputQualityProcessor` (existing empty-response check) runs before the
  new `OutputQualityGuardrail` (structural validation) - cheaper checks first.
- `FalseNegativeGuardrail`/`FalsePositiveGuardrail` run on BOTH input (passive
  tracking of tool calls) and output (validation of the final verdict) - the
  same instance accumulates state across the whole agent run.
- `ResultConsistencyGuardrail` runs last on output since it depends on a
  well-formed report (parsed via `OutputQualityGuardrail.parseReportFields`)
  - if the report is structurally invalid, that guardrail's retry fires first
    and consistency checking is skipped until the report is well-formed.

## Configuration knobs (agent.ts)

```ts
new FalseNegativeGuardrail({ minSearchAttempts: 3, minReadAttempts: 1, maxRetries: 2 });
new FalsePositiveGuardrail({ minEvidenceLength: 10, maxRetries: 2 });
new OutputQualityGuardrail({ maxRetries: 2 });
new ResultConsistencyGuardrail({ scoreTolerance: 0.15, maxRetries: 1 }, consistencyStore);
```

`maxProcessorRetries: 2` on the agent caps total retries across all
processors combined, keeping worst-case latency bounded well under the 90s
per-requirement budget even if multiple guardrails fire in sequence.

## Per-thread state isolation (critical correctness fix)

Mastra constructs `inputProcessors`/`outputProcessors` ONCE per `Agent`
instance and reuses them across every `agent.generate()` call - including
every requirement processed by `requirementsAnalyzerWorkflow`, each with its
own `threadId` (`${challengeId}-req-${requirement.id}-${SUBMISSION_ID}-${Date.now()}`).

All three stateful guardrails (`FalseNegativeGuardrail`,
`FalsePositiveGuardrail`, `ResultConsistencyGuardrail`'s per-run tracking
fields) key their accumulated state by `args.requestContext.threadId` via
`RunStateStore<T>` (`guardrails/run-state.ts`). Without this, search/read
history and verified-paths from REQ_01 would leak into REQ_02's validation -
e.g. REQ_02 could get a free pass on `minSearchAttempts` because REQ_01
already did 3 searches, or REQ_02 could "verify" a file that was only read
while analyzing REQ_01. This is covered by
`tests/guardrails/cross-requirement-isolation.test.ts` (3 tests).

Note: `ResultConsistencyGuardrail`'s **persisted** `ConsistencyStore` is
intentionally CROSS-run (that's the entire point - comparing this run against
a prior run of the same requirement+codebase). Only its per-run *tracking*
fields (`requirementId`, `inventoryPaths`, `readHashes`, used to compute the
fingerprint) are thread-scoped.

## A note on `instructions-patch.ts` and `.db` files

- **`instructions-patch.ts`** is included as a REFERENCE document, not an
  active patch to re-apply. `instructions.ts` in this submission already has
  its content merged in (the new tool descriptions are inline, and the
  synonym table is generated via `${renderDomainConceptsTable()}` from
  `guardrails/domain-concepts.ts` - a single source of truth shared with
  `FalseNegativeGuardrail`, so the prompt and the guardrail can never drift
  out of sync). `instructions-patch.ts` documents what was changed and where,
  for anyone applying these guardrails to a fresh copy of the base codebase.

- **Only one `.db` file is included** (`public/requirement-analyzer-consistency.db`,
  with the `requirement_consistency_results` schema pre-created but empty).
  Two other `.db` files considered in earlier drafts
  (`guardrail-traces.db`/`guardrail_events`, `result-consistency.db`/
  `consistency_records`) were dropped: nothing in this codebase creates or
  writes to those tables. The one included `.db` file is the one `agent.ts`
  actually configures (`LibSQLStore({ id: 'requirement-analyzer-consistency',
  url: ... })`) and will be populated by real runs via
  `LibSQLConsistencyStore`'s `CREATE TABLE IF NOT EXISTS` + upsert.
