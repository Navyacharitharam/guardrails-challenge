# Architecture: Requirement Analyzer Guardrails

## Overview

```
                         ┌─────────────────────────────────────────┐
                         │         requirement-analyzer-agent        │
                         │                                            │
  user message  ───────▶ │  inputProcessors (run before each LLM step)│
  (1 requirement)        │   1. ToolResultManager   (dedup/compress)  │
                         │   2. FalseNegativeGuardrail (track calls)  │
                         │   3. FalsePositiveGuardrail (track reads)  │
                         │   4. ResultConsistencyGuardrail (track    │
                         │      inventory + read hashes)              │
                         │                                            │
                         │  ┌──────────────────────────────────┐    │
                         │  │  LLM (qwen3:4b-instruct, Ollama)   │    │
                         │  │  tools: submission_search,        │    │
                         │  │  submission_read,                 │    │
                         │  │  submission_search_terms (NEW),   │    │
                         │  │  verify_constraint (NEW)          │    │
                         │  └──────────────────────────────────┘    │
                         │                                            │
                         │  outputProcessors (run after each LLM step)│
                         │   1. OutputQualityProcessor (empty check)  │
                         │   2. OutputQualityGuardrail (structure)    │
                         │   3. FalseNegativeGuardrail (MISSING check)│
                         │   4. FalsePositiveGuardrail (evidence chk) │
                         │   5. ResultConsistencyGuardrail (compare)  │
                         │                                            │
                         │  any guardrail can `abort(reason, {retry}) │
                         │  → feedback fed back as next user message  │
                         │     (bounded by maxProcessorRetries: 2)    │
                         └─────────────────────────────────────────┘
                                          │
                                          ▼
                              final structured report (markdown)
```

Each agent run analyzes exactly ONE requirement in ONE thread (per the
"one requirement per agent thread" constraint). All four guardrails are
**stateful, per-run instances** (constructed fresh - or reused across calls
within `agent.ts` module scope for `ResultConsistencyGuardrail`, which is
intentionally cross-run via its persisted store).

---

## 1. False-Negative Minimization Guardrail

**File**: `guardrails/false-negative-guardrail.ts`

### Data flow
1. `processInputStep` (every step): scans `messageList` for new
   `submission_search` / `submission_read` tool-invocation results.
   - For each `submission_search`, records `{query, step, resultCount}`
     where `resultCount = files + documents + skippedSymbols + skippedDocs`.
   - For each `submission_read`, records `{path, step, hadError}`.
   - Also captures the requirement text (first user message) once, and the
     file-inventory size from the `ToolResultManager`-injected system message
     (`"The following files are available for requirement review..."`).

2. `processOutputStep` (on the model's final text): if the text looks like
   a final report (`# Requirement Analysis Report` header or `**Verdict:**`
   present) AND the verdict is `MISSING`:
   - **Empty-codebase short-circuit**: if `inventorySize <= 1` and all
     searches so far returned 0 results and `distinctQueries >= minSearchAttempts`,
     accept immediately (prevents infinite retry loops on junk submissions).
   - Otherwise compute three deficits:
     - `searchDeficit = max(0, minSearchAttempts - distinctQueries.length)`
     - `readDeficit = max(0, minReadAttempts - successfulReads.length)`
     - `missingSynonyms`: domain concepts found in the requirement text
       (via `DOMAIN_SYNONYMS` lookup table) for which NO synonym term has
       appeared in any executed search query.
   - If any deficit > 0 and `retryCount < maxRetries`: `abort(reason, {retry: true})`
     with a feedback message itemizing exactly which additional searches/reads
     to perform, including the specific synonym terms.
   - If `retryCount >= maxRetries`: accept with a warning log (don't loop
     forever).

### Key design decisions
- **Domain synonym table** (`DOMAIN_SYNONYMS`): a static map from normalized
  concept keywords (e.g. `"authentication"`) to literal code-pattern synonyms
  (`["auth", "login", "session", "jwt", ...]`). Extracted via substring match
  against the requirement's title+description+constraints text. This directly
  satisfies the validation criterion "Agent search for common naming
  conventions... based on domain knowledge must be ensured."
- **resultCount-based empty detection**: rather than trying to detect "junk
  codebase" structurally, the guardrail infers it empirically - if the
  inventory has ≤1 entries (effectively just the header) AND every search the
  agent already ran came back empty, there is nothing left to find. This is
  the mechanism that satisfies "Empty/junk code bases should be handled
  properly... not finding anything and looping infinity."
- **Stateful across the whole run**: a single instance is shared for both
  input and output processing within one agent run, accumulating
  `searchAttempts`/`readAttempts` across all steps so the final-step
  validation has full visibility into the entire investigation, not just the
  last step.

---

## 2. False-Positive Prevention Guardrail

**File**: `guardrails/false-positive-guardrail.ts`

### Data flow
1. `processInputStep`: for every successful (`!result.error`)
   `submission_read` tool result, adds entries to `verifiedPaths`:
   - Symbol reads (`{symbolPath, symbol: {bodyText}}`) → both the bare file
     path and the full `path:symbolName` are added.
   - File-with-symbols reads (`{filePath, symbols: [...]}`) → file path +
     `path:symbolName` for each returned symbol.
   - Document reads (`{filePath, content}`) → file path.
   - Also stores `readContents: {path, content, truncated}[]` for
     snippet-traceability and truncation-aware checks.

2. `processOutputStep`: if the final report's verdict is `COVERED` or
   `PARTIAL`, runs six checks. The first four can trigger a retry; the
   remaining two are observational only:

   - **Check 1 - Unread path claims**: `extractClaimedPaths(text)` parses
     `**File:** \`path\`` lines and inline-code spans matching a
     file-extension regex, normalizes `submission/` prefixes and trailing
     `:symbolName` suffixes, then checks each against `verifiedPaths` (with
     fuzzy substring/suffix fallback). Unmatched paths → `unverified[]`.
     If `verdict === 'COVERED'` with zero successful reads at all, that's
     also flagged here.
   - **Check 2 - Untraceable code snippets (blocking)**: fenced code blocks
     ≥ `minEvidenceLength` are checked for a substring match against
     `readContents`. If `readContents` is non-empty but a snippet can't be
     traced to any of it, the snippet is flagged as fabricated/copied from a
     search result (search snippets are explicitly insufficient evidence per
     the agent's instructions). This is now a BLOCKING check (previously
     logged only).
   - **Check 3 - Truncated-read quantitative claims**: if every successful
     read was `truncated: true` AND the report text matches
     `QUANTITATIVE_CLAIM_RE` (e.g. "at least 10", "exactly N", "N contacts"),
     flags that quantitative claims cannot be verified from incomplete file
     content. This directly targets the REQ_12-style failure mode (counting
     entries in a large seed-data file) from the other direction: rather
     than enabling counting, it prevents the agent from asserting counts it
     couldn't have actually performed.
   - **Check 4 - Hallucination/speculative language**: `HALLUCINATION_PATTERNS`
     (e.g. "likely implements", "appears to cover", "standard pattern would")
     combined with zero successful reads → flags speculative justification
     of a COVERED/PARTIAL verdict with no code evidence at all.
   - **Check 5 (observational) - AST symbol validation**: when checks 1-4
     all pass, `extractClaimedSymbols(text)` pulls `path:symbolName`
     references and asynchronously checks each against
     `astIndexerService.getStore().getSymbolsForFile(filePath)`. Because
     `processOutputStep` is synchronous, this lookup resolves AFTER the
     pass/fail decision for this step and can only `tcAILogger.warn(...)` -
     it never gates the verdict. It exists for trace review and to inform
     future threshold tuning, not as a retry trigger. Real-time,
     decision-affecting symbol validation is the agent's own responsibility
     via `verify_constraint` (see Smart Tools below).

   All retry-triggering feedback (checks 1-4) is consolidated into a single
   `abort(reason, {retry: true})` call per step, with each list-valued
   component (e.g. unverified paths) capped at 8 entries + "and N more" to
   bound context growth (see Context Window Management below).

### Key design decisions
- **Search results never count as evidence**: only `submission_read` results
  populate `verifiedPaths`. This directly maps to the
  `verifiedPaths: Set<string>` field in the suggested
  `FalsePositiveGuardrailConfig` interface and to the validation criterion
  "All file paths mentioned in positive findings must have corresponding
  evidences."
- **Fuzzy path matching**: code paths in LLM output are often slightly
  reformatted (e.g. `src/auth/session.ts` vs `./src/auth/session.ts` vs
  `src/auth/session.ts:createSession`). Rather than failing on cosmetic
  mismatches (which would cause spurious retries and hurt latency), the
  guardrail does normalized + fuzzy substring matching, reserving hard
  failures for paths that are genuinely absent from `verifiedPaths`.
- **AST cross-reference is split between guardrail (observational) and tool
  (real-time)**: `verify_constraint` gives the agent a cheap, synchronous way
  to self-check symbol claims *before* finalizing - shifting verification
  left in the workflow. The guardrail's AST check (Check 5) is a secondary,
  best-effort safety net for trace review, not a substitute for the tool.
- **Hallucination and truncation checks address the suggested
  `hallucinationIndicators` interface field and the "code subject should
  really do what agent claims it does" validation criterion** that the
  original single-check implementation did not cover.

---

## 3. Output Quality Verification Guardrail

**File**: `guardrails/output-quality-guardrail.ts`

### Data flow
`processOutputStep`: if the text looks like a final report:
1. `extractSectionsPresent`: checks each of the 5 required `##` sections
   (Requirement Summary, Implementation Evidence, Constraint Verification,
   Coverage Assessment, Quality Observations) is present, matching both
   numbered (`## 1. X`) and unnumbered (`## X`) header forms.
2. `sectionHasContent`: for each present section, extracts its body (up to
   the next `##`) and rejects bodies that are empty or look like an unfilled
   `[placeholder]` template fragment.
3. `extractVerdict` / `extractCoverageScore`: pull `**Verdict:**` and
   `**Overall Coverage Score:**`. Validates score ∈ [0,1] and
   verdict/score consistency (COVERED ≥0.7, PARTIAL 0.3-0.7, MISSING <0.3).
4. `extractJustification`: ensures the Coverage Assessment justification is
   present and non-trivial (≥10 chars, not just `[...]`).
5. `extractConstraintRows`: parses the markdown table in
   "Constraint Verification" into `{constraint, status, evidence}` rows.
   Compares row count against `expectedConstraintCount` (passed in from the
   requirement's `constraints[]` array length, if known).
6. `extractRequirementId` / `extractTitle`: validates `**ID:**` / `**Title:**`
   are present in section 1 (using anchored, end-of-line regexes to avoid
   false matches against the document's `# Requirement **ID:** [...] -Analysis
   Report` title line).

If any check fails and retries remain: `abort(reason, {retry: true})` with
an itemized bullet list of every issue found (not just the first), so the
agent can fix everything in one retry rather than playing whack-a-mole.

### Static API: `OutputQualityGuardrail.parseReportFields(text)`
Returns a `zod`-validated `ReportFields` object (or `null` if the text isn't
a valid final report). This is reused by `ResultConsistencyGuardrail` to get
a structured view of the current run's result without re-implementing
extraction logic - a single source of truth for "what does a valid report
look like."

### Key design decisions
- **Itemized, single-shot feedback**: collects ALL issues before aborting,
  so one retry can fix everything (minimizes total retries → latency).
- **Placeholder detection**: distinguishes "section present but model left
  template instructions in place" from "section genuinely filled in" -
  catches a common small-model failure mode (qwen3:4b copying the prompt
  template verbatim).
- **Verdict/score consistency check**: catches internally-contradictory
  reports (e.g. `Verdict: COVERED` with `Score: 0.2`) which would otherwise
  pass naive "is each field present" validation but represent reasoning
  errors.

---

## 4. Result Consistency Guardrail

**File**: `guardrails/result-consistency-guardrail.ts`,
`guardrails/libsql-consistency-store.ts`

### Data flow
1. `processInputStep`: tracks the file-inventory (from the
   `ToolResultManager` system message) and a hash of every
   `submission_read` result's content, keyed by path. Also extracts
   `requirementId` from the first user message.

2. `computeFingerprint(requirementId)`:
   ```
   fingerprint = sha256({
     requirementId,
     inventory: sorted(inventoryPaths),
     reads: sorted(["path:contentHash", ...])
   })
   ```
   Two runs of the same requirement against the same codebase, where the
   agent reads the same evidence files, produce the SAME fingerprint.

3. `processOutputStep`: parses the current report via
   `OutputQualityGuardrail.parseReportFields`. Looks up `fingerprint` in the
   `ConsistencyStore`:
   - **No prior result** → store `{verdict, coverageScore,
     constraintStatuses, sampleCount: 1}` as baseline. Accept.
   - **Prior exists, within tolerance** (`|Δscore| <= scoreTolerance` AND
     `verdict` unchanged) → update a rolling average of `coverageScore`,
     increment `sampleCount`. Accept.
   - **Prior exists, diverges** (verdict changed OR `|Δscore| >
     scoreTolerance`) and retries remain → `abort(reason, {retry: true})`,
     listing which specific constraints' status changed between runs
     (`diffConstraintStatuses`) and asking the agent to re-verify those
     specifically using `submission_read` before finalizing.
   - **Diverges, retry limit reached** → accept the new result but still
     update the rolling average (so the store trends toward a stable value
     over many runs) and log a warning.

### Persistence: LibSQL
`LibSQLConsistencyStore` wraps a `@mastra/libsql` `LibSQLStore` instance,
creating a `requirement_consistency_results` table
(`fingerprint TEXT PRIMARY KEY, verdict, coverage_score, constraint_statuses
JSON, sample_count, updated_at`) via an `UPSERT`. This `.db` file is placed
under `src/mastra/public/` and included in the submission's
LibSQLStore artifacts, satisfying both the persistence need and the
"include `.db` files with traces" submission requirement.

### Key design decisions
- **Fingerprint includes only files actually READ, not all search results**:
  this means the consistency check only fires when comparing genuinely
  comparable runs - if a second run investigates via a different set of
  files, it's treated as a fresh baseline rather than a false "inconsistency."
  This avoids spurious retries while still catching the real failure mode
  (same investigation, different conclusion → non-deterministic/flaky
  reasoning).
- **Rolling average rather than strict equality**: acknowledges that
  qwen3:4b-instruct will never be bit-identical across runs. The guardrail's
  job is to catch *qualitative* drift (verdict flips, large score swings),
  not to enforce determinism that the underlying model can't provide.
- **`scoreTolerance: 0.15` default**: chosen to be larger than typical
  small-model scoring noise (~0.05-0.1) but small enough to catch a
  COVERED↔PARTIAL boundary flip (0.7 threshold) reliably.
- **`maxRetries: 1` for this guardrail** (vs 2 for others): a
  consistency-triggered retry requires re-reading evidence files, which is
  the most expensive retry type - kept tight to protect the 90s/requirement
  latency budget.

---

## Smart tools

### `submission_search_terms`
**File**: `tools/submission-search-terms-tool.ts`

Wraps the existing `reviewWorkspace.search()` (same hybrid search backend
as `submission_search`) in a loop over 2-6 queries, merging results into
deduplicated `files[]`/`documents[]` (annotated with `matchedQueries`) plus
`perQuery[]` counts and `zeroResultQueries[]`. One tool call instead of N -
directly supports the false-negative guardrail's synonym-search requirement
while reducing total tool-invocation count (helps the 90s latency budget and
keeps `ToolResultManager`'s token-tracking simpler).

### `verify_constraint`
**File**: `tools/verify-constraint-tool.ts`

Given `(constraintText, candidatePath)`:
- Looks up the path/symbol in `astIndexerService`'s store. If absent,
  returns `exists: false` plus `suggestions` (reusing the same
  filename/path-segment similarity scoring as `submission_read`'s existing
  suggestion logic) - lets the agent self-correct a typo'd path for free.
- If present, returns AST metadata: `kind`, `signature`, `complexity`,
  `hasErrorHandling`, `hasLogging`, `calls`/`calledBy` (call graph), and a
  `keywordOverlapScore` (Jaccard overlap between tokenized constraint text
  and tokenized symbol name+signature) - a cheap heuristic signal for "is
  this plausibly the right symbol."
- Explicitly does NOT count as `submission_read` evidence (enforced by the
  false-positive guardrail, which only tracks `submission_read` results) -
  it's a pre-flight check, not a substitute for reading the real code.

---

## Processor registration (agent.ts)

```ts
inputProcessors: [
  toolResultManager,            // dedup/compress tool results first
  falseNegativeGuardrail,       // passive: track search/read calls
  falsePositiveGuardrail,       // passive: track verified paths
  resultConsistencyGuardrail,   // passive: track inventory + read hashes
],
outputProcessors: [
  outputQualityProcessor,       // existing: empty-response retry
  outputQualityGuardrail,       // structural validation
  falseNegativeGuardrail,       // MISSING-verdict validation
  falsePositiveGuardrail,       // evidence validation
  resultConsistencyGuardrail,   // cross-run consistency check
],
maxProcessorRetries: 2,
```

Each guardrail instance is shared between `inputProcessors` and
`outputProcessors` (same object reference) so accumulated state (tool-call
history, verified paths, inventory/read hashes) from input steps is visible
during output validation.

## Context Window Management

The pre-existing `ToolResultManager` already enforces a token budget for tool
results derived from `MAX_CONTEXT_SIZE` (`maxToolResultTokens =
MAX_CONTEXT_SIZE - 8000`), evicting/compressing the largest tool-result
entries via `_dropped`/`_compressed` markers once `totalToolTokens` exceeds
budget (`tools-result-manager.ts`). This guardrail work does not duplicate
or modify that mechanism.

The new guardrails add a second, smaller class of context consumer: retry
feedback and proactive-guidance strings injected via `abort(reason, ...)`
and `processInputStep`'s returned `systemMessages`. These are NOT tool
results, so `ToolResultManager`'s token-budget loop does not see or evict
them. To prevent these from becoming an unbounded growth vector across
retries (e.g. a confused run citing many file paths, or a requirement with
many constraints whose statuses changed between consistency-check runs),
every guardrail-generated feedback string that iterates over a
variable-length list is capped at a small fixed maximum with a "+N more"
summary for the remainder:

| Guardrail | List | Cap |
|---|---|---|
| FalseNegativeGuardrail | distinct search queries shown in retry feedback | 8 (most recent) |
| FalseNegativeGuardrail | missing domain-synonym suggestions (main feedback) | 6 |
| FalseNegativeGuardrail | missing domain-synonym suggestions (proactive guidance) | 5 |
| FalsePositiveGuardrail | unverified file paths cited in evidence | 8 |
| ResultConsistencyGuardrail | constraints whose status changed between runs | 8 |

These caps are small relative to `MAX_CONTEXT_SIZE` (43960) by design - each
capped list contributes at most a few hundred tokens even in the worst case,
keeping guardrail overhead negligible against the existing tool-result
budget regardless of how degenerate a given run becomes.
